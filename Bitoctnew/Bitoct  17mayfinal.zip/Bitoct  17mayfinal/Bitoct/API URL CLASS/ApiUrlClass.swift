//
//  ApiUrlClass.swift
//  QrScanner
//
//  Created by Purushottam on 10/03/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation

var BASE_URL = "https://api.bitoct.com/"

//******************POST*******************//
var LOGIN_URL = "api/bitoct/login"
var REGISTER_URL = "api/bitoct/Register"

//******************GET*******************//
 var BANNER_URL = "api/bitoct/getThemeList"
 var TopFourMarket_URL = "api/bitoct/getTopFourMarket"
 var MarketDataBtc_URL = "api/bitoct/getMarketDataBtc"
 var GetMarketData_URL = "api/bitoct/getMarketData"
var BuyOrderBuymarket_URL = "api/bitoct/getBuyOrdersByMarketID"
var BuyOrderBuymarket_LiveURL = "api/bitoct/getBuyOrdersByMarketIDLive"
var SellOrderByMarket_URL = "api/bitoct/getSellOrdersByMarketID"
var SellOrdeByMarket_LiveURL = "api/bitoct/getSellOrdersByMarketIDLive"
var GetTradeHistoryByAMrket_URL = "api/bitoct/getTradeHistoryByMarketID"
var GetTradeHistoryByAMrket_LiveURL = "api/bitoct/getTradeHistoryByMarketIDLive"

////
var OpenHistory_URL = "api/bitoct/getOpenHistory"
var Cancel_order_URL = "api/bitoct/cancelOrder"
/////
var OrderHistory_URL = "api/bitoct/getOrderHistory"
var DepositHistory_URL = "api/bitoct/getDepositeHistory"
var WithdrawalHistory_URL = "api/bitoct/getWithdrawalHistory"

var GetCoinBtcBalance_URL = "api/bitoct/getCoinBTCBalance?"

var BalanceCurrency_URL = "api/bitoct/getBalanceCurreny?"
var GetDepositeAddress_URL = "api/bitoct/genAddress?"

var GetWithdrawlDetail_URL = "api/bitoct/getWithdrawDetails?"

var WidthdrawlAction_URL = "api/bitoct/withdrawToAddress"

var BuyCurrencyChek_URl = "api/bitoct/buyCurrencycheck"

var SellCurrencyChek_URL = "api/bitoct/sellCurrencycheck"
var ChangePassword_URL = "api/bitoct/ChangePassword"
var GraphData_URL = "api/bitoct/getGraphMarketDataByMarketIDLive?"
var BarGraphData_URL = "api/bitoct/getGraphMarketDataByMarketVolume?"
var ValidateCode_URL = "api/bitoct/secureClick"













