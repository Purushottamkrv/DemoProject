//
//  AccountVC.swift
//  Bitoct
//
//  Created by Purushottam on 09/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class AccountVC: UIViewController {

    @IBOutlet weak var user_imageview: UIImageView!
    @IBOutlet weak var email_lbl: UILabel!
    @IBOutlet weak var description_lbl: UILabel!
    @IBOutlet weak var logout_btnoutlet: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        email_lbl.text = UserDefaults.standard.string(forKey: "EMAIL")
        logout_btnoutlet.layer.borderColor = UIColor .init(red: 3.0/255.0, green: 135.0/255.0, blue: 199.0/255.0, alpha: 1).cgColor
        logout_btnoutlet.layer.borderWidth = 3.0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func security_btnacn(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SecurityVC") as! SecurityVC
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    

    @IBAction func back_btn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func support_btnacn(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SupportVC") as! SupportVC
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func logout_btnacn(_ sender: Any) {
        
        let loginvc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        Alert.AlertActionToNilUserID(fromVC: self, toVC: loginvc)
        //UserDefaults.standard.set(nil, forKey: "USERID")
    }
    
    
}
