//
//  BackupkeyVC.swift
//  Bitoct
//
//  Created by Purushottam on 09/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class BackupkeyVC: UIViewController {

    @IBOutlet weak var google_view: UIView!
    @IBOutlet weak var google_imageview: UIImageView!
    @IBOutlet weak var qrcode_lbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        google_view.layer.cornerRadius = google_view.frame.size.height/2

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func back_btnacn(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func next_btnacn(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "EnterdigitVC") as! EnterdigitVC
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
}
