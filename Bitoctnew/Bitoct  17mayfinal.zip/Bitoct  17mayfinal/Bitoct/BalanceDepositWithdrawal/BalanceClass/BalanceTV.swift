//
//  BalanceTV.swift
//  Bitoct
//
//  Created by Purushottam on 01/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class BalanceTV: UITableView,UITableViewDataSource,UITableViewDelegate {

    //var pairdataarray = [PairDataClass](){
    //  didSet{
    //   reloadData()
    //}
    //}
    
    
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TransactionhistoryTvCell", for: indexPath) as! TransactionhistoryTvCell
        
        return cell
    }
    


}
