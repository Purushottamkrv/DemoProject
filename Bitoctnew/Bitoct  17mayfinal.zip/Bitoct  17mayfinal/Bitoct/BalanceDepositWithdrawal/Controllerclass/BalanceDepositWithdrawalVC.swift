//
//  BalanceDepositWithdrawalVC.swift
//  Bitoct
//
//  Created by Purushottam on 01/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class BalanceDepositWithdrawalVC: UIViewController {
    @IBOutlet weak var balance_linelbl:UILabel!
    @IBOutlet weak var deposit_linelbl:UILabel!
    @IBOutlet weak var withdrawal_linelbl:UILabel!
    
    
    @IBOutlet weak var balance_containerview: UIView!
    @IBOutlet weak var deposit_containerview: UIView!
    @IBOutlet weak var withdrawal_containerview: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        balance_linelbl.isHidden = false
        deposit_linelbl.isHidden = true
        withdrawal_linelbl.isHidden = true
        
        balance_containerview.isHidden = false
        deposit_containerview.isHidden = true
        withdrawal_containerview.isHidden = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    @IBAction func balace_btnacn(_ sender: Any) {
        
        
        
        balance_linelbl.isHidden = false
        deposit_linelbl.isHidden = true
        withdrawal_linelbl.isHidden = true
        
        balance_containerview.isHidden = false
        deposit_containerview.isHidden = true
        withdrawal_containerview.isHidden = true
    }
    
    
    @IBAction func deposit_btnacn(_ sender: Any) {
        
        balance_linelbl.isHidden = true
        deposit_linelbl.isHidden = false
        withdrawal_linelbl.isHidden = true
        
        balance_containerview.isHidden = true
        deposit_containerview.isHidden = false
        withdrawal_containerview.isHidden = true
    }
    
    
   
    
    @IBAction func withdrawal_btnacn(_ sender: Any) {
        
        balance_linelbl.isHidden = true
        deposit_linelbl.isHidden = true
        withdrawal_linelbl.isHidden = false
        
        balance_containerview.isHidden = true
        deposit_containerview.isHidden = true
        withdrawal_containerview.isHidden = false
    }
    
    @IBAction func bitcoin_dropbtnacn(_ sender: Any) {
    }
    
    
}
