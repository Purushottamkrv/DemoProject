//
//  WithdarawalnewVC.swift
//  Bitoct
//
//  Created by Purushottam on 01/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class WithdarawalnewVC: UIViewController {
    
    @IBOutlet weak var withdarawalnew_tableview:WithdarawalnewTV!

    override func viewDidLoad() {
        super.viewDidLoad()

        //buy_tableview.register(UINib(nibName: "BuysellOpenTvCell", bundle: nil), forCellReuseIdentifier: "BuysellOpenTvCell")
        
        withdarawalnew_tableview.register(UINib(nibName: "TransactionhistoryTvCell", bundle: nil), forCellReuseIdentifier: "TransactionhistoryTvCell")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   
}
