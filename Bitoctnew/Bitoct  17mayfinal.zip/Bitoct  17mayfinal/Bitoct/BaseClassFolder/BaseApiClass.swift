//
//  BaseApiClass.swift
//  QrScanner
//
//  Created by Purushottam on 10/03/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON
import MBProgressHUD

class ApiManager{
    
    static let sharedInstance = ApiManager()
    private init(){
    }
    
    
    func fetchResponseFromUrl(urlStr:String, paraMeters: Dictionary<String, Any>, viewController:UIViewController,loadercheck:Int, onCompletion:@escaping (JSON) -> Void, failure:@escaping (Error)->Void){
        
        
        if loadercheck == 1{
          // [MBProgressHUD .showAdded(to: viewController.view, animated: true)]
        }
        let apiURL = BASE_URL+urlStr
        //let apicomponent = URLComponents(string: apiURL)
        let para : Parameters = paraMeters
        let headers: HTTPHeaders = ["Content-type": "application/x-www-form-urlencoded"]
        
        Alamofire.request(apiURL, method: .post, parameters: para, encoding:URLEncoding.default, headers: headers).responseJSON { response in
            switch response.result{
            case.success(let data):
                let getresponse = JSON(data)
              // [MBProgressHUD .hide(for: viewController.view, animated: true)]
                onCompletion(getresponse)
                
            case.failure(let error):
                
               // [MBProgressHUD .hide(for: viewController.view, animated: true)]
                print("Failure:",error)
                failure(error)
                
            }
        }
        
    }
    
    //
    
    func fetchResponseFromUrl_get(urlStr:String, viewController:UIViewController,loadercheck:Int, onCompletion:@escaping (JSON) -> Void, failure:@escaping (Error)->Void){
        
        if loadercheck == 1{
           // [MBProgressHUD .showAdded(to: viewController.view, animated: true)]

            
        }
        let apiURL = BASE_URL+urlStr
          Alamofire.request(apiURL).responseJSON { response in
            switch response.result{
            case.success(let data):
                let getresponse = JSON(data)
                onCompletion(getresponse)
                
            case.failure(let error):
              //  [MBProgressHUD .hide(for: viewController.view, animated: true)]

                
                print("Failure:",error)
                failure(error)
                
            }
        }
        
    }
    
    func fetchResponseFromUrl_getWithParam(urlStr:String, viewController:UIViewController,paramvalue:String,paramname:String,loadercheck:Int, onCompletion:@escaping (JSON) -> Void, failure:@escaping (Error)->Void){
        
        if loadercheck == 1{
          //  [MBProgressHUD .showAdded(to: viewController.view, animated: true)]

            
        }
        let apiURL = BASE_URL+urlStr
        var components = URLComponents(string: apiURL)
        let param = URLQueryItem(name:paramname, value: paramvalue)
        
        components?.queryItems = [param]
        
        Alamofire.request((components?.url)!).responseJSON { response in
            switch response.result{
            case.success(let data):
             //   [MBProgressHUD .hide(for: viewController.view, animated: true)]

                let getresponse = JSON(data)
                //[MBProgressHUD .hide(for: viewController.view, animated: true)]
                onCompletion(getresponse)
                
            case.failure(let error):
              //  [MBProgressHUD .hide(for: viewController.view, animated: true)]

                
                //[MBProgressHUD .hide(for: viewController.view, animated: true)]
                print("Failure:",error)
                failure(error)
                
            }
        }
        
    }
    
    func fetchResponseFromUrl_getWithtwoParam(urlStr:String, viewController:UIViewController,paramvalue1:String,paramname1:String,paramvalue2:String,paramname2:String,loadercheck:Int, onCompletion:@escaping (JSON) -> Void, failure:@escaping (Error)->Void){
        
        if loadercheck == 1{
            
           // [MBProgressHUD .showAdded(to: viewController.view, animated: true)]

        }
        let apiURL = BASE_URL+urlStr
        var components = URLComponents(string: apiURL)
        let param1 = URLQueryItem(name:paramname1, value: paramvalue1)
        let param2 = URLQueryItem(name:paramname2, value: paramvalue2)

        components?.queryItems = [param1,param2]
        
        Alamofire.request((components?.url)!).responseJSON { response in
            switch response.result{
            case.success(let data):
            //    [MBProgressHUD .hide(for: viewController.view, animated: true)]

                let getresponse = JSON(data)
                onCompletion(getresponse)
                
            case.failure(let error):
                
             //   [MBProgressHUD .hide(for: viewController.view, animated: true)]

                print("Failure:",error)
                failure(error)
                
            }
        }
        
    }
    
    
    func fetchResponseFromUrl_getWithSixParams(urlStr:String, viewController:UIViewController,paramvalue1:String,paramname1:String,paramvalue2:String,paramname2:String,paramvalue3:String,paramname3:String,paramvalue4:String,paramname4:String,paramvalue5:String,paramname5:String,paramvalue6:String,paramname6:String,loadercheck:Int, onCompletion:@escaping (JSON) -> Void, failure:@escaping (Error)->Void){
        
        if loadercheck == 1{
          //  [MBProgressHUD .showAdded(to: viewController.view, animated: true)]

            
        }
        let apiURL = BASE_URL+urlStr
        var components = URLComponents(string: apiURL)
        let param1 = URLQueryItem(name:paramname1, value: paramvalue1)
        let param2 = URLQueryItem(name:paramname2, value: paramvalue2)
        let param3 = URLQueryItem(name:paramname3, value: paramvalue3)
        let param4 = URLQueryItem(name:paramname4, value: paramvalue4)
        let param5 = URLQueryItem(name:paramname5, value: paramvalue5)
        let param6 = URLQueryItem(name:paramname6, value: paramvalue6)
        
        components?.queryItems = [param1,param2,param3,param4,param5,param6]
        Alamofire.request((components?.url)!).responseJSON { response in
            switch response.result{
            case.success(let data):
                let getresponse = JSON(data)
                onCompletion(getresponse)
              //  [MBProgressHUD .hide(for: viewController.view, animated: true)]

                
            case.failure(let error):
                
             //   [MBProgressHUD .hide(for: viewController.view, animated: true)]

                print("Failure:",error)
                failure(error)
                
            }
        }
        
    }
    
    
   
    
    
}


