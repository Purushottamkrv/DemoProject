//
//  BuySellVC.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import Charts
import Alamofire
import SwiftyJSON
import HSStockChart

class BuySellVC: UIViewController,UIScrollViewDelegate,UITableViewDataSource,UITableViewDelegate {
    
    
    //@IBOutlet weak var barChartWidthConstraint: NSLayoutConstraint!
    var  array = [MarketDataClass]()
    var timer = Timer()
  // @IBOutlet weak var scrollViewBar: UIScrollView!
    public let ScreenWidth = UIScreen.main.bounds.width
    public let ScreenHeight = UIScreen.main.bounds.height
    public let TimeLineLongpress = "TimeLineLongpress"
    public let TimeLineUnLongpress = "TimeLineUnLongpress"
    public let TimeLineChartDidTap = "TimeLineChartDidTap"
    public let KLineChartLongPress = "kLineChartLongPress"
    public let KLineChartUnLongPress = "kLineChartUnLongPress"
    public let KLineUperChartDidTap = "KLineUperChartDidTap"
    var myTableView : UITableView!
    @IBOutlet weak var timeView: UIView!
    @IBOutlet weak var lineChartView: LineChartView!
    @IBOutlet weak var barChartView: BarChartView!
    @IBOutlet weak var combinedChartView: CombinedChartView!
    @IBOutlet weak var value_lbl: UILabel!
    @IBOutlet weak var value_lblconstraint: NSLayoutConstraint!
    
    let graphTimeArray = ["15min.", "30min.", "1H", "2H", "6H", "1D", "2D", "1W", "2W", "1M", "2M", "6M"]
    let graphSecondArray = ["900", "1800", "3600", "7200", "21600", "86400", "172800", "604800", "1209600", "2419200", "4838400", "14515200"]
    var timeParam = String()
    let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Dec", "Dec", "Dec", "Dec", "Dec", "Dec", "Dec"]
    let unitsSoldLine = [10.0, 12.0, 11.0, 13.0, 9.0, 10.5, 11.5, 12.0, 10.0, 10.5, 12.3, 13.0, 11.5, 10.0,13.5, 11.5, 12.0, 12.5, 9.5]
    var highArray = [Double]()
    var openArray = [Double]()
    var lowArray = [Double]()
    var volumeArray = [Double]()
    var volumeArray0 = [Double]()
    var volumeArray1 = [Double]()
    var timeArray = [String]()
    var timeArray0 = [String]()
    var timeArray1 = [String]()
    var timeArray11 = [String]()
    var tradeTrypeArray = [String]()
    var priceArray = [0, 0.00000002, 0.00000004, 0.00000006, 0.00000006, 0.00000008, 0.0000001]
    let unitsSoldBar = [2.0, 4.0, 6.0, 3.0, 4.0, 5.5, 4.0, 3.5, 2.5, 4.0, 5.7, 4.0, 8.0, 9.0, 5.9, 6.0, 2.0, 6.5, 5.4]
    @IBOutlet weak var graph_view:UIView!
    
    @IBOutlet weak var price_lbl:UILabel!
    @IBOutlet weak var amnt_lbl:UILabel!
    @IBOutlet weak var growthleft_lbl:UILabel!
    @IBOutlet weak var growthright_lbl:UILabel!
    @IBOutlet weak var volume_lbl:UILabel!
    @IBOutlet weak var timeBtn_Outlet: UIButton!
    @IBOutlet weak var highLabel: UILabel!
    @IBOutlet weak var lowLabel: UILabel!
    @IBOutlet weak var coinname_lbl:UILabel!
    @IBOutlet weak var order_view: UIView!
    @IBOutlet weak var marketview: UIView!
    @IBOutlet weak var orderbookcontainer_view: UIView!
    @IBOutlet weak var marketcontainer_view: UIView!
    
    @IBOutlet weak var scroll_view: UIScrollView!
    
    //@IBOutlet weak var content_view: UIView!
    var marketid = String()
    static var marketid1 = String()
    var coinNameStr = String()
    var priceStr = String()
    var growthleftStr = String()
    var growthrightStr = String()
    var amntStr = String()
    var volumeStr = String()
    var lowPrice = String()
    var highPrice = String()
    //var data2 = BarChartData()
    
    //static var aStoryboard:UIStoryboard!
    override func viewDidLoad() {
        super.viewDidLoad()
       self.timeParam = "900"//"86400"
        timeBtn_Outlet.setTitle("15min", for: .normal)
        //addChartController()
       // combinedChartView.backgroundColor = UIColor.init(red: 34.0/255.0, green: 48.0/255.0, blue: 67.0/255.0, alpha: 1.0)
        lineChartView.backgroundColor = UIColor.init(red: 34.0/255.0, green: 48.0/255.0, blue: 67.0/255.0, alpha: 1.0)
        barChartView.backgroundColor = UIColor.init(red: 34.0/255.0, green: 48.0/255.0, blue: 67.0/255.0, alpha: 1.0)
        
        let arraycount = array.count
        
        print("array cpunr",arraycount)
        
        orderbookcontainer_view.isHidden = false
        marketcontainer_view.isHidden = true
        order_view.isHidden = false
        marketview.isHidden = true

        print("Market Id=",marketid)
        BuySellVC.marketid1 = marketid
        coinname_lbl.text = coinNameStr
        price_lbl.text = priceStr
        amnt_lbl.text = amntStr
        growthleft_lbl.text = growthleftStr
        growthright_lbl.text = growthrightStr
        volume_lbl.text = "Vol "+volumeStr+" BTC"
        highLabel.text = highPrice
        lowLabel.text = lowPrice
        
        
       // BuysellApiHIt()
        //setChart(xValues: months, yValuesLineChart:  unitsSoldLine, yValuesBarChart: unitsSoldBar)
        GraphGetApiHIt()
        GraphGetApiHItBar()
       // timer = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    @objc func updateData()
    {
        self.GraphGetApiHIt()
        self.GraphGetApiHItBar()

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setChart(xValues: [String], yValuesLineChart: [Double], yValuesBarChart: [Double],yValuesBarChart0: [Double],yValuesBarChart1: [Double]) {
        //combinedChartView.noDataText = "Please provide data for the chart."
        lineChartView.noDataText = "Please provide data for the chart."
        barChartView.noDataText = "Please provide data for the chart."
        
        var yVals1 : [ChartDataEntry] = [ChartDataEntry]()
        var yVals2 : [BarChartDataEntry] = [BarChartDataEntry]()
        var yVals3 : [BarChartDataEntry] = [BarChartDataEntry]()
        var yVals4 : [BarChartDataEntry] = [BarChartDataEntry]()
        
        for i in 0..<volumeArray.count {
            
            yVals2.append(BarChartDataEntry(x: Double(i), y: yValuesBarChart[i]))
            
        }
        for i in 0..<volumeArray0.count {
            
            yVals3.append(BarChartDataEntry(x: Double(i), y: yValuesBarChart0[i]))
            
        }
        for i in 0..<volumeArray1.count {
            
            yVals4.append(BarChartDataEntry(x: Double(i), y: yValuesBarChart1[i]))
            
        }
        for j in 0..<openArray.count{
            yVals1.append(ChartDataEntry(x: Double(j), y: openArray[j] ))
        }
        print("Volume1 Count = ",volumeArray1.count)
        print("Volume1  = ",volumeArray1)
        print("Volume0 Count = ",volumeArray0.count)
        print("Volume0  = ",volumeArray0)
        print("Volume Count = ",volumeArray.count)
        print("Volume  = ",volumeArray)
        print("Open Count = ",openArray.count)
        print("Open  = ",openArray)
        
        let lineChartSet = LineChartDataSet(values: yVals1, label: "Line Data")
        let barChartSet: BarChartDataSet = BarChartDataSet(values: yVals2, label: "Bar Data")
        ////
        let barCharBuySet = BarChartDataSet(values: yVals3, label: "Sell")
        barCharBuySet.colors = [NSUIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0)]
        barCharBuySet.drawValuesEnabled = false
        
        let barCharSellSet = BarChartDataSet(values: yVals4, label: "Buy")
        barCharSellSet.colors = [NSUIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0)]
        barCharSellSet.drawValuesEnabled = false
       
        ////
        lineChartSet.circleColors = [UIColor.clear]
        lineChartSet.colors = [UIColor.init(red: 25.0/255.0, green: 105.0/255.0, blue: 129.0/255.0, alpha: 1.0)]
        lineChartSet.circleHoleColor = UIColor.clear
        lineChartSet.valueTextColor = UIColor.clear
        lineChartSet.valueColors = [NSUIColor.clear]
        
        let gradientColor = [UIColor.init(red: 19.0/255.0, green: 106.0/255.0, blue: 144.0/255.0, alpha: 1.0).cgColor, UIColor.init(red: 19.0/255.0, green: 106.0/255.0, blue: 144.0/255.0, alpha: 1.0).cgColor] as CFArray
        let colorPosition: [CGFloat] = [1.0, 1.0]
        
        guard let gradient = CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: gradientColor, locations: colorPosition) else{
            print("gradient error")
            return
        }
        lineChartSet.fill = Fill.fillWithLinearGradient(gradient, angle: 180.0)
        lineChartSet.drawFilledEnabled = true
       /* for j in 0..<yValuesBarChart.count
        {
            print("Value Bar = ",yValuesBarChart[j])
//            if yValuesBarChart[j] == 4.0 || yValuesBarChart[j] == 5.0 || yValuesBarChart[j] == 5.5
            if j == 3 || j == 5 || j == 9 || j == 14
            {
                //barChartSet.colors = [NSUIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0)]
                barChartSet.setColor(NSUIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0))
                
                //barChartSet.setColor(NSUIColor.gray)
            }
            else
            {
               // barChartSet.colors = [NSUIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0)]
                barChartSet.setColor(NSUIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0))
                //barChartSet.setColor(NSUIColor.gray)
            }
        }*/
        var colorarray = [UIColor]()
        for i in 0..<tradeTrypeArray.count
        {
            let colorr = setColorr(value: self.tradeTrypeArray[i])
            colorarray.append(colorr)
        }
        barChartSet.colors = colorarray
        barChartSet.valueColors = [NSUIColor.clear]
        //barChartSet.formSize = 2.0
        barChartSet.valueTextColor = UIColor.clear
        
//        let data: CombinedChartData = CombinedChartData()
//        data.barData = BarChartData(dataSets: [barChartSet])
//        data.lineData = LineChartData(dataSets: [lineChartSet])
//        data.barData.barWidth = 0.3
//        combinedChartView.data = data
        
        let data1 = LineChartData()
        data1.addDataSet(lineChartSet)
        lineChartView.data = data1
        lineChartView.chartDescription?.text = ""
        lineChartView.leftAxis.drawAxisLineEnabled = false
        lineChartView.leftAxis.drawGridLinesEnabled = false
        lineChartView.leftAxis.gridColor = NSUIColor.clear
        lineChartView.rightAxis.drawGridLinesEnabled = false
        lineChartView.rightAxis.drawAxisLineEnabled = false
        lineChartView.xAxis.drawGridLinesEnabled = false
        lineChartView.gridBackgroundColor = NSUIColor.clear
        lineChartView.gridBackgroundColor = UIColor.clear
        lineChartView.backgroundColor = UIColor.black
        lineChartView.xAxis.labelTextColor = UIColor.white
        lineChartView.xAxis.labelPosition = .bottom
        lineChartView.legend.enabled = false
        lineChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values:timeArray1)
        lineChartView.xAxis.granularity = 1
        
        let data2 = BarChartData(dataSets: [barCharBuySet, barCharSellSet])
        //data2.groupWidth(groupSpace: 0, barSpace: 0)
        //data2.addDataSet(barCharBuySet)
        //data2.addDataSet(barCharSellSet)
        //data2.addDataSet(barChartSet)
        data2.barWidth = 0.6
        barChartView.data = data2
        barChartView.chartDescription?.text = ""
        barChartView.leftAxis.drawGridLinesEnabled = false
        barChartView.leftAxis.drawAxisLineEnabled = false
        barChartView.leftAxis.gridColor = NSUIColor.clear
        barChartView.rightAxis.drawGridLinesEnabled = false
        barChartView.rightAxis.drawAxisLineEnabled = false
        barChartView.xAxis.drawGridLinesEnabled = false
        barChartView.backgroundColor = UIColor.black
        barChartView.xAxis.labelTextColor = UIColor.clear
        barChartView.xAxis.labelPosition = .bottom
        barChartView.legend.enabled = false
        //barChartView.sizeToFit()
        //barChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values:timeArray11)
       // barChartView.xAxis.granularity = 1
        
    }
    func setColorr(value: String) -> UIColor{
        
       /* if self.tradeTrypeArray.count > 0
        {
            for i in 0..<tradeTrypeArray.count
            {
                if tradeTrypeArray[i] == "0"
                {
                    return UIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0)
                }
                else
                {
                    return UIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0)
                }
            }
        }
            
        else
        {
             return UIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0)
        }*/
        if(value == "0"){
            return UIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0)
        }
        
        /*else if(value > 1000){
            return UIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0)
        }*/
            
        else { //In case anything goes wrong
            return UIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "order" {
            let vc = segue.destination as! OrderVC
            vc.marketid = marketid
        }
        
        else if segue.identifier == "market"{
            
            let vc1 = segue.destination as! MarketVC
            vc1.gatetmarketid = marketid
            
        }
    
    }
    @IBAction func tiimebtn_acn(_ sender: Any) {
        myTableView = UITableView(frame: CGRect(x: 20, y:timeView.frame.size.height+20, width: 120, height: 150))
        myTableView.backgroundColor = UIColor.black
        myTableView.dataSource = self
        myTableView.delegate = self
        myTableView.isHidden = false
        self.view.addSubview(myTableView)
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return graphTimeArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        
        cell.textLabel!.text = graphTimeArray[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.timeParam = graphSecondArray[indexPath.row]
        self.timeBtn_Outlet.setTitle(graphTimeArray[indexPath.row], for: .normal)
        myTableView.isHidden = true
        GraphGetApiHIt()
        GraphGetApiHItBar()
    }
    @IBOutlet weak var depthbtn_acn: UIButton!
    
    @IBAction func back_btnacn(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)

    }
    @IBAction func popbtn_acn(_ sender: Any) {
    }
    @IBAction func cornerbtn_acn(_ sender: Any) {
    }
    @IBAction func buy_btnacn(_ sender: Any) {
        let tabbarvc = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
        tabbarvc.selectedIndex = 2
        self.navigationController?.pushViewController(tabbarvc, animated: true)
    }
    @IBAction func sell_btnacn(_ sender: Any) {
        let tabbarvc = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
        tabbarvc.selectedIndex = 2
        self.navigationController?.pushViewController(tabbarvc, animated: true)
    }
    
    
    
}

extension BuySellVC{
    @IBAction func orderbookbtn_acn(_ sender: Any) {
        
        orderbookcontainer_view.isHidden = false
        marketcontainer_view.isHidden = true
        
        order_view.isHidden = false
        marketview.isHidden = true
        
    }
    
    @IBAction func markettradebtn_acn(_ sender: Any) {
        orderbookcontainer_view.isHidden = true
        marketcontainer_view.isHidden = false
        order_view.isHidden = true
        marketview.isHidden = false
        
    }
    
//    func scrollViewDidScroll(_ scrollView: UIScrollView) {
//    scroll_view.contentSize = CGSize(width: self.view.frame.size.width, height: 2000)
//
//    }
//
    
    
}
extension BuySellVC{

    private func GraphGetApiHIt(){
        var myResponse : JSON? = nil
        var myUser : GraphClass? = nil
        
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
            
            
            ApiManager.sharedInstance.fetchResponseFromUrl_getWithtwoParam(urlStr: GraphData_URL, viewController: self, paramvalue1: self.marketid, paramname1: "marketid", paramvalue2: self.timeParam, paramname2: "history", loadercheck: 1, onCompletion: { (GraphDataJson) ->Void in
                myResponse = GraphDataJson
                print(" Graph Data is ",myResponse!)
                DispatchQueue.main.async {
                    print("This is run on the main queue, after the previous code in outer block")
                    
                    myUser = GraphClass.init(graphclassresponse: myResponse!)
                    print("status = ",myUser?.status as Any)
                    print(myUser?.status as Any)
                    
                    if myUser?.status == "Succeed"{
                        self.volumeArray.removeAll()
                        self.highArray.removeAll()
                        self.lowArray.removeAll()
                        self.openArray.removeAll()
                        self.timeArray.removeAll()
                        self.tradeTrypeArray.removeAll()
                        self.timeArray0.removeAll()
                        self.timeArray1.removeAll()
                        //self.volumeArray0.removeAll()
                        //self.volumeArray1.removeAll()
                        
                        print("status = ",myUser?.graphdataclass.count as Any)
                        print("status = ",myUser?.graphdataclass as Any)
                        if let graphDataArray = myUser?.graphdataclass{
                            /*if graphDataArray.count > 98{
                                for i in 0..<98{
                                
                                    let volume = graphDataArray[i].volume
                                    self.volumeArray.append(Double(volume)!)
                                    let high = graphDataArray[i].high
                                    self.highArray.append(Double(high)!)
                                    let low = graphDataArray[i].low
                                    self.lowArray.append(Double(low)!)
                                    let ticker = graphDataArray[i].ticker
                                    self.timeArray.append(ticker)
                                    let openPrice = graphDataArray[i].open
                                    self.openArray.append(Double(openPrice)!)
                                    let tradetype = graphDataArray[i].tradetype
                                    self.tradeTrypeArray.append(tradetype)
                                    let array = ticker.components(separatedBy:" " )
                                    self.timeArray0.append(array[0])
                                    let arrayNew = array[1].components(separatedBy: ":")
                                    let timee = arrayNew[0] + ":" + arrayNew[1]
                                    self.timeArray1.append(timee)
                                }
                            }
                            else if graphDataArray.count == 98{
                                for i in 0..<graphDataArray.count{
                                    
                                    let volume = graphDataArray[i].volume
                                    self.volumeArray.append(Double(volume)!)
                                    let high = graphDataArray[i].high
                                    self.highArray.append(Double(high)!)
                                    let low = graphDataArray[i].low
                                    self.lowArray.append(Double(low)!)
                                    let ticker = graphDataArray[i].ticker
                                    self.timeArray.append(ticker)
                                    let openPrice = graphDataArray[i].open
                                    self.openArray.append(Double(openPrice)!)
                                    let tradetype = graphDataArray[i].tradetype
                                    self.tradeTrypeArray.append(tradetype)
                                    let array = ticker.components(separatedBy:" " )
                                    self.timeArray0.append(array[0])
                                    let arrayNew = array[1].components(separatedBy: ":")
                                    let timee = arrayNew[0] + ":" + arrayNew[1]
                                    self.timeArray1.append(timee)
                                }
                            }*/
                            //else
                            //{
                            
                                for i in 0..<graphDataArray.count{
                                    
                                    let volume = graphDataArray[i].volume
                                    self.volumeArray.append(Double(volume)!)
                                    let high = graphDataArray[i].high
                                    self.highArray.append(Double(high)!)
                                    let low = graphDataArray[i].low
                                    self.lowArray.append(Double(low)!)
                                    let ticker = graphDataArray[i].ticker
                                    self.timeArray.append(ticker)
                                    let openPrice = graphDataArray[i].open
                                    self.openArray.append(Double(openPrice)!)
                                    let tradetype = graphDataArray[i].tradetype
                                    self.tradeTrypeArray.append(tradetype)
                                    let array = ticker.components(separatedBy:" " )
                                    self.timeArray0.append(array[0])
                                    let arrayNew = array[1].components(separatedBy: ":")
                                    let timee = arrayNew[0] + ":" + arrayNew[1]
                                    self.timeArray1.append(timee)
                                }
                                /*for j in graphDataArray.count..<98{
                                    
                                    self.volumeArray.append(100)
                                    
                                    self.highArray.append(0.00000000)
                                    
                                    self.lowArray.append(0.00000000)
                                    
                                    self.timeArray.append("")
                                    
                                    self.openArray.append(0.00000000)
                                    
                                    self.tradeTrypeArray.append("0")
                                    
                                    self.timeArray0.append("")
                                    
                                    self.timeArray1.append("")
                                }*/
                            //}
                           // self.scrollViewBar.contentSize = CGSize(width: CGFloat(graphDataArray.count)*10, height: self.scrollViewBar.frame.size.height)
                        }
                        
                        
                        /*if (myUser?.graphdataclass.count)! == 50{
                            if let graphDataArray0 = myUser?.graphdataclass0{
                                for i in 0..<graphDataArray0.count{
                                    self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                }
                            }
                            if let graphDataArray1 = myUser?.graphdataclass1{
                                for i in 0..<graphDataArray1.count{
                                    self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                }
                            }
                        }
                        if (myUser?.graphdataclass.count)! > 50{
                            if let graphDataArray0 = myUser?.graphdataclass0{
                                if graphDataArray0.count > 50{
                                    for i in 0..<70{
                                        self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                    }
                                }
                                else{
                                    for i in 0..<graphDataArray0.count{
                                        self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                    }
                                }
                            }
                            if let graphDataArray1 = myUser?.graphdataclass1{
                                if graphDataArray1.count > 50{
                                    for i in 0..<70{
                                        self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                    }
                                }
                                else{
                                    for i in 0..<graphDataArray1.count{
                                        self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                    }
                                }
                            }
                        }
                        if (myUser?.graphdataclass.count)! < 50{
                            if let graphDataArray0 = myUser?.graphdataclass0{
                                for i in 0..<graphDataArray0.count{
                                    self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                }
                            }
                            if let graphDataArray1 = myUser?.graphdataclass1{
                                for i in 0..<graphDataArray1.count{
                                    self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                }
                            }
                            for i in (myUser?.graphdataclass0.count)! + (myUser?.graphdataclass1.count)!..<50{
                                self.volumeArray0.append(0)
                            }
                        }
                        else
                        {
                            
                        }*/
                        self.setChart(xValues: self.months, yValuesLineChart:  self.openArray, yValuesBarChart: self.volumeArray, yValuesBarChart0: self.volumeArray0, yValuesBarChart1: self.volumeArray1)
                    }
                    else{
                        Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                    }
                }
            })
            {
                (failure)-> Void in
                POPMESSAGE.popmessage.NoInternetMessage()
            }
        }
    }
    
}

extension BuySellVC{
    
    private func GraphGetApiHItBar(){
        var myResponse : JSON? = nil
        var myUser : GraphClass? = nil
        
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
            
            
            ApiManager.sharedInstance.fetchResponseFromUrl_getWithtwoParam(urlStr: BarGraphData_URL, viewController: self, paramvalue1: self.marketid, paramname1: "marketid", paramvalue2: self.timeParam, paramname2: "history", loadercheck: 1, onCompletion: { (GraphDataJson) ->Void in
                myResponse = GraphDataJson
                print(" Graph Data is ",myResponse!)
                DispatchQueue.main.async {
                    print("This is run on the main queue, after the previous code in outer block")
                    
                    myUser = GraphClass.init(graphclassresponse: myResponse!)
                    print("status = ",myUser?.status as Any)
                    print(myUser?.status as Any)
                    
                    if myUser?.status == "Succeed"{
                        self.volumeArray.removeAll()
                        //self.highArray.removeAll()
                        //self.lowArray.removeAll()
                        //self.openArray.removeAll()
                        //self.timeArray.removeAll()
                        //self.tradeTrypeArray.removeAll()
                        //self.timeArray0.removeAll()
                        //self.timeArray1.removeAll()
                        self.volumeArray0.removeAll()
                        self.volumeArray1.removeAll()
                        self.timeArray11.removeAll()
                        
                        print("status = ",myUser?.graphdataclass.count as Any)
                        print("status = ",myUser?.graphdataclass as Any)
                        if let graphDataArray = myUser?.graphdataclass{
                            /*if graphDataArray.count > 98{
                             for i in 0..<98{
                             
                             let volume = graphDataArray[i].volume
                             self.volumeArray.append(Double(volume)!)
                             let high = graphDataArray[i].high
                             self.highArray.append(Double(high)!)
                             let low = graphDataArray[i].low
                             self.lowArray.append(Double(low)!)
                             let ticker = graphDataArray[i].ticker
                             self.timeArray.append(ticker)
                             let openPrice = graphDataArray[i].open
                             self.openArray.append(Double(openPrice)!)
                             let tradetype = graphDataArray[i].tradetype
                             self.tradeTrypeArray.append(tradetype)
                             let array = ticker.components(separatedBy:" " )
                             self.timeArray0.append(array[0])
                             let arrayNew = array[1].components(separatedBy: ":")
                             let timee = arrayNew[0] + ":" + arrayNew[1]
                             self.timeArray1.append(timee)
                             }
                             }
                             else if graphDataArray.count == 98{
                             for i in 0..<graphDataArray.count{
                             
                             let volume = graphDataArray[i].volume
                             self.volumeArray.append(Double(volume)!)
                             let high = graphDataArray[i].high
                             self.highArray.append(Double(high)!)
                             let low = graphDataArray[i].low
                             self.lowArray.append(Double(low)!)
                             let ticker = graphDataArray[i].ticker
                             self.timeArray.append(ticker)
                             let openPrice = graphDataArray[i].open
                             self.openArray.append(Double(openPrice)!)
                             let tradetype = graphDataArray[i].tradetype
                             self.tradeTrypeArray.append(tradetype)
                             let array = ticker.components(separatedBy:" " )
                             self.timeArray0.append(array[0])
                             let arrayNew = array[1].components(separatedBy: ":")
                             let timee = arrayNew[0] + ":" + arrayNew[1]
                             self.timeArray1.append(timee)
                             }
                             }*/
                            //else
                            //{
                            
                            for i in 0..<graphDataArray.count{
                                
                                /*let volume = graphDataArray[i].volume
                                self.volumeArray.append(Double(volume)!)
                                let high = graphDataArray[i].high
                                self.highArray.append(Double(high)!)
                                let low = graphDataArray[i].low
                                self.lowArray.append(Double(low)!)*/
                                let ticker = graphDataArray[i].ticker
                                /*self.timeArray.append(ticker)
                                let openPrice = graphDataArray[i].open
                                self.openArray.append(Double(openPrice)!)
                                let tradetype = graphDataArray[i].tradetype
                                self.tradeTrypeArray.append(tradetype)*/
                                if ticker != ""{
                                    let array = ticker.components(separatedBy:" " )
                                    //self.timeArray0.append(array[0])
                                    let arrayNew = array[1].components(separatedBy: ":")
                                    let timee = arrayNew[0] + ":" + arrayNew[1]
                                    self.timeArray11.append(timee)
                                }
                                else
                                {
                                    self.timeArray11.append("")
                                }
                            }
                            /*for j in graphDataArray.count..<98{
                             
                             self.volumeArray.append(100)
                             
                             self.highArray.append(0.00000000)
                             
                             self.lowArray.append(0.00000000)
                             
                             self.timeArray.append("")
                             
                             self.openArray.append(0.00000000)
                             
                             self.tradeTrypeArray.append("0")
                             
                             self.timeArray0.append("")
                             
                             self.timeArray1.append("")
                             }*/
                            //}
                            //self.barChartWidthConstraint.constant = CGFloat(graphDataArray.count*5)
                            
                            //self.scrollViewBar.contentSize = CGSize(width: CGFloat(graphDataArray.count)*10, height: self.scrollViewBar.frame.size.height)
                        }
                        
                        /*if let graphDataArray0 = myUser?.graphdataclass0{
                            for i in 0..<graphDataArray0.count{
                                self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                            }
                        }
                        if let graphDataArray1 = myUser?.graphdataclass1{
                            for i in 0..<graphDataArray1.count{
                                self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                            }
                        }*/
                        if (myUser?.graphdataclass.count)! == 65{
                            if let graphDataArray0 = myUser?.graphdataclass0{
                                for i in 0..<graphDataArray0.count{
                                    self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                }
                            }
                            if let graphDataArray1 = myUser?.graphdataclass1{
                                for i in 0..<graphDataArray1.count{
                                    self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                }
                            }
                        }
                        if (myUser?.graphdataclass.count)! > 65{
                            if let graphDataArray0 = myUser?.graphdataclass0{
                                if graphDataArray0.count > 65{
                                    for i in 0..<65{
                                        self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                    }
                                }
                                else{
                                    for i in 0..<graphDataArray0.count{
                                        self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                    }
                                }
                            }
                            if let graphDataArray1 = myUser?.graphdataclass1{
                                if graphDataArray1.count > 65{
                                    for i in 0..<65{
                                        self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                    }
                                }
                                else{
                                    for i in 0..<graphDataArray1.count{
                                        self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                    }
                                }
                            }
                        }
                        if (myUser?.graphdataclass.count)! < 65{
                            if let graphDataArray0 = myUser?.graphdataclass0{
                                for i in 0..<graphDataArray0.count{
                                    self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                }
                            }
                            if let graphDataArray1 = myUser?.graphdataclass1{
                                for i in 0..<graphDataArray1.count{
                                    self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                }
                            }
                            for i in (myUser?.graphdataclass0.count)! + (myUser?.graphdataclass1.count)!..<65{
                                self.volumeArray0.append(0)
                            }
                        }
                        else
                        {
                            
                        }
                        self.setChart(xValues: self.months, yValuesLineChart:  self.openArray, yValuesBarChart: self.volumeArray, yValuesBarChart0: self.volumeArray0, yValuesBarChart1: self.volumeArray1)
                    }
                    else{
                        Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                    }
                }
            })
            {
                (failure)-> Void in
                POPMESSAGE.popmessage.NoInternetMessage()
            }
        }
    }
    
}
