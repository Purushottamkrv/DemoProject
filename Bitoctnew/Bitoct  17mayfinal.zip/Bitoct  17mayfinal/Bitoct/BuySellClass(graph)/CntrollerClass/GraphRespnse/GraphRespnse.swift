//
//  GraphRespnse.swift
//  Bitoct
//
//  Created by apple on 5/15/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GraphClass {
    
    var status = String()
    var Message = String()
    var graphdatajson:JSON?
    var graphdataclass:[GraphDataClass] = []
    var graphdataclass0:[GraphDataClass0] = []
    var graphdataclass1:[GraphDataClass1] = []
    
    init(graphclassresponse:JSON) {
        self.status = graphclassresponse["status"].stringValue
        self.Message = graphclassresponse["Message"].stringValue
        self.graphdatajson = graphclassresponse["Data"]
        
        if let graphdatajson = self.graphdatajson{
            for i in 0..<graphdatajson.count{
                let datasingle = GraphDataClass.init(graphdataesponse: graphdatajson[i])
                self.graphdataclass.append(datasingle)
                if graphdatajson[i]["tradetype"].stringValue == "0"
                {
                    let datasingle = GraphDataClass0.init(graphdataesponse: graphdatajson[i])
                    self.graphdataclass0.append(datasingle)
                }
                else
                {
                    let datasingle = GraphDataClass1.init(graphdataesponse: graphdatajson[i])
                    self.graphdataclass1.append(datasingle)
                }
            }
        }
    }
}
class GraphDataClass{
    var volume = String()
    var ticker = String()
    var average = String()
    
    var high = String()
    var low = String()
    var close = String()
    var tradetype = String()
    var open = String()
    
    init(graphdataesponse:JSON) {
        self.volume = graphdataesponse["volume"].stringValue
        self.ticker = graphdataesponse["ticker"].stringValue
        self.average = graphdataesponse["average"].stringValue
        self.high = graphdataesponse["high"].stringValue
        self.low = graphdataesponse["low"].stringValue
        self.close = graphdataesponse["close"].stringValue
        self.open = graphdataesponse["open"].stringValue
        self.tradetype = graphdataesponse["tradetype"].stringValue
    }
    
}
class GraphDataClass0 {
    var volume = String()
    var ticker = String()
    var average = String()
    
    var high = String()
    var low = String()
    var close = String()
    var tradetype = String()
    var open = String()
    
    init(graphdataesponse:JSON) {
        self.volume = graphdataesponse["volume"].stringValue
        self.ticker = graphdataesponse["ticker"].stringValue
        self.average = graphdataesponse["average"].stringValue
        self.high = graphdataesponse["high"].stringValue
        self.low = graphdataesponse["low"].stringValue
        self.close = graphdataesponse["close"].stringValue
        self.open = graphdataesponse["open"].stringValue
        self.tradetype = graphdataesponse["tradetype"].stringValue
    }
    
}

class GraphDataClass1 {
    var volume = String()
    var ticker = String()
    var average = String()
    
    var high = String()
    var low = String()
    var close = String()
    var tradetype = String()
    var open = String()
    
    init(graphdataesponse:JSON) {
        self.volume = graphdataesponse["volume"].stringValue
        self.ticker = graphdataesponse["ticker"].stringValue
        self.average = graphdataesponse["average"].stringValue
        self.high = graphdataesponse["high"].stringValue
        self.low = graphdataesponse["low"].stringValue
        self.close = graphdataesponse["close"].stringValue
        self.open = graphdataesponse["open"].stringValue
        self.tradetype = graphdataesponse["tradetype"].stringValue
    }
    
}
