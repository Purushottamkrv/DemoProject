//
//  String.swift
//  Bitoct
//
//  Created by apple on 5/18/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
extension String{
    subscript (i: Int) -> Character{
        return self[self.index(self.startIndex, offsetBy: i)]
    }
    subscript (i: Int) -> String{
        return String(self[i] as Character)
    }
    subscript (r: Range<Int>) -> String{
        let fromIndex = self.index(self.startIndex, offsetBy: r.lowerBound)
        let toIndex = self.index(self.startIndex, offsetBy: r.upperBound)
        return self.substring(with: Range<String.Index>(uncheckedBounds: (lower: fromIndex,upper: toIndex)))
    }
}
