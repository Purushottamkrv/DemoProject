//
//  MarketResponse.swift
//  Bitoct
//
//  Created by Purushottam on 30/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class MarketMainClass {
    
    var status = String()
    var Message = String()
    var  marketdatajson:JSON?
    var marketdataclass:[MarketDataClass] = []
    
    init(marketmainclassjson:JSON) {
        self.status = marketmainclassjson["status"].stringValue
        self.Message = marketmainclassjson["Message"].stringValue
        
        self.marketdatajson = marketmainclassjson["Data"]
        
        if let MarketDataArray = self.marketdatajson{
            for i in 0..<MarketDataArray.count{
                let datasingle = MarketDataClass.init(marketdatajson: MarketDataArray[i])
                self.marketdataclass.append(datasingle)
            }
        }
    }
}

class MarketDataClass {
    var tradetype = String()
    var price = String()
    var volume = String()
    
    var btcvalue = String()
    var tickerid = String()
    var ticker = String()
    
    var basecurrency = String()
    var basevolume = String()
    
    
    
    
    
    init(marketdatajson:JSON) {
        self.tradetype = marketdatajson["tradetype"].stringValue
        self.price = marketdatajson["price"].stringValue
        self.volume = marketdatajson["volume"].stringValue
        
        self.btcvalue = marketdatajson["btcvalue"].stringValue
        self.tickerid = marketdatajson["tickerid"].stringValue
        self.ticker = marketdatajson["ticker"].stringValue
        
        self.basecurrency = marketdatajson["basecurrency"].stringValue
        self.basevolume = marketdatajson["basevolume"].stringValue
        
        
        
        
        
    }
    
    
    
}




