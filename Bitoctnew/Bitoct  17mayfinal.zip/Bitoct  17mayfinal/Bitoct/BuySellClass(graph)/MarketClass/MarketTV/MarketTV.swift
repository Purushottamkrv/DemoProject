//
//  MarketTV.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class MarketTV: UITableView,UITableViewDelegate,UITableViewDataSource {
    
        var markettablearray = [MarketDataClass](){
            didSet{
                reloadData()
            }
        }
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return markettablearray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BuysellOpenTvCell", for: indexPath) as! BuysellOpenTvCell
        cell.main_view.backgroundColor = UIColor .black
        
//        cell.market_lbl.titleLabel?.text = markettablearray[indexPath.row].volume
//        cell.price_lbl.titleLabel?.text = markettablearray[indexPath.row].volume
//

        let str1 = markettablearray[indexPath.row].ticker
        let myStringArr = str1.components(separatedBy: " ")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        cell.time_btnoutlet.setTitle(myStringSecond, for: .normal)
        
        let priceFloat = Float(markettablearray[indexPath.row].price)
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        numberFormatter.maximumFractionDigits = 6
        cell.price_btnoutlet.setTitle(numberFormatter.string(for: priceFloat), for: .normal)
        
        let amntFloat = Float(markettablearray[indexPath.row].volume)
        let numberFormatterr = NumberFormatter()
        numberFormatterr.numberStyle = .decimal
        numberFormatterr.maximumFractionDigits = 3
        cell.volume_btnoutlet.setTitle(numberFormatterr.string(for: amntFloat), for: .normal)
        
        cell.time_btnoutlet.setTitleColor(UIColor .white, for: .normal)
        cell.price_btnoutlet.setTitleColor(UIColor .green, for: .normal)
        cell.volume_btnoutlet.setTitleColor(UIColor .white, for: .normal)
        return cell
        
    }

}
