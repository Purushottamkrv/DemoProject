//
//  MarketVC.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class MarketVC: UIViewController {
    
    @IBOutlet weak var market_tableview:MarketTV!
    var gatetmarketid = String()
    var timerMarket = Timer()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("market is in marketvc", gatetmarketid)
        
        self .MarketApiHIt()
        
        market_tableview.register(UINib(nibName: "BuysellOpenTvCell", bundle: nil), forCellReuseIdentifier: "BuysellOpenTvCell")
        
        //timerMarket = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerMarket = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerMarket.invalidate()
    }
    @objc func updateData()
    {
        self .MarketApiHIt()
    }
}



extension MarketVC{
    
    
    private func MarketApiHIt(){
        var myResponse : JSON? = nil
        var myUser : MarketMainClass? = nil
        var url = String()
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
            if self.gatetmarketid.contains("&live=1") {
            url = GetTradeHistoryByAMrket_LiveURL
        }
        else{
            url = GetTradeHistoryByAMrket_URL
        }
        
            ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:url, viewController: self,paramvalue: self.gatetmarketid,paramname: "marketid", loadercheck: 5, onCompletion: { (Pairjson) ->Void in
            myResponse = Pairjson
            print(" MARKEt DATA API IS",myResponse!)
                DispatchQueue.main.async {
                    print("This is run on the main queue, after the previous code in outer block")
               
                    myUser = MarketMainClass.init(marketmainclassjson: myResponse!)
                    print("status = ",myUser?.status as Any)
                    print(myUser?.status as Any)
            
                    if myUser?.status == "Succeed"{
                
                        self.market_tableview.markettablearray = (myUser?.marketdataclass)!
                    }
                    else{
                        Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                    }
                }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
    
}

