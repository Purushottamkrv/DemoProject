//
//  OrderTv.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class OrderTv: UITableView,UITableViewDelegate,UITableViewDataSource {
    var ordertablearray = [BuySellDataClass]()
    {
        didSet{
            reloadData()
        }
    }
    
    
        var marketid = String()
    
    
    
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ordertablearray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrderTvCommoncell", for: indexPath) as! OrderTvCommoncell
        
        let priceFloat = Float(ordertablearray[indexPath.row].price)
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        numberFormatter.maximumFractionDigits = 6
        cell.price_lbl.text = numberFormatter.string(for: priceFloat)!
        
        let amntFloat = Float(ordertablearray[indexPath.row].amount)
        let numberFormatterr = NumberFormatter()
        numberFormatterr.numberStyle = .decimal
        numberFormatterr.maximumFractionDigits = 3
        cell.amountl_lbl.text = numberFormatterr.string(for: amntFloat)!
        
       
        return cell
    }


}
