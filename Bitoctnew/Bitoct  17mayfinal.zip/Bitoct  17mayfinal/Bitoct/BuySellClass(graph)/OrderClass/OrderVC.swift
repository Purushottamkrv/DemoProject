//
//  OrderVC.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class OrderVC: UIViewController {
    
    var marketid = String()

    @IBOutlet weak var order_tableview: OrderTv!
    @IBOutlet weak var order_tableviewsecond: OrderTVSecond!
    var timerOrder = Timer()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.OrderApiHIt()
        self.OrderApiHItsecond()
        print("market id is in order vc ",marketid)
        
        order_tableview.register(UINib(nibName: "OrderTvCommoncell", bundle: nil), forCellReuseIdentifier: "OrderTvCommoncell")
        
        order_tableviewsecond.register(UINib(nibName: "OrderTvSecondcell", bundle: nil), forCellReuseIdentifier: "OrderTvSecondcell")
        
        //timerOrder = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerOrder = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerOrder.invalidate()
    }
    @objc func updateData()
    {
        self.OrderApiHIt()
        self.OrderApiHItsecond()
    }

}

extension OrderVC{
        private func OrderApiHIt(){
        var myResponse : JSON? = nil
        var myUser : BuySellMainClass? = nil
        DispatchQueue.global(qos: .background).async {
                print("This is run on the background queue")
          
        var url = String()
                if self.marketid.contains("&live=1") {
            url = BuyOrderBuymarket_LiveURL
        }
        else{
            url = BuyOrderBuymarket_URL
        }
                ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:url, viewController: self,paramvalue: self.marketid,paramname: "marketid", loadercheck: 5, onCompletion: { (Pairjson) ->Void in
            myResponse = Pairjson
            print(" BU DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
                myUser = BuySellMainClass.init(buysellmainclassresponse: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
            
                if myUser?.status == "Succeed"{
                
                    self.order_tableview.ordertablearray = (myUser?.buysellddataclass)!
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
    }
    
}

extension OrderVC{
    private func OrderApiHItsecond(){
        var myResponse : JSON? = nil
        var myUser : BuySellMainClass? = nil
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
        var url = String()
            if self.marketid.contains("&live=1") {
            url = SellOrdeByMarket_LiveURL
        }
        else{
            url = SellOrderByMarket_URL
        }
            ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:url, viewController: self,paramvalue: self.marketid,paramname: "marketid", loadercheck: 5, onCompletion: { (Pairjson) ->Void in
            myResponse = Pairjson
            print(" BU DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
                myUser = BuySellMainClass.init(buysellmainclassresponse: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
            
                if myUser?.status == "Succeed"{
                
                    //self.order_tableview.ordertablearray = (myUser?.buysellddataclass)!
                
                    self.order_tableviewsecond.ordersecondarray = (myUser?.buysellddataclass)!
                }
                else{
                        Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
    
}

