//
//  BuySellresponse.swift
//  Bitoct
//
//  Created by Purushottam on 30/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation

import SwiftyJSON
import Alamofire

class BuySellMainClass {
    
    var status = String()
    var Message = String()
    var buyselldatajson:JSON?
    var buysellddataclass:[BuySellDataClass] = []
    
    init(buysellmainclassresponse:JSON) {
        self.status = buysellmainclassresponse["status"].stringValue
        self.Message = buysellmainclassresponse["Message"].stringValue
        self.buyselldatajson = buysellmainclassresponse["Data"]
        
        if let BuySellDataArray = self.buyselldatajson{
            for i in 0..<BuySellDataArray.count{
                let datasingle = BuySellDataClass.init(buyselldataesponse: BuySellDataArray[i])
                self.buysellddataclass.append(datasingle)
            }
        }
    }
}

class BuySellDataClass {
    var price = String()
    var amount = String()
    var total = String()
    
    var basevalue = String()
    var rowtotalbase = String()
    var totalBase = String()
    
    var totalCurr = String()
    
    init(buyselldataesponse:JSON) {
        self.price = buyselldataesponse["price"].stringValue
        self.amount = buyselldataesponse["amount"].stringValue
        self.total = buyselldataesponse["total"].stringValue
        
        self.basevalue = buyselldataesponse["basevalue"].stringValue
        self.rowtotalbase = buyselldataesponse["rowtotalbase"].stringValue
        self.totalBase = buyselldataesponse["totalBase"].stringValue
        self.totalCurr = buyselldataesponse["totalCurr"].stringValue

    }

}




