//
//  ChangePasswordVC.swift
//  Bitoct
//
//  Created by Purushottam on 09/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ChangePasswordVC: UIViewController {
    @IBOutlet weak var oldpassword_txt: UITextField!
    
    @IBOutlet weak var newpassword_txt: UITextField!
    @IBOutlet weak var confirmpassword_txt: UITextField!
    @IBOutlet weak var discription_lbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        oldpassword_txt.attributedPlaceholder = NSAttributedString(string: "   Enter old password", attributes: [NSAttributedStringKey.foregroundColor:UIColor.gray])
       newpassword_txt.attributedPlaceholder = NSAttributedString(string: "   Enter new password", attributes: [NSAttributedStringKey.foregroundColor:UIColor.gray])
        confirmpassword_txt.attributedPlaceholder = NSAttributedString(string: "   Enter new password agian", attributes: [NSAttributedStringKey.foregroundColor:UIColor.gray])
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
      
    }
  
    @IBAction func back_btnacn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func submit_btnacn(_ sender: Any) {
        ChangepsswordApi()
    }
}

extension ChangePasswordVC{
    
    func ChangepsswordApi() {
        var myResponse : JSON? = nil
        var myUser : REGISTER? = nil
        let memberid = UserDefaults.standard.string(forKey: "USERID")
        
        let para : [String:String] = ["MemberId":memberid!, "newPassword":newpassword_txt.text!  ,"oldPassword":oldpassword_txt.text!]
        ApiManager.sharedInstance.fetchResponseFromUrl(urlStr:ChangePassword_URL, paraMeters: para,viewController: self, loadercheck: 6, onCompletion: { (changepasswordjson) ->Void in
            myResponse = changepasswordjson
            myUser = REGISTER(registerjson:myResponse!)
            print("REGISTER  API IS",myResponse!)
            print("message = ",myUser?.Message as Any)
            print(myUser?.status as Any)
            
            if myUser?.status == "Succeed"{
                Alert.showBasic(title: "", message: (myUser?.Message)!, viewController: self)
            }
            else{
                Alert.showBasic(title: "", message: (myUser?.Message)!, viewController: self)
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
    
    
    
}
