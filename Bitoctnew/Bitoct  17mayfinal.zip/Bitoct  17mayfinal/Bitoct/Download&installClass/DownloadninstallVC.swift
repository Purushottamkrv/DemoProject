//
//  DownloadninstallVC.swift
//  Bitoct
//
//  Created by Purushottam on 09/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class DownloadninstallVC: UIViewController {

    @IBOutlet weak var google_view: UIView!
    @IBOutlet weak var google_imageview: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        google_view.layer.cornerRadius = google_view.frame.size.height/2
        google_view.layer.masksToBounds = true
        google_view.clipsToBounds = true

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func back_btnacn(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func next_btnacn(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "BackupkeyVC") as! BackupkeyVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
