//
//  EnterdigitVC.swift
//  Bitoct
//
//  Created by Purushottam on 09/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class EnterdigitVC: UIViewController {

    @IBOutlet weak var digit_txt: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func back_btnacn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func next_btnacn(_ sender: Any) {
    }
}
