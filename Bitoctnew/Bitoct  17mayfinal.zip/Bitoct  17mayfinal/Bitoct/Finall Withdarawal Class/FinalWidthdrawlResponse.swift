//
//  FinalWidthdrawlResponse.swift
//  Bitoct
//
//  Created by Purushottam on 04/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class FinalWithdrawlMainClass {
    
    var status = String()
    var Message = String()
    
    var finalwithrawldataclass :[FinalWithrawlDataClass] = []
    var finalwithdrawldatajson:JSON?
    
    init(finalwithdrawlmainclassjson:JSON) {
        self.status = finalwithdrawlmainclassjson["status"].stringValue
        self.Message = finalwithdrawlmainclassjson["Message"].stringValue
        self.finalwithdrawldatajson = finalwithdrawlmainclassjson["Data"]
        
        if let finalwithdrawldatajson = self.finalwithdrawldatajson{
            for i in 0..<finalwithdrawldatajson.count{
                
                let datasingle = FinalWithrawlDataClass.init(finalwithdrawdataclassjson: finalwithdrawldatajson[i])
                finalwithrawldataclass.append(datasingle)
            }
        }
    }
}

class FinalWithrawlDataClass {
    var toTxfee = String()
    var withdrawleft = String()
    var sptoday = String()
    var CurrencyBalance = String()
    var maxAmount = String()
    
    init(finalwithdrawdataclassjson:JSON) {
        
        self.toTxfee = finalwithdrawdataclassjson["toTxfee"].stringValue
        self.withdrawleft = finalwithdrawdataclassjson["withdrawleft"].stringValue
        self.sptoday = finalwithdrawdataclassjson["sptoday"].stringValue
        self.CurrencyBalance = finalwithdrawdataclassjson["CurrencyBalance"].stringValue
        self.maxAmount = finalwithdrawdataclassjson["maxAmount"].stringValue
        
    }
    
}
