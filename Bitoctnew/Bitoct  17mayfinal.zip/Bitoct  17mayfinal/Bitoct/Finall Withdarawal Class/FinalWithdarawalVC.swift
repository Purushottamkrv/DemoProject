//
//  FinalWithdarawalVC.swift
//  Bitoct
//
//  Created by Purushottam on 04/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import  SDWebImage
import SwiftyJSON
import Alamofire

class FinalWithdarawalVC: UIViewController,UITextFieldDelegate {
    
    var picturestr = String()
    var coinstr = String()
    var withdrawStr = String()
    var recieveStr = String()
    var feeStr  = String()
    var myUser : FinalWithdrawlMainClass? = nil
    @IBOutlet weak var picture_imageview: UIImageView!
    @IBOutlet weak var coin_lbl: UILabel!
    @IBOutlet weak var availablelbalance_lbl: UILabel!
    @IBOutlet weak var coin_lbl1: UILabel!
    @IBOutlet weak var feevalue_lbl: UILabel!
    @IBOutlet weak var receiveamountvalue_lbl: UILabel!
    
    @IBOutlet weak var withdrawamount_txt: UITextField!
    @IBOutlet weak var withdarawaladress_txt: UITextField!
    
    @IBOutlet weak var pincode_txt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        picture_imageview.sd_setImage(with: URL(string:picturestr), completed: nil)
        coin_lbl.text = coinstr
        coin_lbl1.text = coinstr
        withdrawamount_txt.delegate = self
        print("coin name is",coinstr)
        FinalWithdrawlDetailsApi()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func back_btnacn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func withdrawalbtn_acn(_ sender: Any) {
        FinalWithdrawlActionApi()
    }
    
    

}
extension FinalWithdarawalVC{
    
    private func FinalWithdrawlDetailsApi(){
        var myResponse : JSON? = nil
        
        let memberid = UserDefaults.standard.string(forKey: "USERID")
        
        ApiManager.sharedInstance.fetchResponseFromUrl_getWithtwoParam(urlStr:GetWithdrawlDetail_URL, viewController: self,paramvalue1: self.coin_lbl.text!,paramname1: "currency", paramvalue2: memberid!, paramname2: "MemberId", loadercheck: 5, onCompletion: { (fundsbalancejson) ->Void in
            
            myResponse = fundsbalancejson
            
            print("Deposite Address Response= ",myResponse!)
            self.myUser = FinalWithdrawlMainClass.init(finalwithdrawlmainclassjson: myResponse!)
            print("status = ",self.myUser?.status as Any)
            print(self.myUser?.status as Any)
            if self.myUser?.status == "Succeed"{
                
                if let finalwithdrawldataArray = self.myUser?.finalwithrawldataclass
                {
                    for i in 0..<finalwithdrawldataArray.count
                    {
                        self.coin_lbl1.text = finalwithdrawldataArray[i].maxAmount + self.coin_lbl1.text!
                        self.feeStr = finalwithdrawldataArray[i].toTxfee
                        self.feevalue_lbl.text = finalwithdrawldataArray[i].toTxfee + self.coin_lbl1.text!
                    
                    }
                }
                
            }
            else{
                Alert.showBasic(title: "", message:(self.myUser?.Message)!, viewController: self)
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
}
extension FinalWithdarawalVC{
    
    private func FinalWithdrawlActionApi(){
        var myResponse : JSON? = nil
        var myUserr : FinalWithdrawlActionMainClass? = nil
        let memberid = UserDefaults.standard.string(forKey: "USERID")
        
        ApiManager.sharedInstance.fetchResponseFromUrl_getWithSixParams(urlStr:WidthdrawlAction_URL, viewController: self,paramvalue1: self.withdrawamount_txt.text!,paramname1: "toamount", paramvalue2: recieveStr, paramname2: "estimateAmount",paramvalue3: self.withdarawaladress_txt.text!,paramname3: "toaddress", paramvalue4: self.coin_lbl.text!, paramname4: "currency",paramvalue5: self.pincode_txt.text!,paramname5: "Pin", paramvalue6: memberid!, paramname6: "MemberId", loadercheck: 5, onCompletion: { (fundsbalancejson) ->Void in
            
            myResponse = fundsbalancejson
            
            print("Deposite Address Response= ",myResponse!)
            myUserr = FinalWithdrawlActionMainClass.init(finalwithdrawlmainclassjson: myResponse!)
            print("status = ",myUserr?.status as Any)
            print(myUserr?.status as Any)
            if myUserr?.status == "fail"{
                Alert.showBasic(title: "Alert", message:(myUserr!.Message), viewController: self)
            }
            else{
                Alert.showBasic(title: "Status", message:(myUserr!.Message), viewController: self)
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
}
extension FinalWithdarawalVC {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        withdrawStr = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        print("sell price string",string)
        print("sell price value",withdrawStr)
        if withdrawStr.count == 0
        {
            //self.totalamount_txt.text = ""
        }
        else
        {
            let total = (withdrawStr as NSString).floatValue - (self.feeStr as NSString).floatValue
            let numberFormatter = NumberFormatter()
            numberFormatter.numberStyle = .decimal
            numberFormatter.maximumFractionDigits = 8
            recieveStr = numberFormatter.string(for: total)!
            self.receiveamountvalue_lbl.text = recieveStr + coin_lbl1.text!
        }
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
    }
}
