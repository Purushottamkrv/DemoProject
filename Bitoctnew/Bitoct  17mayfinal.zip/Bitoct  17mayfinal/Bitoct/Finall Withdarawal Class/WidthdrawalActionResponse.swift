//
//  WidthdrawalActionResponse.swift
//  Bitoct
//
//  Created by Purushottam on 04/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class FinalWithdrawlActionMainClass {
    
    var status = String()
    var Message = String()
    
    
    init(finalwithdrawlmainclassjson:JSON) {
        self.status = finalwithdrawlmainclassjson["status"].stringValue
        self.Message = finalwithdrawlmainclassjson["Message"].stringValue

    }
}
