//
//  File.swift
//  Bitoct
//
//  Created by apple on 5/4/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class DepositeAddressMainClass {
    
    var status = String()
    var Message = String()
    
    var depositaddressdataclass :[DepositAddressDataClass] = []
    var depositdatajson:JSON?
    
    init(depositaddressmainclassjson:JSON) {
        self.status = depositaddressmainclassjson["status"].stringValue
        self.Message = depositaddressmainclassjson["Message"].stringValue
        self.depositdatajson = depositaddressmainclassjson["Data"]
        
        if let depositdatajson = self.depositdatajson{
            for i in 0..<depositdatajson.count{
                
                let datasingle = DepositAddressDataClass.init(depositaddressdataclassjson: depositdatajson[i])
                depositaddressdataclass.append(datasingle)
            }
        }
    }
}

class DepositAddressDataClass {
    var Address = String()
    var qr = String()
   
    init(depositaddressdataclassjson:JSON) {
        
        self.Address = depositaddressdataclassjson["Address"].stringValue
        self.qr = depositaddressdataclassjson["qr"].stringValue
        
    }
    
}
