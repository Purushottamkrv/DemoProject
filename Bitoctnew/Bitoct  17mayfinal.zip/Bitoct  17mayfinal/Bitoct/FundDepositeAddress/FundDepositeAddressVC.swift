//
//  FundDepositeAddressVC.swift
//  Bitoct
//
//  Created by apple on 5/4/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import SDWebImage

class FundDepositeAddressVC: UIViewController {

    var myUser : DepositeAddressMainClass? = nil
    @IBOutlet weak var addressCodeLabel: UILabel!
    @IBOutlet weak var coinAddressLabel: UILabel!
    @IBOutlet weak var coinLabel: UILabel!
    @IBOutlet weak var iconImgView: UIImageView!
    @IBOutlet weak var belowView: UIView!
    
    
    
    @IBOutlet weak var pop_mainview: UIView!
    @IBOutlet weak var cross_popview:UIView!
    
    @IBOutlet weak var popview1: UIView!
    @IBOutlet weak var qr_imageview: UIImageView!
    @IBOutlet weak var qrcode_lbl: UILabel!
    
    
    
    @IBOutlet weak var copy_btnoutlet: UIButton!
    @IBOutlet weak var saveimage_btnoutlet:UIButton!
    
    @IBOutlet weak var blur_btnoutlet:UIButton!
    
   // @IBOutlet weak var blur_btnoutlet:UIButton!
    @IBOutlet weak var title_lbl:UILabel!
    
    
    var coinStr = String()
    var coinImagStr = String()
    
    override func viewDidLoad() {
        
        
        
        pop_mainview.isHidden = true
        blur_btnoutlet.isHidden = true
        cross_popview.isHidden = true

        copy_btnoutlet.layer.borderColor = UIColor.lightGray.cgColor
        copy_btnoutlet.layer.borderWidth = 1
        saveimage_btnoutlet.layer.borderColor = UIColor.lightGray.cgColor
        saveimage_btnoutlet.layer.borderWidth = 1
        //popview1.layer.cornerRadius = popview1.layer.frame.size.height/2
        
        super.viewDidLoad()
        self.belowView.layer.cornerRadius = 5.0
        self.belowView.layer.shadowColor = UIColor.gray.cgColor
        self.belowView.layer.shadowOpacity = 0.5
        
        self.coinLabel.text = coinStr
        self.iconImgView.sd_setImage(with: URL(string:coinImagStr ), completed: nil)
        
        self.coinAddressLabel.text = coinStr + " Deposite" + " Address"
        
        DepositeAddressApiHit()
    }

    @IBAction func copyAddressAction(_ sender: Any) {
        UIPasteboard.general.string = self.addressCodeLabel.text
        print("Copied Text= ",UIPasteboard.general.string!)
    }
    
    @IBAction func qrCodeAction(_ sender: Any) {
        blur_btnoutlet.isHidden  = false
        pop_mainview.isHidden = false
        cross_popview.isHidden = false
        
        if let depositedataArray = self.myUser?.depositaddressdataclass
        {
            for i in 0..<depositedataArray.count
            {
                let imagedata = NSData(base64Encoded: depositedataArray[i].qr
                    , options: .ignoreUnknownCharacters)
                let image = UIImage(data: imagedata! as Data)
                self.qr_imageview.image = image
                self.qrcode_lbl.text = self.addressCodeLabel.text
                self.title_lbl.text = self.coinAddressLabel.text
            }
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backToDeposte(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func backToFundBalance(_ sender: Any) {
        let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
        tabVC.selectedIndex = 3
        self.navigationController?.pushViewController(tabVC, animated: true)
    }
    
    @IBAction func copy_btnacn(_ sender: Any) {
        UIPasteboard.general.string = self.qrcode_lbl.text
        print("Copied Text= ",UIPasteboard.general.string)
    }
    
    @IBAction func save_image_btnacn(_ sender: Any) {
    }
    
    @IBAction func blur_btnacn(_ sender: Any) {
        
        blur_btnoutlet.isHidden  = true
        pop_mainview.isHidden = true
        cross_popview.isHidden = true
    }
    
    @IBAction func cross_btnacn(_ sender: Any) {
        
        blur_btnoutlet.isHidden = true
        pop_mainview.isHidden = true
        cross_popview.isHidden = true
    }
    
    
}

extension FundDepositeAddressVC{
    
    private func DepositeAddressApiHit(){
        var myResponse : JSON? = nil
        let memberid = UserDefaults.standard.string(forKey: "USERID")
        
        ApiManager.sharedInstance.fetchResponseFromUrl_getWithtwoParam(urlStr:GetDepositeAddress_URL, viewController: self,paramvalue1: coinStr,paramname1: "currency", paramvalue2: memberid!, paramname2: "MemberId", loadercheck: 5, onCompletion: { (fundsbalancejson) ->Void in
            
            myResponse = fundsbalancejson
            
            print("Deposite Address Response= ",myResponse!)
            self.myUser = DepositeAddressMainClass.init(depositaddressmainclassjson: myResponse!)
            print("status = ",self.myUser?.status as Any)
            print(self.myUser?.status as Any)
            if self.myUser?.status == "Succeed"{
                
                if let depositedataArray = self.myUser?.depositaddressdataclass
                {
                    for i in 0..<depositedataArray.count
                    {
                        self.addressCodeLabel.text = depositedataArray[i].Address
                    }
                }
                
            }
            else{
                Alert.showBasic(title: "", message:(self.myUser?.Message)!, viewController: self)
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
}
