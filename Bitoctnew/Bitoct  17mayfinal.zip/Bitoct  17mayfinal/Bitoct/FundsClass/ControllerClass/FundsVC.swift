//
//  FundsVC.swift
//  Bitoct
//
//  Created by Purushottam on 02/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SwiftyJSON

class FundsVC: UIViewController,UITableViewDataSource,UITableViewDelegate,PaasvalueProtocol {
    
    
    @IBOutlet weak var pop_mainview: UIView!
    
    @IBOutlet weak var popview1: UIView!
    @IBOutlet weak var popimageview1: UIImageView!
    @IBOutlet weak var description_lbl: UILabel!
    
    @IBOutlet weak var blur_btnoutlet: UIButton!
    @IBOutlet weak var googleauth_btnoutlet:UIButton!
    
    @IBOutlet weak var smsauth_btnoutlet:UIButton!

    var timerFundBalance = Timer()
    
    @IBOutlet weak var Fundsbalance_tableview: UITableView!
    var balancearray = [FundsDepositBalanceDataClass](){
        didSet{
            Fundsbalance_tableview.reloadData()
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
       // pop_mainview.isHidden = true
        //blur_btnoutlet.isHidden = true

        
        
//        googleauth_btnoutlet.layer.borderColor = UIColor.lightGray.cgColor
//        googleauth_btnoutlet.layer.borderWidth = 1
//        smsauth_btnoutlet.layer.borderColor = UIColor.lightGray.cgColor
//        smsauth_btnoutlet.layer.borderWidth = 1
//        popview1.layer.cornerRadius = popview1.layer.frame.size.height/2
        
        FundsBalanceApiHit()
        Fundsbalance_tableview.register(UINib(nibName: "FundsbalanceTvCell", bundle: nil), forCellReuseIdentifier: "FundsbalanceTvCell")

        //timerFundBalance = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerFundBalance = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerFundBalance.invalidate()
    }
    @objc func updateData()
    {
        self.FundsBalanceApiHit()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return balancearray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "FundsbalanceTvCell", for: indexPath) as! FundsbalanceTvCell
        cell.coin_lbl.text = balancearray[indexPath.row].Coin
        cell.coinname_lbl.text = "("+balancearray[indexPath.row].CoinName+")"
        cell.btcbalance_lbl.text = balancearray[indexPath.row].BTCBalance
        let picturestr = balancearray[indexPath.row].picture
        cell.picture_imageview.sd_setImage(with: URL(string:picturestr), completed: nil)
        return cell
    }
    @IBAction func back_btnacn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension FundsVC{
    
    @IBAction func withdraw_btnacn(_ sender: Any) {
       // blur_btnoutlet.isHidden = false
       // pop_mainview.isHidden = false
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "FundsWithdarawalVC") as! FundsWithdarawalVC
        
       // self.navigationController?.popToViewController(vc, animated: true)
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func History_btnacn(_ sender: Any) {
        let vc  = self.storyboard?.instantiateViewController(withIdentifier: "TaransactionHistoryVC") as! TaransactionHistoryVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func Deposit_btnacn(_ sender: Any) {
        let vc  = self.storyboard?.instantiateViewController(withIdentifier: "FundsDepositClassVC") as! FundsDepositClassVC
        vc.paasvaluedelegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
    
    @IBAction func blur_btnacn(_ sender: Any) {
        //blur_btnoutlet.isHidden = true
        //pop_mainview.isHidden = true
    }
    @IBAction func google_authbtnacn(_ sender: Any) {
    }
    @IBAction func smsauth_btnacn(_ sender: Any) {
    }
    
    
    
}


extension FundsVC{
    
        private func FundsBalanceApiHit(){
            var myResponse : JSON? = nil
            var myUser : FundsDepositBalanceMainClass? = nil
            let memberid = UserDefaults.standard.string(forKey: "USERID")
            DispatchQueue.global(qos: .background).async {
                print("This is run on the background queue")
            
            ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:BalanceCurrency_URL, viewController: self,paramvalue: memberid!,paramname: "Memberid", loadercheck: 1, onCompletion: { (fundsbalancejson) ->Void in
                myResponse = fundsbalancejson
                
                print(" FUNDS BALANCE DATA API IS",myResponse!)
                DispatchQueue.main.async {
                    print("This is run on the main queue, after the previous code in outer block")
                    myUser = FundsDepositBalanceMainClass.init(fundsdepositbalancemainclassjson: myResponse!)
                    print("status = ",myUser?.status as Any)
                    print(myUser?.status as Any)
                    if myUser?.status == "Succeed"{
                        self.balancearray = (myUser?.fundsdepositbalancedataclass)!
                    }
                    else{
                        Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                    }
                }
            })
            {
                (failure)-> Void in
                POPMESSAGE.popmessage.NoInternetMessage()
            }
            }
        }
    }

extension FundsVC{
    
    func value(id: String) {
        let str = id
        print("str is",str)
    }
    
}


