//
//  FundsbalanceTvCell.swift
//  Bitoct
//
//  Created by Purushottam on 03/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class FundsbalanceTvCell: UITableViewCell {
    
    
    @IBOutlet weak var picture_imageview: UIImageView!
    @IBOutlet weak var coin_lbl: UILabel!
    
    @IBOutlet weak var coinname_lbl: UILabel!
    @IBOutlet weak var btcbalance_lbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
