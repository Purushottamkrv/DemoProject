//
//  FundsDepositBalanceResponse.swift
//  Bitoct
//
//  Created by Purushottam on 04/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class FundsDepositBalanceMainClass {
    
    var status = String()
    var Message = String()
    
    var fundsdepositbalancedataclass :[FundsDepositBalanceDataClass] = []
    var fundsdepositdatajson:JSON?
    
    init(fundsdepositbalancemainclassjson:JSON) {
        self.status = fundsdepositbalancemainclassjson["status"].stringValue
        self.Message = fundsdepositbalancemainclassjson["Message"].stringValue
        self.fundsdepositdatajson = fundsdepositbalancemainclassjson["Data"]
        
        if let fundsdepositdataarray = self.fundsdepositdatajson{
            for i in 0..<fundsdepositdataarray.count{
                
                let datasingle = FundsDepositBalanceDataClass.init(fundsdepositbalancedataclassjson: fundsdepositdataarray[i])
                fundsdepositbalancedataclass.append(datasingle)
            }
        }
    }
}

class FundsDepositBalanceDataClass {
    var ID = String()
    var MarketID = String()
    var Coin = String()
    var CoinName = String()
    
    var picture = String()
    var BTCBalance = String()
    var  TradeBalace = String()
    var TotalBTC = String()
    
    init(fundsdepositbalancedataclassjson:JSON) {
        
        
        self.ID = fundsdepositbalancedataclassjson["ID"].stringValue
        self.MarketID = fundsdepositbalancedataclassjson["MarketID"].stringValue
        self.Coin = fundsdepositbalancedataclassjson["Coin"].stringValue
        self.CoinName = fundsdepositbalancedataclassjson["CoinName"].stringValue
        
        self.picture = fundsdepositbalancedataclassjson["picture"].stringValue
        self.BTCBalance = fundsdepositbalancedataclassjson["BTCBalance"].stringValue
        self.TradeBalace = fundsdepositbalancedataclassjson["TradeBalace"].stringValue
        self.TotalBTC = fundsdepositbalancedataclassjson["TotalBTC"].stringValue
        
    }
    
}

