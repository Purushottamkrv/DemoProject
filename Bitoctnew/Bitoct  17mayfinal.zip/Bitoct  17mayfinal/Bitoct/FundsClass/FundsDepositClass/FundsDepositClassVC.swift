//
//  FundsDepositClassVC.swift
//  Bitoct
//
//  Created by Purushottam on 03/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

import SwiftyJSON
import Alamofire
import SDWebImage

protocol PaasvalueProtocol {
    func value(id:String)
}

class FundsDepositClassVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var paasvaluedelegate:PaasvalueProtocol!
    var timerFundDeposite = Timer()
    var depositarray = [FundsDepositBalanceDataClass](){
        didSet{
            deposit_tableview .reloadData()
        }
    }
    @IBOutlet weak var deposit_tableview:UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        FundsDepositApiHit()
        
        deposit_tableview.register(UINib(nibName: "FundsbalanceTvCell", bundle: nil), forCellReuseIdentifier: "FundsbalanceTvCell")
        
        //timerFundDeposite = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerFundDeposite = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerFundDeposite.invalidate()
    }
    @objc func updateData()
    {
        self.FundsDepositApiHit()
    }
    @IBAction func back_btnacn(_ sender: Any) {
      self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return depositarray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FundsbalanceTvCell", for: indexPath) as! FundsbalanceTvCell
        
        cell.coin_lbl.text = depositarray[indexPath.row].Coin
        cell.coinname_lbl.text = "("+depositarray[indexPath.row].CoinName+")"
        
        cell.btcbalance_lbl.text = depositarray[indexPath.row].BTCBalance
        
        let picturestr = depositarray[indexPath.row].picture
        
        
        cell.picture_imageview.sd_setImage(with: URL(string:picturestr ), completed: nil)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //self.navigationController?.popViewController(animated: true)
        //paasvaluedelegate.value(id: depositarray[indexPath.row].BTCBalance)
        let vc  = self.storyboard?.instantiateViewController(withIdentifier: "FundDepositeAddressVC") as! FundDepositeAddressVC
        vc.coinStr = depositarray[indexPath.row].Coin
        vc.coinImagStr = depositarray[indexPath.row].picture
        //vc.paasvaluedelegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
extension FundsDepositClassVC{
    
    private func FundsDepositApiHit(){
        var myResponse : JSON? = nil
        var myUser : FundsDepositBalanceMainClass? = nil
        let memberid = UserDefaults.standard.string(forKey: "USERID")
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
        ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:BalanceCurrency_URL, viewController: self,paramvalue: memberid!,paramname: "MemberId", loadercheck: 1, onCompletion: { (fundsbalancejson) ->Void in
            
            myResponse = fundsbalancejson
            print(" FUNDS DEPOSIT DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
            
                myUser = FundsDepositBalanceMainClass.init(fundsdepositbalancemainclassjson: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
                if myUser?.status == "Succeed"{
                    self.depositarray = (myUser?.fundsdepositbalancedataclass)!
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
    
    
}
