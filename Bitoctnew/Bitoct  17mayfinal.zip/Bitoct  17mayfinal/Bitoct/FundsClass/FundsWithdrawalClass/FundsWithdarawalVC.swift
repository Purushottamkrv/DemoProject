//
//  FundsWithdarawalVC.swift
//  Bitoct
//
//  Created by Purushottam on 04/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

import SwiftyJSON
import Alamofire

import SDWebImage

class FundsWithdarawalVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    @IBOutlet weak var withdrawal_tableview:UITableView?
    var timerFund = Timer()
    
    var withdrawarray = [FundsDepositBalanceDataClass](){
        didSet{
            withdrawal_tableview?.reloadData()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        FundsWithdarawalApiHit()
        
        withdrawal_tableview?.register(UINib(nibName: "FundsbalanceTvCell", bundle: nil), forCellReuseIdentifier: "FundsbalanceTvCell")
        
        //timerFund = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerFund = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerFund.invalidate()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @objc func updateData()
    {
        self.FundsWithdarawalApiHit()
    }
    
    @IBAction func back_btnacn(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return withdrawarray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FundsbalanceTvCell", for: indexPath) as! FundsbalanceTvCell
        
        cell.coin_lbl.text = withdrawarray[indexPath.row].Coin
        cell.coinname_lbl.text = "("+withdrawarray[indexPath.row].CoinName+")"
        
        cell.btcbalance_lbl.text = withdrawarray[indexPath.row].BTCBalance
        
        let picturestr = withdrawarray[indexPath.row].picture
        
        
        cell.picture_imageview.sd_setImage(with: URL(string:picturestr ), completed: nil)
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "FinalWithdarawalVC") as! FinalWithdarawalVC
        
        self.navigationController?.pushViewController(vc, animated: true)
        
        vc.coinstr = withdrawarray[indexPath.row].Coin
        vc.picturestr = withdrawarray[indexPath.row].picture

    }


}

extension FundsWithdarawalVC{
    
    private func FundsWithdarawalApiHit(){
        var myResponse : JSON? = nil
        var myUser : FundsDepositBalanceMainClass? = nil
        let memberid = UserDefaults.standard.string(forKey: "USERID")
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
        
        ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:BalanceCurrency_URL, viewController: self,paramvalue: memberid!,paramname: "MemberId", loadercheck: 1, onCompletion: { (fundsbalancejson) ->Void in
            
            myResponse = fundsbalancejson
            print(" FUNDS DEPOSIT DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
            
                myUser = FundsDepositBalanceMainClass.init(fundsdepositbalancemainclassjson: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
                if myUser?.status == "Succeed"{
                    self.withdrawarray = (myUser?.fundsdepositbalancedataclass)!
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
    
}
