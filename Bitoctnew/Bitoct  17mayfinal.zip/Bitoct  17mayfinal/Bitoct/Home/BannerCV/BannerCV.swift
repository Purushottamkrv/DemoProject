//
//  BannerCV.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SDWebImage

class BannerCV: UICollectionView,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    var BanneimageArray = [BANNERIMAGEDATA](){
        didSet{
            reloadData()
        }
    }
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        super.init(frame: frame, collectionViewLayout: layout)
        self.delegate = self
        self.dataSource = self
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    func getpagecontrolr(viewcontroller:UIViewController)
    {
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return BanneimageArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "bannercell", for: indexPath) as! BannerCvCell
        
        let imgstr = self.BanneimageArray[indexPath.row].banner
        if imgstr != nil{
            //let imgStrNew = imgstr.addingPercentEncoding(
               // withAllowedCharaimgstr    String    "http://api.bitoct.in/uploads/header_five.jpg"    cters: CharacterSet.urlQueryAllowed)
            cell.banner_imageview.sd_setImage(with: URL(string: imgstr), completed: nil)
            
        }
        else{
            cell.banner_imageview.image = #imageLiteral(resourceName: "home")
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let yourWidth = collectionView.bounds.width
        let yourHeight = collectionView.bounds.height
        
        return CGSize(width: yourWidth, height: yourHeight)
    }

}
