//
//  BannerCvCell.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class BannerCvCell: UICollectionViewCell {
    @IBOutlet weak var banner_imageview: UIImageView!
    
}
