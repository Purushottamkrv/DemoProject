//
//  BannerCvresponse.swift
//  Bitoct
//
//  Created by Purushottam on 26/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class  BANNER {
    var bannerimagedatclass : [BANNERIMAGEDATA] = []
    var status = String()
    var bannerdatajson :JSON?
    
    init(bannerdata:JSON) {
        self.status = bannerdata["status"].stringValue
        self.bannerdatajson = bannerdata["Data"]
        
        if let BannerJson = self.bannerdatajson{
            for i in 0..<BannerJson.count{
                let Bannersingle = BANNERIMAGEDATA.init(banneimagedatajson: BannerJson[i])
                self.bannerimagedatclass.append(Bannersingle)
            }
        }
    }
}

class BANNERIMAGEDATA {
        var banner = String()
        init(banneimagedatajson:JSON) {
            
            self.banner = banneimagedatajson["themePics"].stringValue
        }
}



