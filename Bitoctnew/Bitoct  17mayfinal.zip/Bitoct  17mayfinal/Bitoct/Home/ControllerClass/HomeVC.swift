//
//  HomeVC.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class HomeVC: UIViewController {
    var gainTag = Int()
    
    
    @IBOutlet weak var search_bar: UISearchBar!
    @IBAction func corner_btnacn(_ sender: Any) {
    }
    @IBOutlet weak var tababr_outlet: UITabBar!
    @IBOutlet weak var banner_collectionview:BannerCV?
    @IBOutlet weak var pager_collectionview:PagerCV?
    @IBOutlet weak var pair_tableview:PairTV?


    @IBOutlet weak var gainerline_lbl: UILabel!
    @IBOutlet weak var gainer_imageview: UIImageView!
    @IBOutlet weak var looserline_lbl: UILabel!
    @IBOutlet weak var looser_imageview: UIImageView!
    @IBOutlet weak var gainer_containerview: UIView!
    @IBOutlet weak var looser_containerview: UIView!
    var timerHome = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        gainerline_lbl.isHidden  = false
        looserline_lbl.isHidden = true
        gainer_containerview.isHidden  = false
        looser_containerview.isHidden = true
        gainTag = 1
        
//        let appearance = UITabBarItem.appearance()
//        let attributes = [kCTFontAttributeName:UIFont(name: "American Typewriter", size: 17)]
//        appearance.setTitleTextAttributes(attributes as [NSAttributedStringKey : Any], for: .normal)
        
        self .BannerApiHit()
        self .PagerApiHit()
        self .PairApiHit()
//        gainerlooser_tableview?.register(UINib(nibName: "GainerLooseTvCell", bundle: nil), forCellReuseIdentifier:"gainerloosercell")
        
        //timerHome = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerHome = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerHome.invalidate()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func deposit_btnacn(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "FundsDepositClassVC") as! FundsDepositClassVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func withdrawal_btnacn(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "FundsWithdarawalVC") as! FundsWithdarawalVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @objc func updateData()
    {
        self.PairApiHit()
        self.PagerApiHit()
    }
    
    
    
    
}
extension HomeVC {
    @IBAction func arrow_btnacn(_ sender: Any) {
    }
    
    @IBAction func gainer_btnacn(_ sender: Any) {
        
        gainer_containerview.isHidden = false
        looser_containerview.isHidden = true
        gainerline_lbl.isHidden = false
        looserline_lbl.isHidden = true
    }
    @IBAction func looser_btnacn(_ sender: Any) {
        looser_containerview.isHidden = true
        looser_containerview.isHidden = false
        looserline_lbl.isHidden = false
        gainerline_lbl.isHidden = true
    }
    
}
extension HomeVC{
    @IBAction func more_btnacn(_ sender: Any) {
        
        let tbc = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
        tbc.selectedIndex = 1
        self.navigationController?.pushViewController(tbc, animated: true)
    }
}
// MARK:- Banner_Api
extension HomeVC{
    private func BannerApiHit()      {
        var myResponse : JSON? = nil
        var myUser : BANNER? = nil
        ApiManager.sharedInstance.fetchResponseFromUrl_get(urlStr:BANNER_URL, viewController: self, loadercheck: 5, onCompletion: { (Bannerjson) ->Void in
            myResponse = Bannerjson
                print("BANNER DETAIL API IS",myResponse!)
                myUser = BANNER(bannerdata: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
                
                if myUser?.status == "Succeed"{
                    self.banner_collectionview?.getpagecontrolr(viewcontroller: self)
                    self.banner_collectionview?.BanneimageArray = (myUser?.bannerimagedatclass)!
                }
                else{
                    Alert.showBasic(title: "", message:"theme get successfully", viewController: self)
                }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
}

// MARK:- Pager_Api

extension HomeVC{
   private func PagerApiHit(){
        var myResponse : JSON? = nil
        var myUser : PagerMainClass? = nil
    DispatchQueue.global(qos: .background).async {
        print("This is run on the background queue")
        ApiManager.sharedInstance.fetchResponseFromUrl_get(urlStr:TopFourMarket_URL, viewController: self, loadercheck: 5, onCompletion: { (Pagerjson) ->Void in
            myResponse = Pagerjson
            print(" PAGER DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
                myUser = PagerMainClass.init(pagermainclassjson: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
                if myUser?.status == "Succeed"{
                    self.pager_collectionview?.pagerdatarray = (myUser?.pagerdtaclass)!
                    self.pager_collectionview?.homeviewcontroller = self

                }
                else{
                        Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                    }
                }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
    }
}
// MARK:- Pair_Api
extension HomeVC{
    private func PairApiHit(){
        var myResponse : JSON? = nil
        var myUser : PairMainclass? = nil
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
            ApiManager.sharedInstance.fetchResponseFromUrl_get(urlStr:MarketDataBtc_URL, viewController: self, loadercheck: 5, onCompletion: { (Pairjson) ->Void in
                myResponse = Pairjson
                print(" PAIR DATA API IS",myResponse!)
                DispatchQueue.main.async {
                    print("This is run on the main queue, after the previous code in outer block")
               
                    myUser = PairMainclass.init(pairmainclassjson: myResponse!)
                    print("status = ",myUser?.status as Any)
                    print(myUser?.status as Any)
                    if myUser?.status == "Succeed"{
                        self.pair_tableview?.pairdataarray = (myUser?.pairdataclass)!
                        self.pair_tableview?.homeviewcontroller = self
                    
                    }
                    else{
                            Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                        }
                    }
            })
            {
                (failure)-> Void in
                POPMESSAGE.popmessage.NoInternetMessage()
            }
            
        }
        
        
    }
}

