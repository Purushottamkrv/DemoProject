//
//  GainerTV.swift
//  
//
//  Created by Purushottam on 28/04/18.
//

import UIKit

class GainerTV: UITableView,UITableViewDelegate,UITableViewDataSource {
    
    var bool:Bool = true
    var gainervc = GainerContainerVC()
    var gainerDataArray = [PairDataClassPlus](){
        didSet{
            reloadData()
        }
    }
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("Gainer Data Count = ",gainerDataArray.count)
        return gainerDataArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "gainerloosercell", for: indexPath) as! GainerLooseTvCell
        
        let str1 = gainerDataArray[indexPath.row].MarketAssetCode
        let myStringArr = str1.components(separatedBy: "/")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        
        cell.marketassetcode_lbl1.text = myStringFirst
        cell.marketassetcode_lbl2.text = "/ " + myStringSecond
        cell.lastprice_lbl.text = gainerDataArray[indexPath.row].LastPrice
        cell.change_lbl.backgroundColor =  UIColor(red: 115.0/255.0, green: 164.0/255.0, blue: 20.0/255.0, alpha: 1.0)
        cell.change_lbl.text = gainerDataArray[indexPath.row].Change + "%"
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("hello")
        let mainStory = UIStoryboard(name: "Main", bundle: nil)
        let buysellvc = mainStory.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
        buysellvc.marketid = gainerDataArray[indexPath.row].MarketId
        buysellvc.coinNameStr = gainerDataArray[indexPath.row].MarketAssetCode
        buysellvc.priceStr = gainerDataArray[indexPath.row].LastPrice
        buysellvc.volumeStr = gainerDataArray[indexPath.row].Volume
        buysellvc.lowPrice = gainerDataArray[indexPath.row].LowPrice
        buysellvc.highPrice = gainerDataArray[indexPath.row].HighPrice
        buysellvc.amntStr = gainerDataArray[indexPath.row].Dollar
        buysellvc.growthleftStr = gainerDataArray[indexPath.row].Change24
        buysellvc.growthrightStr = gainerDataArray[indexPath.row].Change
        self.gainervc.navigationController?.pushViewController(buysellvc, animated:true)
        
    }
    

    
}
