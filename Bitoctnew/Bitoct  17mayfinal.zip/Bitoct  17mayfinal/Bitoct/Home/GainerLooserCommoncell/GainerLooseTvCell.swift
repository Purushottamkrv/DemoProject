//
//  GainerLooseTvCell.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class GainerLooseTvCell: UITableViewCell {

    @IBOutlet weak var marketassetcode_lbl1: UILabel!
    @IBOutlet weak var marketassetcode_lbl2: UILabel!
    @IBOutlet weak var change_lbl: UILabel!
    @IBOutlet weak var lastprice_lbl: UILabel!
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
