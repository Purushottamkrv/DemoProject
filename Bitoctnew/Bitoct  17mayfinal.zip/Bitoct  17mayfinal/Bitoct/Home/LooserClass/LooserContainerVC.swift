//
//  LooserContainerVC.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class LooserContainerVC: UIViewController {
    
    @IBOutlet weak var looser_tableview:LooserTV!
    var timerLooser = Timer()
    override func viewDidLoad() {
        super.viewDidLoad()
        looser_tableview.register(UINib(nibName: "GainerLooseTvCell", bundle: nil), forCellReuseIdentifier: "gainerloosercell")
        
        self.LooserApiHit()
       // timerLooser = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerLooser = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerLooser.invalidate()
    }
    @objc func updateData()
    {
        self.LooserApiHit()
    }
}
extension LooserContainerVC{
    private func LooserApiHit(){
        var myResponse : JSON? = nil
        var myUser : PairMainclass? = nil
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
       
        ApiManager.sharedInstance.fetchResponseFromUrl_get(urlStr:MarketDataBtc_URL, viewController: self, loadercheck: 5, onCompletion: { (Pairjson) ->Void in
            myResponse = Pairjson
            print(" PAIR DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
                myUser = PairMainclass.init(pairmainclassjson: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
                if myUser?.status == "Succeed"{
                
                    self.looser_tableview.looserDataArray = (myUser?.pairdataclassminus)!
                    self.looser_tableview.looservc = self
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
    }
}
