//
//  LooserTV.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class LooserTV: UITableView,UITableViewDelegate,UITableViewDataSource {
    
    var bool:Bool = true
     var looservc = LooserContainerVC()
    var looserDataArray = [PairDataClassMinus](){
        didSet{
            reloadData()
        }
    }
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("Looser Data Count= ",looserDataArray.count)
        return looserDataArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "gainerloosercell", for: indexPath) as! GainerLooseTvCell
        
        let str1 = looserDataArray[indexPath.row].MarketAssetCode
        let myStringArr = str1.components(separatedBy: "/")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        
        cell.marketassetcode_lbl1.text = myStringFirst
        cell.marketassetcode_lbl2.text = "/ " + myStringSecond
        cell.lastprice_lbl.text = looserDataArray[indexPath.row].LastPrice
        cell.change_lbl.backgroundColor =  UIColor(red: 235.0/255.0, green: 0.0/255.0, blue: 112.0/255.0, alpha: 1.0)
        cell.change_lbl.text = looserDataArray[indexPath.row].Change + "%"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("hello")
        let mainStory = UIStoryboard(name: "Main", bundle: nil)
        let buysellvc = mainStory.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
        buysellvc.marketid = looserDataArray[indexPath.row].MarketId
        buysellvc.coinNameStr = looserDataArray[indexPath.row].MarketAssetCode
        buysellvc.priceStr = looserDataArray[indexPath.row].LastPrice
        buysellvc.volumeStr = looserDataArray[indexPath.row].Volume
        buysellvc.lowPrice = looserDataArray[indexPath.row].LowPrice
        buysellvc.highPrice = looserDataArray[indexPath.row].HighPrice
        buysellvc.amntStr = looserDataArray[indexPath.row].Dollar
        buysellvc.growthleftStr = looserDataArray[indexPath.row].Change24
        buysellvc.growthrightStr = looserDataArray[indexPath.row].Change
        self.looservc.navigationController?.pushViewController(buysellvc, animated:true)
        
    }
    
    

}
