//
//  PagerCV.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class PagerCV: UICollectionView,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    var homeviewcontroller = HomeVC()
    var pagerdatarray = [PagerDataClass](){
        didSet{
            reloadData()
        }
    }
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        super.init(frame: frame, collectionViewLayout: layout)
        self.delegate = self
        self.dataSource = self
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    
    func getpagecontrolr(viewcontroller:UIViewController)
    {
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("Page Data Count = ",pagerdatarray.count)
        return pagerdatarray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "pagercell", for: indexPath) as! PagerCvCell
        
            cell.currency_lbl.text = pagerdatarray[indexPath.row].Currency
            cell.lastprice_lbl.text = pagerdatarray[indexPath.row].LastPrice
            cell.change_lbl.text = pagerdatarray[indexPath.row].Change + "%"
        
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
        let mainStory = UIStoryboard(name: "Main", bundle: nil)
        let buysellvc = mainStory.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
        buysellvc.marketid = pagerdatarray[indexPath.row].MarketID
        buysellvc.coinNameStr = pagerdatarray[indexPath.row].Currency
        buysellvc.priceStr = pagerdatarray[indexPath.row].LastPrice
        buysellvc.volumeStr = pagerdatarray[indexPath.row].Volume
        buysellvc.lowPrice = pagerdatarray[indexPath.row].LowPrice
        buysellvc.highPrice = pagerdatarray[indexPath.row].HighPrice
        buysellvc.amntStr = pagerdatarray[indexPath.row].Dollar
        buysellvc.growthleftStr = pagerdatarray[indexPath.row].Change24
        buysellvc.growthrightStr = pagerdatarray[indexPath.row].Change
        self.homeviewcontroller.navigationController?.pushViewController(buysellvc, animated:true)
        
        
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let yourWidth = collectionView.bounds.width/3
        let yourHeight = collectionView.bounds.height
        
        return CGSize(width: yourWidth, height: yourHeight)
    }
    
}

