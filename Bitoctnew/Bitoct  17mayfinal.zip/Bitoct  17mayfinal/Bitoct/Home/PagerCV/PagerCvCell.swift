//
//  PagerCvCell.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class PagerCvCell: UICollectionViewCell {
    
    
    @IBOutlet weak var currency_lbl: UILabel!
    @IBOutlet weak var lastprice_lbl: UILabel!
    @IBOutlet weak var change_lbl: UILabel!
    
    
    
}
