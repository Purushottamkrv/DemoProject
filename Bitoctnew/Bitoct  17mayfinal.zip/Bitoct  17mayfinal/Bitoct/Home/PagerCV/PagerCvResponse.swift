//
//  PagerCvResponse.swift
//  Bitoct
//
//  Created by Purushottam on 27/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class PagerMainClass {
    
    var status = String()
    var Message = String()
    var pagerdatajson:JSON?
    var pagerdtaclass:[PagerDataClass] = []
    
    init(pagermainclassjson:JSON) {
        self.status = pagermainclassjson["status"].stringValue
        self.Message = pagermainclassjson["Message"].stringValue
        self.pagerdatajson = pagermainclassjson["Data"]
        
        if let Pagerjson = self.pagerdatajson{
            for i in 0..<Pagerjson.count{
                let pagersingle = PagerDataClass.init(pagerdataclassjson: Pagerjson[i])
                self.pagerdtaclass.append(pagersingle)
            }
        }
    }
}

class PagerDataClass {
    var Currency = String()
    var LastPrice = String()
    var Change = String()
    var MarketID = String()
    var Volume = String()
    var LowPrice = String()
    var HighPrice = String()
    var Change24 = String()
    var Dollar = String()
    var BaseCurrencyId = String()
    
    init(pagerdataclassjson:JSON) {
        self.Currency = pagerdataclassjson["Currency"].stringValue
        self.LastPrice = pagerdataclassjson["LastPrice"].stringValue
        self.Change = pagerdataclassjson["Change"].stringValue
        self.MarketID = pagerdataclassjson["MarketID"].stringValue
        self.Volume = pagerdataclassjson["Volume"].stringValue
        self.LowPrice = pagerdataclassjson["LowPrice"].stringValue
        self.HighPrice = pagerdataclassjson["HighPrice"].stringValue
        self.Change24 = pagerdataclassjson["Change24"].stringValue
        self.Dollar = pagerdataclassjson["Dollar"].stringValue
        self.BaseCurrencyId = pagerdataclassjson["BaseCurrencyId"].stringValue
        
    }
    
    
    
}

