//
//  PairTV.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class PairTV: UITableView,UITableViewDelegate,UITableViewDataSource {
    
   var homeviewcontroller = HomeVC()
    

    var pairdataarray = [PairDataClass](){
        didSet{
            reloadData()
        }
    }
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("PairDataArrayCount ",pairdataarray.count)
        return pairdataarray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PairTvCell
        
        let str1 = pairdataarray[indexPath.row].MarketAssetCode
        let myStringArr = str1.components(separatedBy: "/")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        
        
        cell.contentView.backgroundColor = UIColor.green
        cell.pair_lbl.text = myStringFirst
        cell.pairbtc_lbl.text = "/ " + myStringSecond
        cell.lastprice_lbl.text = pairdataarray[indexPath.row].LastPrice
        cell.volume_llbl.text = pairdataarray[indexPath.row].Volume
          return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("hello")
        let mainStory = UIStoryboard(name: "Main", bundle: nil)
        let buysellvc = mainStory.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
        buysellvc.marketid = pairdataarray[indexPath.row].MarketId
        buysellvc.coinNameStr = pairdataarray[indexPath.row].MarketAssetCode
        buysellvc.priceStr = pairdataarray[indexPath.row].LastPrice
        buysellvc.volumeStr = pairdataarray[indexPath.row].Volume
        buysellvc.lowPrice = pairdataarray[indexPath.row].LowPrice
        buysellvc.highPrice = pairdataarray[indexPath.row].HighPrice
        buysellvc.amntStr = pairdataarray[indexPath.row].Dollar
        buysellvc.growthleftStr = pairdataarray[indexPath.row].Change24
        buysellvc.growthrightStr = pairdataarray[indexPath.row].Change
        
        self.homeviewcontroller.navigationController?.pushViewController(buysellvc, animated:true)
        
    }


}
