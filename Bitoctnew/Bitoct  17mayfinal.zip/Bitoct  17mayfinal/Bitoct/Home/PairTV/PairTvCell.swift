//
//  PairTvCell.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class PairTvCell: UITableViewCell {

    @IBOutlet weak var pair_lbl: UILabel!
    @IBOutlet weak var pairbtc_lbl: UILabel!
    @IBOutlet weak var lastprice_lbl: UILabel!
    @IBOutlet weak var volume_llbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
