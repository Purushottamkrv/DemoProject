//
//  PairTvResponse.swift
//  Bitoct
//
//  Created by Purushottam on 27/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON

class  PairMainclass {
    
    var status = String()
    var Message = String()
    var pairdataclass:[PairDataClass] = []
    var pairdataclassplus:[PairDataClassPlus] = []
    var pairdataclassminus:[PairDataClassMinus] = []
    var pairdatajsonarray:JSON?
    
    init(pairmainclassjson:JSON) {
        self.status = pairmainclassjson["status"].stringValue
        self.Message = pairmainclassjson["Message"].stringValue
        self.pairdatajsonarray = pairmainclassjson["Data"]
        
        if let PairArray = self.pairdatajsonarray{
            for i in 0..<PairArray.count{
                let pairsinglearray = PairDataClass.init(pairdataclassjson: PairArray[i])
                pairdataclass.append(pairsinglearray)
                if PairArray[i]["Change"].stringValue.hasPrefix("-")
                {
                    let pairsinglearray = PairDataClassMinus.init(pairdataclassjson: PairArray[i])
                    pairdataclassminus.append(pairsinglearray)
                    
                }
                else 
                {
                    let pairsinglearray = PairDataClassPlus.init(pairdataclassjson: PairArray[i])
                    pairdataclassplus.append(pairsinglearray)
                }
            }
        }
        
    }
}
//Full Data Btc//
class PairDataClass {
    
    var MarketId = String()
    var MarketAssetCode = String()
    var MarketAssetName = String()
    var LastPrice = String()
    var Change = String()
    var HighPrice = String()
    var LowPrice = String()
    var Volume = String()
    var Change24 = String()
    var Dollar = String()
    
    init(pairdataclassjson:JSON) {
        
        self.MarketId = pairdataclassjson["MarketId"].stringValue
        self.MarketAssetCode = pairdataclassjson["MarketAssetCode"].stringValue
        self.LastPrice = pairdataclassjson["LastPrice"].stringValue
        self.Change = pairdataclassjson["Change"].stringValue
        self.Volume = pairdataclassjson["Volume"].stringValue
        self.Change24 = pairdataclassjson["Change24"].stringValue
        self.HighPrice = pairdataclassjson["HighPrice"].stringValue
        self.LowPrice = pairdataclassjson["LowPrice"].stringValue
        self.Dollar = pairdataclassjson["Dollar"].stringValue
    }
}
//For Data BTC + or 0
class PairDataClassPlus {
    
    var MarketId = String()
    var MarketAssetCode = String()
    var MarketAssetName = String()
    var LastPrice = String()
    var Change = String()
    var HighPrice = String()
    var LowPrice = String()
    var Volume = String()
    var Change24 = String()
    var Dollar = String()
    
    init(pairdataclassjson:JSON) {
        
        self.MarketId = pairdataclassjson["MarketId"].stringValue
        self.MarketAssetCode = pairdataclassjson["MarketAssetCode"].stringValue
        self.LastPrice = pairdataclassjson["LastPrice"].stringValue
        self.Change = pairdataclassjson["Change"].stringValue
        self.Volume = pairdataclassjson["Volume"].stringValue
        self.Change24 = pairdataclassjson["Change24"].stringValue
        self.HighPrice = pairdataclassjson["HighPrice"].stringValue
        self.LowPrice = pairdataclassjson["LowPrice"].stringValue
        self.Dollar = pairdataclassjson["Dollar"].stringValue
    }
}
//For Data BTC -
class PairDataClassMinus {
    
    var MarketId = String()
    var MarketAssetCode = String()
    var MarketAssetName = String()
    var LastPrice = String()
    var Change = String()
    var HighPrice = String()
    var LowPrice = String()
    var Volume = String()
    var Change24 = String()
    var Dollar = String()
    
    init(pairdataclassjson:JSON) {
        
        self.MarketId = pairdataclassjson["MarketId"].stringValue
        self.MarketAssetCode = pairdataclassjson["MarketAssetCode"].stringValue
        self.LastPrice = pairdataclassjson["LastPrice"].stringValue
        self.Change = pairdataclassjson["Change"].stringValue
        self.Volume = pairdataclassjson["Volume"].stringValue
        self.Change24 = pairdataclassjson["Change24"].stringValue
        self.HighPrice = pairdataclassjson["HighPrice"].stringValue
        self.LowPrice = pairdataclassjson["LowPrice"].stringValue
        self.Dollar = pairdataclassjson["Dollar"].stringValue
    }
}
