//
//  InitialVC.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class InitialVC: UIViewController {

    @IBOutlet weak var Logo_imageview: UIImageView!
    @IBOutlet weak var login_linelbl:UILabel!
    @IBOutlet weak var registerline_lbl:UILabel!
    @IBOutlet weak var login_containerview: UIView!
    @IBOutlet weak var register_containerview:UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        login_containerview.isHidden = false
        register_containerview.isHidden = true
        login_linelbl.isHidden = false
        registerline_lbl.isHidden = true
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    @IBAction func login_btnacn(_ sender: Any) {
        login_linelbl.isHidden = false
        registerline_lbl.isHidden =  true
        login_containerview.isHidden = false
        register_containerview.isHidden = true
    
    }
    
    @IBAction  func Register_btnacn(_ sender: Any){
        
        registerline_lbl.isHidden = false
        login_linelbl.isHidden = true
        login_containerview.isHidden = true
        register_containerview.isHidden = false
        
        
    }
    

}
