//
//  LoginVC.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

enum MESSAGE{
    case MATCH
    case NOT_MATCH
}
class LoginVC: UIViewController,UIGestureRecognizerDelegate {
    @IBOutlet weak var emailid_text: UITextField!
    @IBOutlet weak var password_txt:UITextField!
    @IBOutlet weak var main_view:UIView!
    @IBOutlet weak var login_btnoutlet:UIButton!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var reloadBtnOutlet: UIButton!
    @IBOutlet weak var submitBtnOutlet: UIButton!
    @IBOutlet weak var codeTextFld: UITextField!
    @IBOutlet weak var code_lbl: UILabel!
    @IBOutlet weak var blurView: UIView!
    var tapGesture = UITapGestureRecognizer()
    var rollType = String()
    var emailID = String()
    var userid = String()
    var password = String()
    var name = String()
    var lastlogin = String()
    
    let arr: String = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@#!%*"
    var currentCaptch = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        contentView.layer.cornerRadius = 5
//        main_view?.layer.cornerRadius = 5
//        main_view.layer.borderWidth = 0.5
//        main_view.layer.borderColor = UIColor .lightGray.cgColor
//        main_view?.layer.shadowOpacity = 0.2
//        main_view?.layer.shadowColor = UIColor.lightGray.cgColor
        //login_btnoutlet.layer.cornerRadius = 5
        //emailid_text.layer.borderWidth = 1.0
        //emailid_text.layer.borderColor = UIColor.init(red: 188.0/255.0, green: 188.0/255.0, blue: 188.0/255.0, alpha: 1.0).cgColor
       // password_txt.layer.borderWidth = 1.0
        //password_txt.layer.borderColor = UIColor.init(red: 188.0/255.0, green: 188.0/255.0, blue: 188.0/255.0, alpha: 1.0).cgColor
        
        emailid_text.attributedPlaceholder = NSAttributedString(string: "   Enter username",
                                                                attributes:[NSAttributedStringKey.foregroundColor: UIColor.gray])
        password_txt.attributedPlaceholder = NSAttributedString(string: "   Enter password", attributes: [NSAttributedStringKey.foregroundColor: UIColor.gray])
        
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        tapGesture.delegate = self
        blurView.addGestureRecognizer(tapGesture)
    
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func forgot_btnacn(_ sender: Any){
        
    }
    
    @IBAction func login_btnacn(_ sender: Any) {
        guard let username = emailid_text.text?.count, !(username == 0) else {
            Alert.showBasic(title: "", message: "Please Enter Username", viewController: self)
            return
        }
        guard let password = password_txt.text?.count, !(password == 0) else {
            Alert.showBasic(title: "", message: "Please Enter Password", viewController: self)
            return
        }
        logInApiHit()
    }
   
    @IBAction func register_btnacn(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "RegisterVC") as! RegisterVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        self.blurView.isHidden = true
        self.contentView.isHidden = true
        self.codeTextFld.text = ""
    }
    @IBAction func reloadAction(_ sender: Any)
    {
        reloadCaptch()
        
    }
    func checkIsMatchTwoString() -> MESSAGE
    {
        let input = codeTextFld.text
        if input  == currentCaptch
        {
            return MESSAGE.MATCH
        }
        else
        {
            return MESSAGE.NOT_MATCH
        }
    }
    func reloadCaptch()
    {
        currentCaptch = getRandomCatptch()
        code_lbl.text = currentCaptch
        code_lbl.backgroundColor = getRandomColor()
        codeTextFld.text = ""
    }
    @IBAction func submitAction(_ sender: Any)
    {
        switch checkIsMatchTwoString() {
        case .MATCH:
            code_lbl.text = "Success"
            UserDefaults.standard.set(self.userid, forKey: "USERID")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
            self.navigationController?.pushViewController(vc, animated: false)
            break
        case .NOT_MATCH:
            code_lbl.text = "Failed"
        }
        
    }
    func getRandomCatptch() -> String {
        var captcha = ""
        let count = UInt32(arr.count)
        let index1 = Int(arc4random_uniform(count))
        let index2 = Int(arc4random_uniform(count))
        let index3 = Int(arc4random_uniform(count))
        let index4 = Int(arc4random_uniform(count))
        let index5 = Int(arc4random_uniform(count))
        captcha = String(format: "%@%@%@%@%@", arguments:[arr[index1],arr[index2],arr[index3],arr[index4],arr[index5]])
        print("\(index1)-\(index2)-\(index3)-\(index4)-\(index5)-\(captcha)")
        return captcha
        
    }
    func getRandomColor() -> UIColor{
        let hue : CGFloat = (CGFloat(arc4random() % 256) / 256.0)
        let saturation : CGFloat = (CGFloat(arc4random() % 128) / 256.0) + 0.5
        let brightness : CGFloat = (CGFloat(arc4random() % 128) / 256.0) + 0.5
        let color : UIColor = UIColor(hue: hue, saturation: saturation, brightness: brightness, alpha: 1)
        return color
    }
}
extension LoginVC{
    
    
    func logInApiHit() {
        var myResponse : JSON? = nil
        var myUser : LOGIN? = nil
        let para : [String:Any] = ["UserName":emailid_text.text!, "Password":password_txt.text!]
        ApiManager.sharedInstance.fetchResponseFromUrl(urlStr:LOGIN_URL, paraMeters: para,viewController: self, loadercheck: 6, onCompletion: { (userLogInJson) ->Void in
            myResponse = userLogInJson
            myUser = LOGIN(loginjson: myResponse!)
            print("LOG IN API IS",myResponse!)
            print("message = ",myUser?.message as Any)
            print(myUser?.status as Any)
            
            if myUser?.status == "Succeed"{
                
                    if let myUser = myUser{
                        for i in 0..<myUser.logindataclassarray.count{
                            
                            self.rollType = myUser.logindataclassarray[i].RoleType
                            UserDefaults.standard.set(myUser.logindataclassarray[i].RoleType, forKey:"RoleType")
                            self.userid = myUser.logindataclassarray[i].MemberId
                            //UserDefaults.standard.set(myUser.logindataclassarray[i].MemberId, forKey: "USERID")
                            self.name = myUser.logindataclassarray[i].Name
                            UserDefaults.standard.set(myUser.logindataclassarray[i].Name, forKey: "NAME")
                            self.lastlogin = myUser.logindataclassarray[i].LastLogin
                            UserDefaults.standard.set(myUser.logindataclassarray[i].LastLogin, forKey: "LastLogin")
                            self.emailID = myUser.logindataclassarray[i].EmailId
                            UserDefaults.standard.set(myUser.logindataclassarray[i].EmailId, forKey: "EMAIL")
                            self.password = myUser.logindataclassarray[i].Password
                            UserDefaults.standard.set(myUser.logindataclassarray[i].Password, forKey: "PASSWORD")
                            
                            UserDefaults.standard.synchronize()
                        }
                }
                    
                    if myUser?.message == "2FA enabled"
                    {
                        
                        let googleVC = self.storyboard?.instantiateViewController(withIdentifier: "GoogleFAViewController") as! GoogleFAViewController
                        googleVC.memberID = self.userid
                        googleVC.userName = self.emailid_text.text!
                        googleVC.name = self.name
                        googleVC.emailID = self.emailID
                        googleVC.roleType = self.rollType
                        googleVC.lastLogin = self.lastlogin
                        googleVC.password = self.password
                        self.navigationController?.pushViewController(googleVC, animated: true)
                    }
                else
                    {
                        self.blurView.isHidden = false
                        self.contentView.isHidden = false
                        self.reloadCaptch()
//                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
//                        self.navigationController?.pushViewController(vc, animated: true)
                        
                    }
                
                
            }
            else{
                Alert.showBasic(title: "", message: (myUser?.message)!, viewController: self)
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
}

