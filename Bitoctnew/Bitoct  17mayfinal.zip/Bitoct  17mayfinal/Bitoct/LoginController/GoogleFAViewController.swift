//
//  2FAViewController.swift
//  Bitoct
//
//  Created by apple on 5/16/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

enum MESSAGENEW{
    case MATCH
    case NOT_MATCH
}

class GoogleFAViewController: UIViewController,UIGestureRecognizerDelegate {
    
    var memberID = String()
    var userName = String()
    var emailID = String()
    var name = String()
    var roleType = String()
    var lastLogin = String()
    var password = String()
    @IBOutlet weak var codeTextField: UITextField!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var reloadBtnOutlet: UIButton!
    @IBOutlet weak var submittBtnOtlt: UIButton!
    @IBOutlet weak var captchaTextFld: UITextField!
    @IBOutlet weak var code_lbl: UILabel!
    @IBOutlet weak var blurView: UIView!
    
    var tapGesture = UITapGestureRecognizer()
    let arr: String = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@#!%*"
    var currentCaptch = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        contentView.layer.cornerRadius = 5
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        tapGesture.delegate = self
        blurView.addGestureRecognizer(tapGesture)
        
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var submitBtnOutlet: UIButton!
    
    @IBAction func submitAction(_ sender: Any) {
        if codeTextField.text?.count == 0
        {
            Alert.showBasic(title: "Alert", message: "Please enter the code.", viewController: self)
        }
        else
        {
            validationAPIHit()
        }
    }
    @IBAction func backAction(_ sender: Any)
    {
        self.navigationController?.popViewController(animated: true)
    }
    func checkIsMatchTwoString() -> MESSAGENEW
    {
        let input = captchaTextFld.text
        if input  == currentCaptch
        {
            return MESSAGENEW.MATCH
        }
        else
        {
            return MESSAGENEW.NOT_MATCH
        }
    }
    func reloadCaptch()
    {
        currentCaptch = getRandomCatptch()
        code_lbl.text = currentCaptch
        code_lbl.backgroundColor = getRandomColor()
        captchaTextFld.text = ""
    }
    @IBAction func reloadAction(_ sender: Any)
    {
         reloadCaptch()
    }
    @IBAction func captchSubmitAction(_ sender: Any)
    {
        switch checkIsMatchTwoString() {
        case .MATCH:
            code_lbl.text = "Success"
            UserDefaults.standard.set(self.memberID, forKey: "USERID")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
            self.navigationController?.pushViewController(vc, animated: false)
            break
        case .NOT_MATCH:
            code_lbl.text = "Failed"
        }
    }
    func getRandomCatptch() -> String {
        var captcha = ""
        let count = UInt32(arr.count)
        let index1 = Int(arc4random_uniform(count))
        let index2 = Int(arc4random_uniform(count))
        let index3 = Int(arc4random_uniform(count))
        let index4 = Int(arc4random_uniform(count))
        let index5 = Int(arc4random_uniform(count))
        captcha = String(format: "%@%@%@%@%@", arguments:[arr[index1],arr[index2],arr[index3],arr[index4],arr[index5]])
        print("\(index1)-\(index2)-\(index3)-\(index4)-\(index5)-\(captcha)")
        return captcha
        
    }
    func getRandomColor() -> UIColor{
        let hue : CGFloat = (CGFloat(arc4random() % 256) / 256.0)
        let saturation : CGFloat = (CGFloat(arc4random() % 128) / 256.0) + 0.5
        let brightness : CGFloat = (CGFloat(arc4random() % 128) / 256.0) + 0.5
        let color : UIColor = UIColor(hue: hue, saturation: saturation, brightness: brightness, alpha: 1)
        return color
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        self.blurView.isHidden = true
        self.contentView.isHidden = true
        self.captchaTextFld.text = ""
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension GoogleFAViewController{
    func validationAPIHit()
    {
        var myResponse : JSON? = nil
        var myUser : CodeValidateClass? = nil
        let para : [String:Any] = ["MemberId":self.memberID, "securecode":self.codeTextField.text!,"username":self.userName,"emailid":self.emailID,"name":self.name,"roletype":self.roleType]
        ApiManager.sharedInstance.fetchResponseFromUrl(urlStr:ValidateCode_URL, paraMeters: para,viewController: self, loadercheck: 6, onCompletion: { (userLogInJson) ->Void in
            myResponse = userLogInJson
            myUser = CodeValidateClass(codeValidateJSON: myResponse!)
            print("LOG IN API IS",myResponse!)
            print("message = ",myUser?.message as Any)
            print(myUser?.status as Any)
            
            if myUser?.status == "Succeed"{
                
                UserDefaults.standard.set(self.roleType, forKey:"RoleType")
                
                //UserDefaults.standard.set(self.memberID, forKey: "USERID")
                
                UserDefaults.standard.set(self.name, forKey: "NAME")
                
                UserDefaults.standard.set(self.lastLogin, forKey: "LastLogin")
                
                UserDefaults.standard.set(self.emailID, forKey: "EMAIL")
                UserDefaults.standard.set(self.password, forKey: "PASSWORD")
                
                UserDefaults.standard.synchronize()
                
               self.blurView.isHidden = false
                self.contentView.isHidden = false
                //let vc = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
                //self.navigationController?.pushViewController(vc, animated: true)
            }
            else{
                Alert.showBasic(title: "", message: (myUser?.message)!, viewController: self)
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
}
