//
//  CodeValidate.swift
//  Bitoct
//
//  Created by apple on 5/15/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON

class CodeValidateClass{
    var status = String()
    var message = String()
    init(codeValidateJSON:JSON) {
        self.status = codeValidateJSON["status"].stringValue
        self.message = codeValidateJSON["Message"].stringValue
    }
}
