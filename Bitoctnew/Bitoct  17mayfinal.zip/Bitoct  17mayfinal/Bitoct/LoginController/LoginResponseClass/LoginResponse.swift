//
//  LoginResponse.swift
//  Bitoct
//
//  Created by Purushottam on 26/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class LOGIN {
    var status = String()
    var message = String()
    var logindataclassJson : JSON?
    var logindataclassarray : [LoginDataClass] = []
    init(loginjson:JSON) {
        self.status = loginjson["status"].stringValue
        self.message = loginjson["Message"].stringValue
        self.logindataclassJson = loginjson["Data"]
        
        if let logindataclassJson = self.logindataclassJson{
            for i in 0..<logindataclassJson.count{
                let logindatasingle = LoginDataClass(loginDataJson:logindataclassJson[i])
                self.logindataclassarray.append(logindatasingle)
            }
        }
    }
}
class LoginDataClass{
    var RoleType = String()
    var MemberId = String()
    var Name = String()
    var LastLogin = String()
    var Password = String()
    var EmailId = String()
    init(loginDataJson:JSON) {
        self.RoleType = loginDataJson["RoleType"].stringValue
        self.MemberId = loginDataJson["MemberId"].stringValue
        self.Name = loginDataJson["Name"].stringValue
        self.LastLogin = loginDataJson["LastLogin"].stringValue
        self.Password = loginDataJson["Password"].stringValue
        self.EmailId = loginDataJson["EmailId"].stringValue
    }
}
