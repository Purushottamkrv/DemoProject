//
//  BTCcontainerVC.swift
//  Bitoct
//
//  Created by Purushottam on 26/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
class BTCcontainerVC: UIViewController {
    
    @IBOutlet weak var btc_tableview:BtcTV?
    var timerBTC = Timer()
    override func viewDidLoad() {
        super.viewDidLoad()
        self .BtcLtcEthCommonApiHit()
        btc_tableview?.register(UINib(nibName: "BtcTvCommen_cell", bundle: nil), forCellReuseIdentifier: "cell")
        //timerBTC = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerBTC = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerBTC.invalidate()
    }
    @objc func updateData()
    {
        self .BtcLtcEthCommonApiHit()
    }
}

// MARK:- Btc
extension BTCcontainerVC{
    private func BtcLtcEthCommonApiHit(){
        var myResponse : JSON? = nil
        var myUser : BtcLtcEthcommonmainclass? = nil
        
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
       
        ApiManager.sharedInstance.fetchResponseFromUrl_get(urlStr:GetMarketData_URL, viewController: self, loadercheck: 5, onCompletion: { (commonjson) ->Void in
            myResponse = commonjson
            print(" Btc DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
           
                myUser = BtcLtcEthcommonmainclass(btcltcethcommondatajson: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
            
                if myUser?.status == "Succeed"{
            
                    self.btc_tableview?.Commmondataarray = (myUser?.commondataclass)!
                    self.btc_tableview?.btcContainerVC =  self
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
}



