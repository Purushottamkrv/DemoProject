//
//  BtcTV.swift
//  Bitoct
//
//  Created by Purushottam on 26/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class BtcTV: UITableView,UITableViewDelegate,UITableViewDataSource,UINavigationControllerDelegate {
    
    var btcContainerVC = BTCcontainerVC()
    var Commmondataarray = [CommonDataClass](){
        
        didSet{
            reloadData()
        }
    }
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Commmondataarray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BtcTvCommen_cell
        
        let str1 = Commmondataarray[indexPath.row].MarketAssetCode
        let myStringArr = str1.components(separatedBy: "/")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        cell.marketassetcode1_lbl.text = myStringFirst
        cell.marketassetcode2_lbl.text = "/ "+myStringSecond
        cell.volume_lbl.text = "Vol "+Commmondataarray[indexPath.row].Volume
        cell.doller_lbl.text = Commmondataarray[indexPath.row].Dollar
        cell.lastprice_lbl.text = Commmondataarray[indexPath.row].LastPrice
        if Commmondataarray[indexPath.row].Change.hasPrefix("-")
        {
           cell.change_lbl.backgroundColor =  UIColor(red: 235.0/255.0, green: 0.0/255.0, blue: 112.0/255.0, alpha: 1.0)
        }
        else
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 115.0/255.0, green: 164.0/255.0, blue: 20.0/255.0, alpha: 1.0)
        }
        cell.change_lbl.text = Commmondataarray[indexPath.row].Change+"%"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("hello")
        let mainStory = UIStoryboard(name: "Main", bundle: nil)
        let buysellvc = mainStory.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
        buysellvc.marketid = Commmondataarray[indexPath.row].MarketId
        buysellvc.coinNameStr = Commmondataarray[indexPath.row].MarketAssetCode
        buysellvc.priceStr = Commmondataarray[indexPath.row].LastPrice
        buysellvc.volumeStr = Commmondataarray[indexPath.row].Volume
        buysellvc.lowPrice = Commmondataarray[indexPath.row].LowPrice
        buysellvc.highPrice = Commmondataarray[indexPath.row].HighPrice
        buysellvc.amntStr = Commmondataarray[indexPath.row].Dollar
        buysellvc.growthleftStr = Commmondataarray[indexPath.row].Change24
        buysellvc.growthrightStr = Commmondataarray[indexPath.row].Change
        self.btcContainerVC.navigationController?.pushViewController(buysellvc, animated:true)
    
    }
}


