//
//  marketVC.swift
//  Bitoct
//
//  Created by Purushottam on 26/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class marketVC: UIViewController {
    
    @IBOutlet weak var btc_containerview: UIView!
    @IBOutlet weak var LTCcontainer_VC: UIView!
    @IBOutlet weak var eth_containerview: UIView!
    @IBOutlet weak var dash_containerview: UIView!
    @IBOutlet weak var zcash_containerview: UIView!
    @IBOutlet weak var iota_containerview: UIView!
    @IBOutlet weak var eos_containerview: UIView!
    @IBOutlet weak var btcline_lbl: UILabel!
    @IBOutlet weak var ethline_lbl: UILabel!
    @IBOutlet weak var ltc_linelbl: UILabel!
    @IBOutlet weak var dash_linelbl: UILabel!
    @IBOutlet weak var zcash_linelbl: UILabel!
    @IBOutlet weak var iota_linelbl: UILabel!
    @IBOutlet weak var eos_linelbl: UILabel!
    @IBOutlet weak var search_bar:UISearchBar!
      override func viewDidLoad() {
        super.viewDidLoad()
        
        btc_containerview.isHidden = false
        btcline_lbl.isEnabled = false
        ltc_linelbl.isHidden = true
        ethline_lbl.isHidden = true
        LTCcontainer_VC.isHidden = true
        eth_containerview.isHidden = true
        dash_containerview.isHidden = true
        dash_linelbl.isHidden = true
        zcash_containerview.isHidden = true
        zcash_linelbl.isHidden = true
        iota_containerview.isHidden = true
        iota_linelbl.isHidden = true
        eos_containerview.isHidden = true
        eos_linelbl.isHidden = true
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btc_btnacn(_ sender: Any) {
        
        btc_containerview.isHidden = false
        LTCcontainer_VC.isHidden = true
        eth_containerview.isHidden = true
        dash_containerview.isHidden = true
        zcash_containerview.isHidden = true
        iota_containerview.isHidden = true
        eos_containerview.isHidden = true
        
        btcline_lbl.isHidden = false
         ltc_linelbl.isHidden = true
        ethline_lbl.isHidden = true
        dash_linelbl.isHidden = true
        zcash_linelbl.isHidden = true
        iota_linelbl.isHidden = true
        eos_linelbl.isHidden = true
    }
    @IBAction func ltc_btnacn(_ sender: Any) {
        
        LTCcontainer_VC.isHidden = false
        btc_containerview.isHidden = true
        eth_containerview.isHidden = true
        dash_containerview.isHidden = true
        zcash_containerview.isHidden = true
        iota_containerview.isHidden = true
        eos_containerview.isHidden = true
        
        btcline_lbl.isHidden = true
        ltc_linelbl.isHidden = false
        ethline_lbl.isHidden = true
        dash_linelbl.isHidden = true
        zcash_linelbl.isHidden = true
        iota_linelbl.isHidden = true
        eos_linelbl.isHidden = true
    }
    @IBAction func eth_btnacn(_ sender: Any) {
        eth_containerview.isHidden = false
        LTCcontainer_VC.isHidden = true
        btc_containerview.isHidden = true
        dash_containerview.isHidden = true
        zcash_containerview.isHidden = true
        iota_containerview.isHidden = true
        eos_containerview.isHidden = true
        
        btcline_lbl.isHidden = true
        ethline_lbl.isHidden = false
        ltc_linelbl.isHidden = true
        dash_linelbl.isHidden = true
        zcash_linelbl.isHidden = true
        iota_linelbl.isHidden = true
        eos_linelbl.isHidden = true
    }
    @IBAction func dash_btnacn(_ sender: Any) {
        dash_containerview.isHidden = false
        LTCcontainer_VC.isHidden = true
        btc_containerview.isHidden = true
        eth_containerview.isHidden = true
        zcash_containerview.isHidden = true
        iota_containerview.isHidden = true
        eos_containerview.isHidden = true
        
        dash_linelbl.isHidden = false
        btcline_lbl.isHidden = true
        ethline_lbl.isHidden = true
        ltc_linelbl.isHidden = true
        zcash_linelbl.isHidden = true
        iota_linelbl.isHidden = true
        eos_linelbl.isHidden = true
    }
    @IBAction func zcash_btnacn(_ sender: Any) {
        zcash_containerview.isHidden = false
        eth_containerview.isHidden = true
        LTCcontainer_VC.isHidden = true
        btc_containerview.isHidden = true
        dash_containerview.isHidden = true
        iota_containerview.isHidden = true
        eos_containerview.isHidden = true
        
        zcash_linelbl.isHidden = false
        btcline_lbl.isHidden = true
        ethline_lbl.isHidden = true
        ltc_linelbl.isHidden = true
        dash_linelbl.isHidden = true
        iota_linelbl.isHidden = true
        eos_linelbl.isHidden = true
    }
    @IBAction func iota_btnacn(_ sender: Any) {
        iota_containerview.isHidden = false
        eth_containerview.isHidden = true
        LTCcontainer_VC.isHidden = true
        btc_containerview.isHidden = true
        zcash_containerview.isHidden = true
        dash_containerview.isHidden = true
        eos_containerview.isHidden = true
        
        iota_linelbl.isHidden = false
        btcline_lbl.isHidden = true
        ethline_lbl.isHidden = true
        ltc_linelbl.isHidden = true
        zcash_linelbl.isHidden = true
        dash_linelbl.isHidden = true
        eos_linelbl.isHidden = true
    }
    @IBAction func eos_btnacn(_ sender: Any) {
        
        eos_containerview.isHidden = false
        eth_containerview.isHidden = true
        LTCcontainer_VC.isHidden = true
        btc_containerview.isHidden = true
        iota_containerview.isHidden = true
        zcash_containerview.isHidden = true
        dash_containerview.isHidden = true
        
        eos_linelbl.isHidden = false
        btcline_lbl.isHidden = true
        ethline_lbl.isHidden = true
        ltc_linelbl.isHidden = true
        iota_linelbl.isHidden = true
        zcash_linelbl.isHidden = true
        dash_linelbl.isHidden = true
        
    }
}




