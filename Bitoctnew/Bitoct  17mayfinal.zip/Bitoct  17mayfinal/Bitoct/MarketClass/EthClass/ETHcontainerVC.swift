//
//  ETHcontainerVC.swift
//  Bitoct
//
//  Created by Purushottam on 26/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class ETHcontainerVC: UIViewController {
    
    @IBOutlet weak var eth_tableeview:EthTV!
    var timerETH = Timer()
    
    override func viewDidLoad() {
        self .EthApiHit()
        super.viewDidLoad()
        eth_tableeview.register(UINib(nibName: "BtcTvCommen_cell", bundle: nil), forCellReuseIdentifier: "cell")
        //timerETH = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerETH = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerETH.invalidate()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @objc func updateData()
    {
        self .EthApiHit()
    }
}

// MARK:- EthApiHit
extension ETHcontainerVC{
    private func EthApiHit(){
        var myResponse : JSON? = nil
        var myUser : BtcLtcEthcommonmainclass? = nil
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
        ApiManager.sharedInstance.fetchResponseFromUrl_get(urlStr:GetMarketData_URL, viewController: self, loadercheck: 5, onCompletion: { (commonjson) ->Void in
            myResponse = commonjson
            print(" Btc DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
                myUser = BtcLtcEthcommonmainclass(btcltcethcommondatajson: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
            
                if myUser?.status == "Succeed"{
                
                
                    self.eth_tableeview.EthArray = (myUser?.commondataclasseth)!
                
                    self.eth_tableeview.ethContainerVC = self
                
                
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
}
