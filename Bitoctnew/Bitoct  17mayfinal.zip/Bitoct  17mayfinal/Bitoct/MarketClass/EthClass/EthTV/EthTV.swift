//
//  EthTV.swift
//  Bitoct
//
//  Created by Purushottam on 26/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class EthTV: UITableView,UITableViewDataSource,UITableViewDelegate {
    
    var ethContainerVC = ETHcontainerVC()
    var EthArray = [CommonDataClassETH](){
        didSet{
            reloadData()
        }
    }
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return EthArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BtcTvCommen_cell
        
        //cell.marketassetcode1_lbl.text = EthArray[indexPath.row].MarketAssetCode
        
        let str1 = EthArray[indexPath.row].MarketAssetCode
        let myStringArr = str1.components(separatedBy: "/")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        cell.marketassetcode1_lbl.text = myStringFirst
        cell.marketassetcode2_lbl.text = "/ "+myStringSecond
        
        cell.volume_lbl.text = "Vol "+EthArray[indexPath.row].Volume
        cell.doller_lbl.text = EthArray[indexPath.row].Dollar
        cell.lastprice_lbl.text = EthArray[indexPath.row].LastPrice
        if EthArray[indexPath.row].Change.hasPrefix("-")
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 235.0/255.0, green: 0.0/255.0, blue: 112.0/255.0, alpha: 1.0)
        }
        else
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 115.0/255.0, green: 164.0/255.0, blue: 20.0/255.0, alpha: 1.0)
        }
        cell.change_lbl.text = EthArray[indexPath.row].Change+"%"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        
        
//        let mainStory = UIStoryboard(name: "Main", bundle: nil)
//        let buysellvc = mainStory.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
//        buysellvc.marketid = Commmondataarray[indexPath.row].MarketId
//        self.btcContainerVC.navigationController?.pushViewController(buysellvc, animated:true)
//
        let mainstoryboard = UIStoryboard.init(name: "Main", bundle: nil)
        let buysellvc =  mainstoryboard.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
        buysellvc.marketid = EthArray[indexPath.row].MarketId
        buysellvc.coinNameStr = EthArray[indexPath.row].MarketAssetCode
        buysellvc.priceStr = EthArray[indexPath.row].LastPrice
        buysellvc.volumeStr = EthArray[indexPath.row].Volume
        buysellvc.lowPrice = EthArray[indexPath.row].LowPrice
        buysellvc.highPrice = EthArray[indexPath.row].HighPrice
        buysellvc.amntStr = EthArray[indexPath.row].Dollar
        buysellvc.growthleftStr = EthArray[indexPath.row].Change24
        buysellvc.growthrightStr = EthArray[indexPath.row].Change
        self.ethContainerVC.navigationController?.pushViewController(buysellvc, animated: true)
        }
    
    
   
}
