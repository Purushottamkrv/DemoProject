//
//  DashContainerVC.swift
//  Bitoct
//
//  Created by apple on 6/11/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class IOTAContainerVC: UIViewController {

    @IBOutlet weak var dash_tableeview:DashTV!
    var timerDASH = Timer()
    
    override func viewDidLoad() {
        self.DashApiHit()
        super.viewDidLoad()
        dash_tableeview.register(UINib(nibName: "BtcTvCommen_cell", bundle: nil), forCellReuseIdentifier: "cell")
        //timerETH = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerDASH = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerDASH.invalidate()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @objc func updateData()
    {
        self.DashApiHit()
    }
}

// MARK:- EthApiHit
extension DashContainerVC{
    private func DashApiHit(){
        var myResponse : JSON? = nil
        var myUser : BtcLtcEthcommonmainclass? = nil
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
            ApiManager.sharedInstance.fetchResponseFromUrl_get(urlStr:GetMarketData_URL, viewController: self, loadercheck: 5, onCompletion: { (commonjson) ->Void in
                myResponse = commonjson
                print(" Btc DATA API IS",myResponse!)
                DispatchQueue.main.async {
                    print("This is run on the main queue, after the previous code in outer block")
                    myUser = BtcLtcEthcommonmainclass(btcltcethcommondatajson: myResponse!)
                    print("status = ",myUser?.status as Any)
                    print(myUser?.status as Any)
                    
                    if myUser?.status == "Succeed"{
                        
                        
                        self.dash_tableeview.DashArray = (myUser?.commondataclassdash)!
                        
                        self.dash_tableeview.dashContainerVC = self
                        
                        
                    }
                    else{
                        Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                    }
                }
            })
            {
                (failure)-> Void in
                POPMESSAGE.popmessage.NoInternetMessage()
            }
        }
    }

}
