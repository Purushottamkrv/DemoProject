//
//  DashTV.swift
//  Bitoct
//
//  Created by apple on 6/11/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class IotaTV: UITableView ,UITableViewDataSource,UITableViewDelegate {
    
    var iotaContainerVC = IOTAContainerVC()
    var IotaArray = [CommonDataClassIOTA](){
        didSet{
            reloadData()
        }
    }
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return IotaArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BtcTvCommen_cell
        
        //cell.marketassetcode1_lbl.text = EthArray[indexPath.row].MarketAssetCode
        
        let str1 = IotaArray[indexPath.row].MarketAssetCode
        let myStringArr = str1.components(separatedBy: "/")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        cell.marketassetcode1_lbl.text = myStringFirst
        cell.marketassetcode2_lbl.text = "/ "+myStringSecond
        
        cell.volume_lbl.text = "Vol "+IotaArray[indexPath.row].Volume
        cell.doller_lbl.text = IotaArray[indexPath.row].Dollar
        cell.lastprice_lbl.text = IotaArray[indexPath.row].LastPrice
        if IotaArray[indexPath.row].Change.hasPrefix("-")
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 235.0/255.0, green: 0.0/255.0, blue: 112.0/255.0, alpha: 1.0)
        }
        else
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 115.0/255.0, green: 164.0/255.0, blue: 20.0/255.0, alpha: 1.0)
        }
        cell.change_lbl.text = IotaArray[indexPath.row].Change+"%"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        
        //        let mainStory = UIStoryboard(name: "Main", bundle: nil)
        //        let buysellvc = mainStory.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
        //        buysellvc.marketid = Commmondataarray[indexPath.row].MarketId
        //        self.btcContainerVC.navigationController?.pushViewController(buysellvc, animated:true)
        //
        let mainstoryboard = UIStoryboard.init(name: "Main", bundle: nil)
        let buysellvc =  mainstoryboard.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
        buysellvc.marketid = IotaArray[indexPath.row].MarketId
        buysellvc.coinNameStr = IotaArray[indexPath.row].MarketAssetCode
        buysellvc.priceStr = IotaArray[indexPath.row].LastPrice
        buysellvc.volumeStr = IotaArray[indexPath.row].Volume
        buysellvc.lowPrice = IotaArray[indexPath.row].LowPrice
        buysellvc.highPrice = IotaArray[indexPath.row].HighPrice
        buysellvc.amntStr = IotaArray[indexPath.row].Dollar
        buysellvc.growthleftStr = IotaArray[indexPath.row].Change24
        buysellvc.growthrightStr = IotaArray[indexPath.row].Change
        self.iotaContainerVC.navigationController?.pushViewController(buysellvc, animated: true)
    }
    
    
    
}
