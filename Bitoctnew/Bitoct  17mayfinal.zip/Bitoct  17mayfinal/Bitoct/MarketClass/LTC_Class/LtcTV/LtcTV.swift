//
//  LtcTV.swift
//  Bitoct
//
//  Created by Purushottam on 26/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class LtcTV: UITableView,UITableViewDataSource,UITableViewDelegate {
    
    var ltcContainervc = LTCcontainerVC()

    var ltcarray = [CommonDataClassLTC](){
        didSet{
            
            reloadData()
        }
    }
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ltcarray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BtcTvCommen_cell
        
       // cell.marketassetcode1_lbl.text = ltcarray[indexPath.row].MarketAssetCode
        
        
        
        
        let str1 = ltcarray[indexPath.row].MarketAssetCode
        let myStringArr = str1.components(separatedBy: "/")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        
        cell.marketassetcode1_lbl.text = myStringFirst
        cell.marketassetcode2_lbl.text = "/ "+myStringSecond
        cell.volume_lbl.text = "Vol "+ltcarray[indexPath.row].Volume
        cell.doller_lbl.text = ltcarray[indexPath.row].Dollar
        cell.lastprice_lbl.text = ltcarray[indexPath.row].LastPrice
        if ltcarray[indexPath.row].Change.hasPrefix("-")
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 235.0/255.0, green: 0.0/255.0, blue: 112.0/255.0, alpha: 1.0)
        }
        else
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 115.0/255.0, green: 164.0/255.0, blue: 20.0/255.0, alpha: 1.0)
        }
        cell.change_lbl.text = ltcarray[indexPath.row].Change+"%"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    

        let mainStory = UIStoryboard(name: "Main", bundle: nil)
        let buysellvc = mainStory.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
        buysellvc.marketid = self.ltcarray[indexPath.row].MarketId
        buysellvc.coinNameStr = self.ltcarray[indexPath.row].MarketAssetCode
        buysellvc.priceStr = self.ltcarray[indexPath.row].LastPrice
        buysellvc.volumeStr = self.ltcarray[indexPath.row].Volume
        buysellvc.lowPrice = self.ltcarray[indexPath.row].LowPrice
        buysellvc.highPrice = self.ltcarray[indexPath.row].HighPrice
        buysellvc.amntStr = self.ltcarray[indexPath.row].Dollar
        buysellvc.growthleftStr = self.ltcarray[indexPath.row].Change24
        buysellvc.growthrightStr = self.ltcarray[indexPath.row].Change
        self.ltcContainervc.navigationController?.pushViewController(buysellvc, animated:true)
        }
    

}
