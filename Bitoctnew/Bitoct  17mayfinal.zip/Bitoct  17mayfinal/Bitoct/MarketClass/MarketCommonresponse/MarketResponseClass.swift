//
//  MarketResponseClass.swift
//  Bitoct
//
//  Created by Purushottam on 27/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class BtcLtcEthcommonmainclass {
    
    var status = String()
    var Message = String()
    var commondataclass:[CommonDataClass] = []
    var commondataclassltc:[CommonDataClassLTC] = []
    var commondataclasseth:[CommonDataClassETH] = []
    var commondataclassdash:[CommonDataClassDASH] = []
    var commondataclasszcash:[CommonDataClassZCASH] = []
    var commondataclassiota:[CommonDataClassIOTA] = []
    var commondataclasseos:[CommonDataClassEOS] = []
    var commondataarray:JSON?
    
     init(btcltcethcommondatajson:JSON) {
        self.status = btcltcethcommondatajson["status"].stringValue
        self.Message = btcltcethcommondatajson["Message"].stringValue
        self.commondataarray = btcltcethcommondatajson["Data"]
        
        if let CommonArray = self.commondataarray{
            for i in 0..<CommonArray.count{
                if (CommonArray[i]["BaseCurrencyID"].stringValue == "1")
                {
                    let commonsinglearray = CommonDataClass.init(commondatajson: CommonArray[i])
                    commondataclass.append(commonsinglearray)
                }
                else if(CommonArray[i]["BaseCurrencyID"].stringValue == "2")
                {
                    let commonsinglearray = CommonDataClassLTC.init(commondatajson: CommonArray[i])
                    commondataclassltc.append(commonsinglearray)
                }
                else if(CommonArray[i]["BaseCurrencyID"].stringValue == "3")
                {
                    let commonsinglearray = CommonDataClassETH.init(commondatajson: CommonArray[i])
                    commondataclasseth.append(commonsinglearray)
                }
                else if(CommonArray[i]["BaseCurrencyID"].stringValue == "4")
                {
                    let commonsinglearray = CommonDataClassDASH.init(commondatajson: CommonArray[i])
                    commondataclassdash.append(commonsinglearray)
                }
                else if(CommonArray[i]["BaseCurrencyID"].stringValue == "5")
                {
                    let commonsinglearray = CommonDataClassZCASH.init(commondatajson: CommonArray[i])
                    commondataclasszcash.append(commonsinglearray)
                }
                else if(CommonArray[i]["BaseCurrencyID"].stringValue == "6")
                {
                    let commonsinglearray = CommonDataClassIOTA.init(commondatajson: CommonArray[i])
                    commondataclassiota.append(commonsinglearray)
                }
                else
                {
                    let commonsinglearray = CommonDataClassEOS.init(commondatajson: CommonArray[i])
                    commondataclasseos.append(commonsinglearray)
                }
                
            }
        }
    }
}
/// For BTC///
class CommonDataClass {
    
    var MarketId = String()
    var MarketAssetCode = String()
    var MarketAssetName = String()
    var LastPrice = String()
    var Change = String()
    var HighPrice = String()
    var LowPrice = String()
    var Volume = String()
    var Change24 = String()
    var BaseCurrencyID = String()
    
    var Dollar = String()
    
    init(commondatajson:JSON) {
        self.MarketId = commondatajson["MarketId"].stringValue
        self.MarketAssetCode = commondatajson["MarketAssetCode"].stringValue
        self.MarketAssetName = commondatajson["MarketAssetName"].stringValue
        self.LastPrice = commondatajson["LastPrice"].stringValue
        self.Change = commondatajson["Change"].stringValue
        self.HighPrice = commondatajson["HighPrice"].stringValue
        self.LowPrice = commondatajson["LowPrice"].stringValue
        self.Volume = commondatajson["Volume"].stringValue
        self.Change24 = commondatajson["Change24"].stringValue
        self.BaseCurrencyID = commondatajson["BaseCurrencyID"].stringValue
        self.Dollar = commondatajson["Dollar"].stringValue


        
    }
}
// For LTC//
class CommonDataClassLTC {
    
    var MarketId = String()
    var MarketAssetCode = String()
    var MarketAssetName = String()
    var LastPrice = String()
    var Change = String()
    var HighPrice = String()
    var LowPrice = String()
    var Volume = String()
    var Change24 = String()
    var BaseCurrencyID = String()
    var Dollar = String()
    
    init(commondatajson:JSON) {
        self.MarketId = commondatajson["MarketId"].stringValue
        self.MarketAssetCode = commondatajson["MarketAssetCode"].stringValue
        self.MarketAssetName = commondatajson["MarketAssetName"].stringValue
        self.LastPrice = commondatajson["LastPrice"].stringValue
        self.Change = commondatajson["Change"].stringValue
        self.HighPrice = commondatajson["HighPrice"].stringValue
        self.LowPrice = commondatajson["LowPrice"].stringValue
        self.Volume = commondatajson["Volume"].stringValue
        self.Change24 = commondatajson["Change24"].stringValue
        self.BaseCurrencyID = commondatajson["BaseCurrencyID"].stringValue
        self.Dollar = commondatajson["Dollar"].stringValue

        
        
    }
}
// For ETH //
class CommonDataClassETH {
    
    var MarketId = String()
    var MarketAssetCode = String()
    var MarketAssetName = String()
    var LastPrice = String()
    var Change = String()
    var HighPrice = String()
    var LowPrice = String()
    var Volume = String()
    var Change24 = String()
    var BaseCurrencyID = String()
    var Dollar = String()
    
    
    init(commondatajson:JSON) {
        self.MarketId = commondatajson["MarketId"].stringValue
        self.MarketAssetCode = commondatajson["MarketAssetCode"].stringValue
        self.MarketAssetName = commondatajson["MarketAssetName"].stringValue
        self.LastPrice = commondatajson["LastPrice"].stringValue
        self.Change = commondatajson["Change"].stringValue
        self.HighPrice = commondatajson["HighPrice"].stringValue
        self.LowPrice = commondatajson["LowPrice"].stringValue
        self.Volume = commondatajson["Volume"].stringValue
        self.Change24 = commondatajson["Change24"].stringValue
        self.BaseCurrencyID = commondatajson["BaseCurrencyID"].stringValue
        self.Dollar = commondatajson["Dollar"].stringValue

        
        
    }
}

// For DASH //
class CommonDataClassDASH {
    
    var MarketId = String()
    var MarketAssetCode = String()
    var MarketAssetName = String()
    var LastPrice = String()
    var Change = String()
    var HighPrice = String()
    var LowPrice = String()
    var Volume = String()
    var Change24 = String()
    var BaseCurrencyID = String()
    var Dollar = String()
    
    
    init(commondatajson:JSON) {
        self.MarketId = commondatajson["MarketId"].stringValue
        self.MarketAssetCode = commondatajson["MarketAssetCode"].stringValue
        self.MarketAssetName = commondatajson["MarketAssetName"].stringValue
        self.LastPrice = commondatajson["LastPrice"].stringValue
        self.Change = commondatajson["Change"].stringValue
        self.HighPrice = commondatajson["HighPrice"].stringValue
        self.LowPrice = commondatajson["LowPrice"].stringValue
        self.Volume = commondatajson["Volume"].stringValue
        self.Change24 = commondatajson["Change24"].stringValue
        self.BaseCurrencyID = commondatajson["BaseCurrencyID"].stringValue
        self.Dollar = commondatajson["Dollar"].stringValue
        
        
        
    }
}

// For ZCASH //
class CommonDataClassZCASH {
    
    var MarketId = String()
    var MarketAssetCode = String()
    var MarketAssetName = String()
    var LastPrice = String()
    var Change = String()
    var HighPrice = String()
    var LowPrice = String()
    var Volume = String()
    var Change24 = String()
    var BaseCurrencyID = String()
    var Dollar = String()
    
    
    init(commondatajson:JSON) {
        self.MarketId = commondatajson["MarketId"].stringValue
        self.MarketAssetCode = commondatajson["MarketAssetCode"].stringValue
        self.MarketAssetName = commondatajson["MarketAssetName"].stringValue
        self.LastPrice = commondatajson["LastPrice"].stringValue
        self.Change = commondatajson["Change"].stringValue
        self.HighPrice = commondatajson["HighPrice"].stringValue
        self.LowPrice = commondatajson["LowPrice"].stringValue
        self.Volume = commondatajson["Volume"].stringValue
        self.Change24 = commondatajson["Change24"].stringValue
        self.BaseCurrencyID = commondatajson["BaseCurrencyID"].stringValue
        self.Dollar = commondatajson["Dollar"].stringValue
        
        
        
    }
}

// For IOTA //
class CommonDataClassIOTA {
    
    var MarketId = String()
    var MarketAssetCode = String()
    var MarketAssetName = String()
    var LastPrice = String()
    var Change = String()
    var HighPrice = String()
    var LowPrice = String()
    var Volume = String()
    var Change24 = String()
    var BaseCurrencyID = String()
    var Dollar = String()
    
    
    init(commondatajson:JSON) {
        self.MarketId = commondatajson["MarketId"].stringValue
        self.MarketAssetCode = commondatajson["MarketAssetCode"].stringValue
        self.MarketAssetName = commondatajson["MarketAssetName"].stringValue
        self.LastPrice = commondatajson["LastPrice"].stringValue
        self.Change = commondatajson["Change"].stringValue
        self.HighPrice = commondatajson["HighPrice"].stringValue
        self.LowPrice = commondatajson["LowPrice"].stringValue
        self.Volume = commondatajson["Volume"].stringValue
        self.Change24 = commondatajson["Change24"].stringValue
        self.BaseCurrencyID = commondatajson["BaseCurrencyID"].stringValue
        self.Dollar = commondatajson["Dollar"].stringValue
        
        
        
    }
}
// For EOS //
class CommonDataClassEOS {
    
    var MarketId = String()
    var MarketAssetCode = String()
    var MarketAssetName = String()
    var LastPrice = String()
    var Change = String()
    var HighPrice = String()
    var LowPrice = String()
    var Volume = String()
    var Change24 = String()
    var BaseCurrencyID = String()
    var Dollar = String()
    
    
    init(commondatajson:JSON) {
        self.MarketId = commondatajson["MarketId"].stringValue
        self.MarketAssetCode = commondatajson["MarketAssetCode"].stringValue
        self.MarketAssetName = commondatajson["MarketAssetName"].stringValue
        self.LastPrice = commondatajson["LastPrice"].stringValue
        self.Change = commondatajson["Change"].stringValue
        self.HighPrice = commondatajson["HighPrice"].stringValue
        self.LowPrice = commondatajson["LowPrice"].stringValue
        self.Volume = commondatajson["Volume"].stringValue
        self.Change24 = commondatajson["Change24"].stringValue
        self.BaseCurrencyID = commondatajson["BaseCurrencyID"].stringValue
        self.Dollar = commondatajson["Dollar"].stringValue
        
        
        
    }
}
