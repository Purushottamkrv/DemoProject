//
//  DashTV.swift
//  Bitoct
//
//  Created by apple on 6/11/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class ZCashTV: UITableView ,UITableViewDataSource,UITableViewDelegate {
    
    var zcashContainerVC = ZCashContainerVC()
    var ZCashArray = [CommonDataClassZCASH](){
        didSet{
            reloadData()
        }
    }
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ZCashArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BtcTvCommen_cell
        
        //cell.marketassetcode1_lbl.text = EthArray[indexPath.row].MarketAssetCode
        
        let str1 = ZCashArray[indexPath.row].MarketAssetCode
        let myStringArr = str1.components(separatedBy: "/")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        cell.marketassetcode1_lbl.text = myStringFirst
        cell.marketassetcode2_lbl.text = "/ "+myStringSecond
        
        cell.volume_lbl.text = "Vol "+ZCashArray[indexPath.row].Volume
        cell.doller_lbl.text = ZCashArray[indexPath.row].Dollar
        cell.lastprice_lbl.text = ZCashArray[indexPath.row].LastPrice
        if ZCashArray[indexPath.row].Change.hasPrefix("-")
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 235.0/255.0, green: 0.0/255.0, blue: 112.0/255.0, alpha: 1.0)
        }
        else
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 115.0/255.0, green: 164.0/255.0, blue: 20.0/255.0, alpha: 1.0)
        }
        cell.change_lbl.text = ZCashArray[indexPath.row].Change+"%"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        
        //        let mainStory = UIStoryboard(name: "Main", bundle: nil)
        //        let buysellvc = mainStory.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
        //        buysellvc.marketid = Commmondataarray[indexPath.row].MarketId
        //        self.btcContainerVC.navigationController?.pushViewController(buysellvc, animated:true)
        //
        let mainstoryboard = UIStoryboard.init(name: "Main", bundle: nil)
        let buysellvc =  mainstoryboard.instantiateViewController(withIdentifier: "BuySellVC") as! BuySellVC
        buysellvc.marketid = ZCashArray[indexPath.row].MarketId
        buysellvc.coinNameStr = ZCashArray[indexPath.row].MarketAssetCode
        buysellvc.priceStr = ZCashArray[indexPath.row].LastPrice
        buysellvc.volumeStr = ZCashArray[indexPath.row].Volume
        buysellvc.lowPrice = ZCashArray[indexPath.row].LowPrice
        buysellvc.highPrice = ZCashArray[indexPath.row].HighPrice
        buysellvc.amntStr = ZCashArray[indexPath.row].Dollar
        buysellvc.growthleftStr = ZCashArray[indexPath.row].Change24
        buysellvc.growthrightStr = ZCashArray[indexPath.row].Change
        self.zcashContainerVC.navigationController?.pushViewController(buysellvc, animated: true)
    }
    
    
    
}
