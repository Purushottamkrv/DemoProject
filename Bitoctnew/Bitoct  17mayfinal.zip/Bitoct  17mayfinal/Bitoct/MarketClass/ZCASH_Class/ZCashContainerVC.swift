//
//  DashContainerVC.swift
//  Bitoct
//
//  Created by apple on 6/11/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class ZCashContainerVC: UIViewController {

    @IBOutlet weak var zcash_tableeview:ZCashTV!
    var timerZCash = Timer()
    
    override func viewDidLoad() {
        self.ZCashApiHit()
        super.viewDidLoad()
        zcash_tableeview.register(UINib(nibName: "BtcTvCommen_cell", bundle: nil), forCellReuseIdentifier: "cell")
        //timerETH = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerZCash = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerZCash.invalidate()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @objc func updateData()
    {
        self.ZCashApiHit()
    }
}

// MARK:- EthApiHit
extension ZCashContainerVC{
    private func ZCashApiHit(){
        var myResponse : JSON? = nil
        var myUser : BtcLtcEthcommonmainclass? = nil
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
            ApiManager.sharedInstance.fetchResponseFromUrl_get(urlStr:GetMarketData_URL, viewController: self, loadercheck: 5, onCompletion: { (commonjson) ->Void in
                myResponse = commonjson
                print(" Btc DATA API IS",myResponse!)
                DispatchQueue.main.async {
                    print("This is run on the main queue, after the previous code in outer block")
                    myUser = BtcLtcEthcommonmainclass(btcltcethcommondatajson: myResponse!)
                    print("status = ",myUser?.status as Any)
                    print(myUser?.status as Any)
                    
                    if myUser?.status == "Succeed"{
                        
                        
                        self.zcash_tableeview.ZCashArray = (myUser?.commondataclasszcash)!
                        
                        self.zcash_tableeview.zcashContainerVC = self
                        
                        
                    }
                    else{
                        Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                    }
                }
            })
            {
                (failure)-> Void in
                POPMESSAGE.popmessage.NoInternetMessage()
            }
        }
    }

}
