//
//  BtcNewContainerVC.swift
//  Bitoct
//
//  Created by Purushottam on 05/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

protocol btcMarketIdDelegate {
    func getBtcMarketIdAction(marketId:String, marketAssetCode:String)
}
class BtcNewContainerVC: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var timerBTCNew = Timer()
    var Commmondataarray = [CommonDataClass](){
        didSet{
            btc_newtableview.reloadData()
        }
    }
    @IBOutlet weak var btc_newtableview: UITableView!
    var btcmarketiddelegate : btcMarketIdDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        BtcLtcEthNewCommonApiHit()
        btc_newtableview?.register(UINib(nibName: "BtcTvCommen_cell", bundle: nil), forCellReuseIdentifier: "cell")
        // Do any additional setup after loading the view.
//        timerBTCNew = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerBTCNew = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerBTCNew.invalidate()
    }
    @objc func updateData()
    {
        self.BtcLtcEthNewCommonApiHit()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Commmondataarray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BtcTvCommen_cell
        let str1 = Commmondataarray[indexPath.row].MarketAssetCode
        let myStringArr = str1.components(separatedBy: "/")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        cell.marketassetcode1_lbl.text = myStringFirst
        cell.marketassetcode2_lbl.text = "/ "+myStringSecond
        cell.volume_lbl.text = "Vol "+Commmondataarray[indexPath.row].Volume
        cell.doller_lbl.text = Commmondataarray[indexPath.row].Dollar
        cell.lastprice_lbl.text = Commmondataarray[indexPath.row].LastPrice
        if Commmondataarray[indexPath.row].Change.hasPrefix("-")
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 235.0/255.0, green: 0.0/255.0, blue: 112.0/255.0, alpha: 1.0)
        }
        else
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 115.0/255.0, green: 164.0/255.0, blue: 20.0/255.0, alpha: 1.0)
        }
        cell.change_lbl.text = Commmondataarray[indexPath.row].Change+"%"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        btcmarketiddelegate?.getBtcMarketIdAction(marketId: Commmondataarray[indexPath.row].MarketId, marketAssetCode: Commmondataarray[indexPath.row].MarketAssetCode)
        
//        UserDefaults.standard.set(Commmondataarray[indexPath.row].MarketId, forKey: "MarketID")
//        UserDefaults.standard.set(Commmondataarray[indexPath.row].MarketAssetCode, forKey: "MarketCode")
//        self.navigationController?.popViewController(animated: true)
        
    }
}


// MARK:- Btc
extension BtcNewContainerVC{
    private func BtcLtcEthNewCommonApiHit(){
        var myResponse : JSON? = nil
        var myUser : BtcLtcEthcommonmainclass? = nil
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
        
        ApiManager.sharedInstance.fetchResponseFromUrl_get(urlStr:GetMarketData_URL, viewController: self, loadercheck: 5, onCompletion: { (commonjson) ->Void in
            myResponse = commonjson
            print(" Btc DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
                myUser = BtcLtcEthcommonmainclass(btcltcethcommondatajson: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
            
                if myUser?.status == "Succeed"{
                    self.Commmondataarray = (myUser?.commondataclass)!
                    //self.btc_tableview?.btcContainerVC =  self
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
}




