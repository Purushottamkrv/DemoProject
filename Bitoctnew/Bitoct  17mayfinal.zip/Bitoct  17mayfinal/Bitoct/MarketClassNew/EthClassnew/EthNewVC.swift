//
//  EthNewVC.swift
//  Bitoct
//
//  Created by Purushottam on 05/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

protocol ethMarketIdDelegate {
    func getEthMarketIdAction(marketId:String, marketAssetCode:String)
}
class EthNewVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var timerETHNew = Timer()
    var EthArray = [CommonDataClassETH](){
        didSet{
           eth_newtableview .reloadData()
        }
    }
    
    
    
    @IBOutlet weak var eth_newtableview: UITableView!
    var ethmarketiddelegate : ethMarketIdDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        EthNewApiHit()
        eth_newtableview?.register(UINib(nibName: "BtcTvCommen_cell", bundle: nil), forCellReuseIdentifier: "cell")

        //timerETHNew = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerETHNew = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerETHNew.invalidate()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @objc func updateData()
    {
        self.EthNewApiHit()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return EthArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BtcTvCommen_cell
        
        //cell.marketassetcode1_lbl.text = EthArray[indexPath.row].MarketAssetCode
        
        let str1 = EthArray[indexPath.row].MarketAssetCode
        let myStringArr = str1.components(separatedBy: "/")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        cell.marketassetcode1_lbl.text = myStringFirst
        cell.marketassetcode2_lbl.text = "/ "+myStringSecond
        
        cell.volume_lbl.text = "Vol "+EthArray[indexPath.row].Volume
        cell.doller_lbl.text = EthArray[indexPath.row].Dollar
        cell.lastprice_lbl.text = EthArray[indexPath.row].LastPrice
        if EthArray[indexPath.row].Change.hasPrefix("-")
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 235.0/255.0, green: 0.0/255.0, blue: 112.0/255.0, alpha: 1.0)
        }
        else
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 115.0/255.0, green: 164.0/255.0, blue: 20.0/255.0, alpha: 1.0)
        }
        cell.change_lbl.text = EthArray[indexPath.row].Change+"%"
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        ethmarketiddelegate?.getEthMarketIdAction(marketId: self.EthArray[indexPath.row].MarketId, marketAssetCode: self.EthArray[indexPath.row].MarketAssetCode)
        
//        UserDefaults.standard.set(EthArray[indexPath.row].MarketId, forKey: "MarketID")
//        UserDefaults.standard.set(EthArray[indexPath.row].MarketAssetCode, forKey: "MarketCode")
//        self.navigationController?.popViewController(animated: true)
    }
}

// MARK:- EthApiHit

extension EthNewVC{
        private func EthNewApiHit(){
            var myResponse : JSON? = nil
            var myUser : BtcLtcEthcommonmainclass? = nil
            DispatchQueue.global(qos: .background).async {
                print("This is run on the background queue")
            
            ApiManager.sharedInstance.fetchResponseFromUrl_get(urlStr:GetMarketData_URL, viewController: self, loadercheck: 5, onCompletion: { (commonjson) ->Void in
                myResponse = commonjson
                print(" Btc DATA API IS",myResponse!)
                DispatchQueue.main.async {
                    print("This is run on the main queue, after the previous code in outer block")
                
                    myUser = BtcLtcEthcommonmainclass(btcltcethcommondatajson: myResponse!)
                    print("status = ",myUser?.status as Any)
                    print(myUser?.status as Any)
                
                    if myUser?.status == "Succeed"{
                        self.EthArray = (myUser?.commondataclasseth)!
                        //self.eth_tableeview.ethContainerVC = self
                    }
                    else{
                        Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                    }
                }
            })
            {
                (failure)-> Void in
                POPMESSAGE.popmessage.NoInternetMessage()
            }
            }
        }
    

}
