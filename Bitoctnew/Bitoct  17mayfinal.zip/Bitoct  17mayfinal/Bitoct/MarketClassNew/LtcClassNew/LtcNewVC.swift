//
//  LtcNewVC.swift
//  Bitoct
//
//  Created by Purushottam on 05/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

protocol ltcMarketIdDelegate {
    func getLtcMarketIdAction(marketId:String, marketAssetCode:String)
}
class LtcNewVC: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var timerLTCNew = Timer()
    var ltcarray = [CommonDataClassLTC](){
        didSet{
            
            ltc_newtableview .reloadData()
        }
    }
    
    
    @IBOutlet weak var ltc_newtableview: UITableView!
    var ltcmarketiddelegate : ltcMarketIdDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        ltc_newtableview.register(UINib(nibName: "BtcTvCommen_cell", bundle: nil), forCellReuseIdentifier: "cell")
        LtcnewApiHit()
        
        //timerLTCNew = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerLTCNew = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerLTCNew.invalidate()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @objc func updateData()
    {
        self.LtcnewApiHit()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ltcarray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BtcTvCommen_cell
        
        // cell.marketassetcode1_lbl.text = ltcarray[indexPath.row].MarketAssetCode
        
        let str1 = ltcarray[indexPath.row].MarketAssetCode
        let myStringArr = str1.components(separatedBy: "/")
        let myStringFirst = myStringArr[0]
        let myStringSecond = myStringArr[1]
        
        cell.marketassetcode1_lbl.text = myStringFirst
        cell.marketassetcode2_lbl.text = "/ "+myStringSecond
        cell.volume_lbl.text = "Vol "+ltcarray[indexPath.row].Volume
        cell.doller_lbl.text = ltcarray[indexPath.row].Dollar
        cell.lastprice_lbl.text = ltcarray[indexPath.row].LastPrice
        if ltcarray[indexPath.row].Change.hasPrefix("-")
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 235.0/255.0, green: 0.0/255.0, blue: 112.0/255.0, alpha: 1.0)
        }
        else
        {
            cell.change_lbl.backgroundColor =  UIColor(red: 115.0/255.0, green: 164.0/255.0, blue: 20.0/255.0, alpha: 1.0)
        }
        cell.change_lbl.text = ltcarray[indexPath.row].Change+"%"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        ltcmarketiddelegate?.getLtcMarketIdAction(marketId: self.ltcarray[indexPath.row].MarketId, marketAssetCode: self.ltcarray[indexPath.row].MarketAssetCode)
        
//        UserDefaults.standard.set(ltcarray[indexPath.row].MarketId, forKey: "MarketID")
//        UserDefaults.standard.set(ltcarray[indexPath.row].MarketAssetCode, forKey: "MarketCode")
//        self.navigationController?.popViewController(animated: true)
    }

}

extension LtcNewVC{
    
    private func LtcnewApiHit(){
        var myResponse : JSON? = nil
        var myUser : BtcLtcEthcommonmainclass? = nil
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
        
        ApiManager.sharedInstance.fetchResponseFromUrl_get(urlStr:GetMarketData_URL, viewController: self, loadercheck: 5, onCompletion: { (commonjson) ->Void in
            myResponse = commonjson
            print(" Btc DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
            
                myUser = BtcLtcEthcommonmainclass(btcltcethcommondatajson: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
                if myUser?.status == "Succeed"{
                    self.ltcarray = (myUser?.commondataclassltc)!
                    //  self.ltc_tableview.ltcContainervc = self
                
                    // self.ltc_tableview.ltcContainervc = self
                
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
}

