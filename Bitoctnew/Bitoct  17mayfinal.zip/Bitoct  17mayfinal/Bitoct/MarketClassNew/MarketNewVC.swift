//
//  MarketNewVC.swift
//  Bitoct
//
//  Created by Purushottam on 05/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class MarketNewVC: UIViewController,btcMarketIdDelegate,ltcMarketIdDelegate,ethMarketIdDelegate {
    
    func getEthMarketIdAction(marketId: String, marketAssetCode: String) {
        let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
        (tabVC.viewControllers![2] as! TradeVC).marketIdStr = marketId
        (tabVC.viewControllers![2] as! TradeVC).marketAssetCodeStr = marketAssetCode
        tabVC.selectedIndex = 2
        self.navigationController?.pushViewController(tabVC, animated: true)
    }
    
    func getLtcMarketIdAction(marketId: String, marketAssetCode: String) {
        let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
        (tabVC.viewControllers![2] as! TradeVC).marketIdStr = marketId
        (tabVC.viewControllers![2] as! TradeVC).marketAssetCodeStr = marketAssetCode
        tabVC.selectedIndex = 2
        self.navigationController?.pushViewController(tabVC, animated: true)
    }
    
    func getBtcMarketIdAction(marketId: String, marketAssetCode: String) {
    
        let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
        (tabVC.viewControllers![2] as! TradeVC).marketIdStr = marketId
        (tabVC.viewControllers![2] as! TradeVC).marketAssetCodeStr = marketAssetCode
         tabVC.selectedIndex = 2
        self.navigationController?.pushViewController(tabVC, animated: true)
        
    }
    
//    var btcnewcv : BtcNewContainerVC?
//    var ltcnewcv : LtcNewVC?
//    var etchnewcv : EthNewVC?
    
    @IBOutlet weak var btcnew_containerview: UIView!
    @IBOutlet weak var ltcnew_containerview: UIView!
    @IBOutlet weak var ethnew_containerview: UIView!
    @IBOutlet weak var btcnew_linelbl: UILabel!
    
    @IBOutlet weak var ltcnew_linelbl: UILabel!
    @IBOutlet weak var ethnew_linelbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btcnew_containerview.isHidden = false
        ltcnew_containerview.isHidden = true
        ethnew_containerview.isHidden = true
        btcnew_linelbl.isHidden = false
        ltcnew_linelbl.isHidden = true
        ethnew_linelbl.isHidden = true
        
        // Do any additional setup after loading the view.
//        btcnewcv?.btcmarketiddelegate = self
//        ltcnewcv?.ltcmarketiddelegate = self
//        etchnewcv?.ethmarketiddelegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btcnew_btnacn(_ sender: Any) {
        
        btcnew_containerview.isHidden = false
        ltcnew_containerview.isHidden = true
        ethnew_containerview.isHidden = true
        
        
        btcnew_linelbl.isHidden = false
        ltcnew_linelbl.isHidden = true
        ethnew_linelbl.isHidden = true
        
        
    }
    
    
    @IBAction func ltcnew_btn(_ sender: Any) {
        btcnew_containerview.isHidden = true
        ltcnew_containerview.isHidden = false
        ethnew_containerview.isHidden = true
        
        btcnew_linelbl.isHidden = true
        ltcnew_linelbl.isHidden = false
        ethnew_linelbl.isHidden = true
        
        
        
    }
    
    @IBAction func ethnew_btnacn(_ sender: Any) {
        btcnew_containerview.isHidden = true
        ltcnew_containerview.isHidden = true
        ethnew_containerview.isHidden = false
        
        
        btcnew_linelbl.isHidden = true
        ltcnew_linelbl.isHidden = true
        ethnew_linelbl.isHidden = false
        
        
        
    }
    @IBAction func backToTrade(_ sender: Any)
    {
        self.navigationController?.popViewController(animated: true)
    }
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

            if segue.identifier == "btcNew" {
                let vc = segue.destination as! BtcNewContainerVC
                vc.btcmarketiddelegate = self

            }

            else if segue.identifier == "ltcNew"{

                let vc1 = segue.destination as! LtcNewVC
                vc1.ltcmarketiddelegate = self

            }
            else if segue.identifier == "ethNew"{

                let vc1 = segue.destination as! EthNewVC
                vc1.ethmarketiddelegate = self

            }

        }
    
}
