//
//  OrderHistoryTvCell.swift
//  Bitoct
//
//  Created by Purushottam on 01/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class OrderHistoryTvCell: UITableViewCell {

    @IBOutlet weak var market_lbl: UILabel!
    
    @IBOutlet weak var price_lbl: UILabel!
    @IBOutlet weak var volume_lbl: UILabel!
    
    @IBOutlet weak var ticker_lbl: UILabel!
    @IBOutlet weak var price1_lbl: UILabel!
    
    @IBOutlet weak var volume1_lbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
