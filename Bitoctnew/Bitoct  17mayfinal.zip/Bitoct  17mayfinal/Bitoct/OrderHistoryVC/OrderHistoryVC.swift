//
//  OrderHistoryVC.swift
//  Bitoct
//
//  Created by Purushottam on 01/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class OrderHistoryVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var orderhistory_tableview: UITableView!
    var timerOrderHistory = Timer()
    var getorderhistoryarray = [TradeDataClass](){
        didSet{
            orderhistory_tableview .reloadData()
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        GetOrderHistoryApiHIt()
        
        orderhistory_tableview.register(UINib(nibName: "OrderHistoryTvCell", bundle: nil), forCellReuseIdentifier: "OrderHistoryTvCell")
        
        //timerOrderHistory = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)

        // Do any additional setup after loading the view.
    }

    @IBAction func back_btnacn(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerOrderHistory = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerOrderHistory.invalidate()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @objc func updateData()
    {
        self.GetOrderHistoryApiHIt()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return getorderhistoryarray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrderHistoryTvCell", for: indexPath) as! OrderHistoryTvCell
        
        cell.market_lbl.text = getorderhistoryarray[indexPath.row].Market
        cell.price_lbl.text = getorderhistoryarray[indexPath.row].price
        cell.volume_lbl.text = getorderhistoryarray[indexPath.row].volume
        cell.price1_lbl.text = getorderhistoryarray[indexPath.row].price
        cell.volume1_lbl.text = getorderhistoryarray[indexPath.row].volume
        cell.ticker_lbl.text = getorderhistoryarray[indexPath.row].ticker
        
        return cell
    }
    

}
extension OrderHistoryVC{
    private func GetOrderHistoryApiHIt(){
        let Memberd:String? = UserDefaults.standard.string(forKey: "USERID")
        var myResponse : JSON? = nil
        var myUser : TradeMainMainClass? = nil
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
        
        ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:OrderHistory_URL, viewController: self,paramvalue: Memberd!,paramname: "Memberid", loadercheck: 5, onCompletion: { (canceljson) ->Void in
            
            myResponse = canceljson
            print("ORDER HISTORY DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
                myUser = TradeMainMainClass.init(trademaincassjsin: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
                if myUser?.status == "Succeed"{
                    self.getorderhistoryarray = (myUser?.tradedataclass)!
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
    
}

