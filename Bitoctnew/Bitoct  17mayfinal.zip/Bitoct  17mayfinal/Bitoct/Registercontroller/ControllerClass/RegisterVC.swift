//
//  RegisterVC.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class RegisterVC: UIViewController {
    
    
    @IBOutlet weak var username_text:UITextField!
    @IBOutlet weak var email_text:UITextField!
    @IBOutlet weak var password_text:UITextField!
    @IBOutlet weak var register_btnoutlet:UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        register_btnoutlet.layer.cornerRadius = 5
//        email_text.layer.borderWidth = 1.0
//        email_text.layer.borderColor = UIColor.lightGray.cgColor
//        password_text.layer.borderWidth = 1.0
//        password_text.layer.borderColor = UIColor.lightGray.cgColor
//        username_text.layer.borderWidth = 1.0
//        username_text.layer.borderColor = UIColor.lightGray.cgColor
        
        username_text.attributedPlaceholder = NSAttributedString(string: "   Enter username",
                                                                attributes:[NSAttributedStringKey.foregroundColor: UIColor.gray])
        email_text.attributedPlaceholder = NSAttributedString(string: "   Enter email", attributes: [NSAttributedStringKey.foregroundColor: UIColor.gray])
        
        password_text.attributedPlaceholder = NSAttributedString(string: "   Enter password", attributes: [NSAttributedStringKey.foregroundColor: UIColor.gray])
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func Register_btnacn(_sender:Any)
    {
        
        guard let user = username_text.text?.count, !(user == 0) else {
            Alert.showBasic(title: "", message: "Please Enter Username.", viewController: self)
            return
        }
        guard let email = email_text.text?.count, !(email == 0) else {
            Alert.showBasic(title: "", message: "Please Enter Email.", viewController: self)
            return
        }
        guard let pass = password_text.text?.count, !(pass == 0) else {
            Alert.showBasic(title: "", message: "Please Enter Password.", viewController: self)
            return
        }
        
            RegisterApiHit()
        
        
    }
    
    @IBAction func termncondition_btnacn(_ sender: Any) {
    }
    
    @IBAction func login_btnacn(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
}

extension RegisterVC{
    
    func RegisterApiHit() {
        var myResponse : JSON? = nil
        var myUser : REGISTER? = nil
        
        let para : [String:String] = ["UserName":username_text.text!, "EmailId":email_text.text! ,"Password":password_text.text!]
        
        ApiManager.sharedInstance.fetchResponseFromUrl(urlStr:REGISTER_URL, paraMeters: para,viewController: self, loadercheck: 6, onCompletion: { (registerjson) ->Void in
            
            myResponse = registerjson
            myUser = REGISTER(registerjson:myResponse!)
            print("REGISTER  API IS",myResponse!)
            print("message = ",myUser?.Message as Any)
            print(myUser?.status as Any)
            
            if myUser?.status == "Succeed"{
                Alert.showBasic(title: "", message: (myUser?.Message)!, viewController: self)

                
            }
            else{
                Alert.showBasic(title: "", message: (myUser?.Message)!, viewController: self)
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
    
   
    
}
