//
//  RegisterResponse.swift
//  Bitoct
//
//  Created by Purushottam on 26/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class REGISTER {
    
    var status = String()
    var Message = String()
    
    init(registerjson:JSON) {
        
        self.Message = registerjson["Message"].stringValue
        self.status = registerjson["status"].stringValue
    }
}


