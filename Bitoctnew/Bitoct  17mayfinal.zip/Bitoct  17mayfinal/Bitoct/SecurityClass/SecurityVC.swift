//
//  SecurityVC.swift
//  Bitoct
//
//  Created by Purushottam on 09/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class SecurityVC: UIViewController {
    
    
    
    @IBAction func back_btnacn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func googleaunth_btnacn(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DownloadninstallVC") as! DownloadninstallVC
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func changepassword_btnacn(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangePasswordVC") as! ChangePasswordVC
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    

}
