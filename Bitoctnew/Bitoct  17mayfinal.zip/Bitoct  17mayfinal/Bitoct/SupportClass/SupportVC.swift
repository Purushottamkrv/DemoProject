//
//  SupportVC.swift
//  Bitoct
//
//  Created by Purushottam on 09/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class SupportVC: UIViewController {

    @IBOutlet weak var web_view: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //web_view.loadRequest(URLRequest(url: URL(string: "http://www.google.com")!))
        web_view.loadRequest(URLRequest(url: URL(string: "https://bitoct.com/Support")!))


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func back_btnacn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
