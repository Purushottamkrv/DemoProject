//
//  BuysellOpenTvCell.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class BuysellOpenTvCell: UITableViewCell {
    
    
    @IBOutlet weak var main_view: UIView!
    
    @IBOutlet weak var time_btnoutlet: UIButton!
    
    @IBOutlet weak var price_btnoutlet: UIButton!
    
    @IBOutlet weak var volume_btnoutlet: UIButton!

    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
