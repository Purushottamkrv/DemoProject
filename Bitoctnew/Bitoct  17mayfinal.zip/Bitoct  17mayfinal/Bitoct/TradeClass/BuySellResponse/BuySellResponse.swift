//
//  BuySellResponse.swift
//  Bitoct
//
//  Created by Purushottam on 06/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class BuySellClass {
    
    var status = String()
    var Message = String()
    
    var buyselldatajson:JSON?
    
    init(buyselljson:JSON) {
        self.status = buyselljson["status"].stringValue
        self.Message = buyselljson["Message"].stringValue
    }
}
