//
//  BuySellCurrencyChekResponse.swift
//  Bitoct
//
//  Created by Purushottam on 05/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class BuySellCurrencyChekMainClass {
    
    var status = String()
    var Message = String()
    
    var busellcurrencychekdataclass :[BuySellCurrencyChekDataClass] = []
    var buyselldatajson:JSON?
    
    init(buysellcurrencychekmainclassjson:JSON) {
        self.status = buysellcurrencychekmainclassjson["status"].stringValue
        self.Message = buysellcurrencychekmainclassjson["Message"].stringValue
        self.buyselldatajson = buysellcurrencychekmainclassjson["Data"]
        
        if let buyselldatadataarray = self.buyselldatajson{
            for i in 0..<buyselldatadataarray.count{
                
                let datasingle = BuySellCurrencyChekDataClass.init(buysellcurrencychekdataclassjson: buyselldatadataarray[i])
                busellcurrencychekdataclass.append(datasingle)
            }
        }
    }
}

class BuySellCurrencyChekDataClass {
    
    var key = String()
    var toamount_tot = String()
    var tocurrency = String()
    var fromamount = String()
    var fromcurrency = String()
     var price = String()
    var fee = String()
    var  toamount = String()
    var isok = String()
    init(buysellcurrencychekdataclassjson:JSON) {
        self.key = buysellcurrencychekdataclassjson["key"].stringValue

        self.toamount_tot = buysellcurrencychekdataclassjson["toamount_tot"].stringValue
        self.tocurrency = buysellcurrencychekdataclassjson["tocurrency"].stringValue
        self.fromamount = buysellcurrencychekdataclassjson["fromamount"].stringValue
        self.fromcurrency = buysellcurrencychekdataclassjson["fromcurrency"].stringValue
        
        self.price = buysellcurrencychekdataclassjson["price"].stringValue
        self.fee = buysellcurrencychekdataclassjson["fee"].stringValue
        self.toamount = buysellcurrencychekdataclassjson["toamount"].stringValue
        self.isok = buysellcurrencychekdataclassjson["isok"].stringValue
        
    }
    
}


