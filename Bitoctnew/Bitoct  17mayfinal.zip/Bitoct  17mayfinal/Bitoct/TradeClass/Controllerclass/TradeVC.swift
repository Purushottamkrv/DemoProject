//
//  TradeVC.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class TradeVC: UIViewController {
    
    var marketIdStr = String()
    var marketAssetCodeStr = String()
    @IBOutlet weak var title_lbl: UILabel!
    @IBOutlet weak var buyline_lbl: UILabel!
    @IBOutlet weak var sellline_lbl: UILabel!
    @IBOutlet weak var buycontainer_view: UIView!
    @IBOutlet weak var sellcontainer_view:UIView!
    @IBOutlet weak var opencontainer_view:UIView!
    @IBOutlet weak var openline_lbl: UILabel!
    
    @IBOutlet weak var buybtn_outlet: UIButton!
    @IBOutlet weak var sellbtn_outlet: UIButton!
    @IBOutlet weak var openorderbtn_outlet: UIButton!
    var height = Float()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buybtn_outlet.setTitleColor(UIColor(red:0.0, green:132.0, blue:211.0, alpha:1.0), for: .normal)
        buycontainer_view.isHidden = false
        sellcontainer_view.isHidden = true
        opencontainer_view.isHidden = true
        buyline_lbl.isHidden = false
        sellline_lbl.isHidden = true
        openline_lbl.isHidden = true
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//        guard let titleStr = UserDefaults.standard.string(forKey: "MarketCode") else {
//            title_lbl.text = "BSS/BTC"
//            return
//        }
        if marketAssetCodeStr == nil || marketAssetCodeStr == ""
        {
            title_lbl.text = "BSS/BTC"
        }
        else
        {
            title_lbl.text = marketAssetCodeStr
        }
    }
    
    override func viewDidLayoutSubviews() {
        
        height = Float(self.buycontainer_view.frame.size.height)
        
        print("height is",height)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "Buy" {
            let vc = segue.destination as! BuyContainerVC
            vc.getheight = height
            vc.marketID = marketIdStr
            vc.marketCode = marketAssetCodeStr
        }
            
        else if segue.identifier == "sell"{
            
            let vc1 = segue.destination as! SellcontainerVC
            vc1.getheight = height
            vc1.marketID = marketIdStr
            vc1.marketCode = marketAssetCodeStr
        }
        
    }
    @IBAction func corner_btnacn(_ sender: Any) {
    }
    
    
    @IBAction func buy_btnacn(_ sender: Any) {
        
        buycontainer_view.isHidden = false
        sellcontainer_view.isHidden = true
        opencontainer_view.isHidden = true
        buyline_lbl.isHidden = false
        sellline_lbl.isHidden = true
        openline_lbl.isHidden = true
        
    }
    
   
    @IBAction func sell_btnacn(_ sender: Any) {
        
        buycontainer_view.isHidden = true
        sellcontainer_view.isHidden = false
        opencontainer_view.isHidden = true
        buyline_lbl.isHidden = true
        sellline_lbl.isHidden = false
        openline_lbl.isHidden = true
    }
    @IBAction func openorder_btnacn(_ sender: Any) {
        
        buycontainer_view.isHidden = true
        sellcontainer_view.isHidden = true
        opencontainer_view.isHidden = false
        buyline_lbl.isHidden = true
        sellline_lbl.isHidden = true
        openline_lbl.isHidden = false
    }
    @IBAction func markettrade_btnacn(_ sender: Any) {
    
    }
    
    @IBAction func OrderHistory_btnacn(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "OrderHistoryVC") as! OrderHistoryVC
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func bss_btnacn(_ sender: Any) {
        
//        let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
//        tabVC.selectedIndex = 1
//        self.navigationController?.pushViewController(tabVC, animated: true)
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MarketNewVC") as! MarketNewVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
}
