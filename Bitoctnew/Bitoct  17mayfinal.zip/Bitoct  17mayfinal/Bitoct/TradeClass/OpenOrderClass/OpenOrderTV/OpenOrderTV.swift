//
//  OpenOrderTV.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

protocol MyProtocol
{
    func cancelApiHIt(orderid:Int)
}

class OpenOrderTV: UITableView,UITableViewDelegate,UITableViewDataSource {
    
    
    var delegates:MyProtocol!
    
    
    var orderid = String()
    
    var tradadataarray = [TradeDataClass](){
        didSet{
            reloadData()
        }
    }
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tradadataarray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TradeTvCommonCell", for: indexPath) as! TradeTvCommonCell
        
        cell.price_lbl.text = tradadataarray[indexPath.row].price 
        cell.volume_lbl.text = tradadataarray[indexPath.row].volume
        cell.ticker_lbl.text = tradadataarray[indexPath.row].ticker
        cell.market_lbl.text = tradadataarray[indexPath.row].Market
        cell.cancleBtn.tag = Int(tradadataarray[indexPath.row].tickerid)!
        
        cell.round_uiview.layer.cornerRadius = cell.round_uiview.frame.size.height/2
        cell.round_uiview.layer.borderWidth = 2.0
        cell.round_uiview.layer.borderColor = UIColor .red.cgColor
        //cell.round_uiview.clipsToBounds = true
        cell.round_uiview.layer.masksToBounds = true
        cell.cancleBtn.addTarget(self, action: #selector(buttonClicked), for: UIControlEvents.touchUpInside)

       // cell.cancel_btnacn(tradadataarray[indexPath.row].tickerid)
        
        
        
        return cell
    }
    @objc func buttonClicked(sender:UIButton) {
        let getorderid:Int = sender.tag
        
        delegates.cancelApiHIt(orderid: (getorderid))
    }


}
