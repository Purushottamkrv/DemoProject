//
//  TradeTvCommonCell.swift
//  Bitoct
//
//  Created by Purushottam on 01/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class TradeTvCommonCell: UITableViewCell {
    
    @IBOutlet weak var market_lbl: UILabel!
    @IBOutlet weak var volume_lbl: UILabel!
    @IBOutlet weak var ticker_lbl: UILabel!
    @IBOutlet weak var price_lbl: UILabel!
    
    @IBOutlet weak var round_uiview: UIView!
    
    @IBOutlet weak var cancleBtn:UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
