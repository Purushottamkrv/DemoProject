//
//  OpenOrderVC.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class OpenOrderVC: UIViewController,MyProtocol {
    
    @IBOutlet weak var openorder_tableview:OpenOrderTV!
    var timerOpen = Timer()
    
   let openordervc = UIViewController()
    var orderid = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        openorder_tableview.delegates = self
        TradeApiHIt()
        
    openorder_tableview.register(UINib(nibName: "TradeTvCommonCell", bundle: nil), forCellReuseIdentifier: "TradeTvCommonCell")
        
        //timerOpen = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @objc func updateData()
    {
        self.TradeApiHIt()
    }
   /// @IBAction func cancel_btnacn(_ sender: UIButton) {
        
       // let buttonRow = (sender as AnyObject).tag// }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerOpen = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerOpen.invalidate()
    }
    
}

extension OpenOrderVC{
     func TradeApiHIt(){
        let Memberd:String? = UserDefaults.standard.string(forKey: "USERID")
        var myResponse : JSON? = nil
        var myUser : TradeMainMainClass? = nil
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
        
        ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:OpenHistory_URL, viewController: self,paramvalue: Memberd!,paramname: "MemberId", loadercheck: 5, onCompletion: { (canceljson) ->Void in
            
            myResponse = canceljson
            print("TRADE DATA API IS",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
                myUser = TradeMainMainClass.init(trademaincassjsin: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
                if myUser?.status == "Succeed"{
                    self.openorder_tableview.tradadataarray = (myUser?.tradedataclass)!
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
    
}



extension OpenOrderVC{
    func cancelApiHIt(orderid:Int)
    {
        var myResponse : JSON? = nil
        
        var myUser : TradeMainMainClass? = nil
        ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:Cancel_order_URL, viewController: self,paramvalue: String(orderid),paramname: "orderid", loadercheck: 5, onCompletion: { (Tradejson) ->Void in
            
            myResponse = Tradejson
            print("CANCEL DATA API IS",myResponse!)
            myUser = TradeMainMainClass.init(trademaincassjsin: myResponse!)
            print("status = ",myUser?.status as Any)
            print(myUser?.status as Any)
            if myUser?.status == "Succeed"{
                self.TradeApiHIt()
            }
            else{
                Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
    
}











