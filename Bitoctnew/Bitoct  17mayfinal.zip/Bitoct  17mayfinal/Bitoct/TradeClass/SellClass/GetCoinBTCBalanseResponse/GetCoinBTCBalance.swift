//
//  GetCoinBTCBalance.swift
//  Bitoct
//
//  Created by Purushottam on 03/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetCoinBTCBalanceMainClass {
    var status = String()
    var Message = String()
    
    
    
    var getcoinbtcbalancedataclass:[GetCoinBtcBalanceDataClass] = []
    var getcoinbtcdatajson:JSON?
    
    
    init(getcoinbtcmainclassjson:JSON) {
        self.status = getcoinbtcmainclassjson["status"].stringValue
        self.Message = getcoinbtcmainclassjson["Message"].stringValue
        
        self.getcoinbtcdatajson = getcoinbtcmainclassjson["Data"]
        
        if let dataarray = self.getcoinbtcdatajson  {
            
            for i in 0..<dataarray.count{
               let singledata = GetCoinBtcBalanceDataClass.init(getcoinbtcdatajson: dataarray[i])
                getcoinbtcbalancedataclass.append(singledata)
            }
        }
    }
}

class GetCoinBtcBalanceDataClass {
    var TotalCoin = String()
    var BalBTC = String()
    var CoinPrice = String()
    var BTCPrice = String()
    var buyprice = String()
    var sellprice = String()
    init(getcoinbtcdatajson:JSON) {
        
        self.TotalCoin = getcoinbtcdatajson["TotalCoin"].stringValue
        self.BalBTC = getcoinbtcdatajson["BalBTC"].stringValue
        
        self.CoinPrice = getcoinbtcdatajson["CoinPrice"].stringValue
        self.BTCPrice = getcoinbtcdatajson["BTCPrice"].stringValue
        
        self.buyprice = getcoinbtcdatajson["buyprice"].stringValue
        self.sellprice = getcoinbtcdatajson["sellprice"].stringValue

        
        
        
    }
    
}
