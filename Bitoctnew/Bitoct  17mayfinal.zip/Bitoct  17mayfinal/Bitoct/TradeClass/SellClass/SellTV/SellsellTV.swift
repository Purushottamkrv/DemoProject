//
//  SellsellTV.swift
//  Bitoct
//
//  Created by Purushottam on 02/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class SellsellTV: UITableView,UITableViewDataSource,UITableViewDelegate {
    
    
    var markettradeArray = [MarketDataClass](){
        
        didSet{
            
             reloadData()
        }
    }

   
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        self.delegate = self
        self.dataSource = self
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
        self.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return markettradeArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BuysellOpenTvCell", for: indexPath) as! BuysellOpenTvCell
        
        let str1 = markettradeArray[indexPath.row].ticker
        let myarray = str1.components(separatedBy:" ")
        //let datestr = myarray[0]
        let timestr = myarray[1]
        if markettradeArray[indexPath.row].tradetype == "1"
        {
            
            cell.price_btnoutlet.setTitleColor(UIColor (red: 87.0/255.0, green: 177.0/255.0, blue: 0.0/255, alpha: 1), for: .normal)
            cell.volume_btnoutlet.setTitleColor(UIColor (red: 87.0/255.0, green: 177.0/255.0, blue: 0.0/255, alpha: 1), for: .normal)
        }
        else
        {
            
            cell.price_btnoutlet.setTitleColor(UIColor (red: 252.0/255.0, green: 0.0/255.0, blue: 108.0/255, alpha: 1), for: .normal)
            
            cell.volume_btnoutlet.setTitleColor(UIColor (red: 252.0/255.0, green: 0.0/255.0, blue: 108.0/255, alpha: 1), for: .normal)
        }
        cell.time_btnoutlet.setTitle(timestr, for: .normal)
        cell.price_btnoutlet.setTitle(markettradeArray[indexPath.row].price, for: .normal)
        cell.volume_btnoutlet.setTitle(markettradeArray[indexPath.row].volume, for: .normal)
        
        return cell
    }


}
