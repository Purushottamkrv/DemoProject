//
//  SellcontainerVC.swift
//  Bitoct
//
//  Created by Purushottam on 28/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit
import Charts
import SwiftyJSON
import Alamofire

class SellcontainerVC: UIViewController,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UIScrollViewDelegate {
    
    @IBOutlet weak var combinedChartView: CombinedChartView!
    let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Dec", "Dec", "Dec", "Dec", "Dec", "Dec", "Dec"]
    let unitsSoldLine = [10.0, 12.0, 11.0, 13.0, 9.0, 10.5, 11.5, 12.0, 10.0, 10.5, 12.3, 13.0, 11.5, 10.0,13.5, 11.5, 12.0, 12.5, 9.5]
    
    let unitsSoldBar = [2.0, 4.0, 6.0, 3.0, 4.0, 5.5, 4.0, 3.5, 2.5, 4.0, 5.7, 4.0, 8.0, 9.0, 5.9, 6.0, 2.0, 6.5, 5.4]
    var highArray = [Double]()
    var lowArray = [Double]()
    var volumeArray = [Double]()
    var timeArray = [String]()
    var openArray = [Double]()
    var volumeArray0 = [Double]()
    var volumeArray1 = [Double]()
    var timeArray0 = [String]()
    var timeArray1 = [String]()
    var tradeTrypeArray = [String]()
    var priceArray = [0, 0.00000002, 0.00000004, 0.00000006, 0.00000006, 0.00000008, 0.0000001]
    @IBOutlet weak var scroll_view:UIScrollView?
    @IBOutlet weak var pricelabel: UILabel!
    @IBOutlet weak var viewsell: UIView!
    @IBOutlet weak var marketLabel: UILabel!
    @IBOutlet weak var totalAmntHghtConstrnt: NSLayoutConstraint!
    private let myArray: NSArray = ["Limit Order","Market Order","Stop-Limit"]
    private var myTableView: UITableView!
    var marketOrderTag = String()
    var SELLPRICE = String()
    @IBOutlet weak var tradedetail_popview: UIView!
    @IBOutlet weak var tradedetail_tableview: UITableView!
    @IBOutlet weak var blur_btnoutlet: UIButton!
    var getheight = Float()
    var marketID = String()
    var marketCode = String()
    var marketCodeNew = String()
    var string = String()
    var feeStr = String()
    var netTotalStr = String()
    var totalAmnt = Float()
    var balStr = String()
    @IBOutlet weak var lineChartView: LineChartView!
    @IBOutlet weak var barChartView: BarChartView!
    @IBOutlet weak var limit_orderview: UIView!
    @IBOutlet weak var btcprice_text: UITextField!
    @IBOutlet weak var sellprice_txt: UITextField!
    @IBOutlet weak var totalamount_txt: UITextField!
    @IBOutlet weak var totalcoin_lbl: UILabel!
    @IBOutlet weak var equivalent_lbl: UILabel!
    @IBOutlet weak var sell_tableview:SellsellTV!
    @IBOutlet weak var first_tableview: UITableView!
    @IBOutlet weak var second_tableview: UITableView!
    
    var timerSellCV = Timer()
    var sellprice = String()
    var tradePrice = [String]()
    var tradeVolume = [String]()
    var tradeTotal = [String]()
    var getcoinbtcbalanceArray = [GetCoinBtcBalanceDataClass]()
    var firsttablearray = [BuySellDataClass]()
    {
        didSet{
            first_tableview .reloadData()
        }
    }
    var secondtablearray = [BuySellDataClass]()
    {
        didSet{
            
            second_tableview .reloadData()
            myTableView .reloadData()
        }
    }
    override func viewDidLoad() {
        
        tradedetail_popview.isHidden = true
        blur_btnoutlet.isHidden = true
        ////////****************tableview/////////////////////////
        marketLabel.isHidden = true
        myTableView = UITableView(frame: CGRect(x: 20, y: limit_orderview.frame.origin.y+limit_orderview.frame.size.height, width: 120, height: 150))
        myTableView.register(UITableViewCell.self, forCellReuseIdentifier: "MyCell")
        myTableView.backgroundColor = UIColor.black
        myTableView.dataSource = self
        myTableView.delegate = self
        self.view.addSubview(myTableView)
         myTableView.isHidden = true

        print("gettt heigh is",getheight)
        print("stringvalueis",string)
        print("stringvalueis",marketID)
        print("stringvalueis",marketCode)
        ////////////////*tableview////
        super.viewDidLoad()
        
        tradedetail_tableview.register(UINib(nibName: "BuysellOpenTvCell", bundle: nil), forCellReuseIdentifier: "BuysellOpenTvCell")
        
        sell_tableview.register(UINib(nibName: "BuysellOpenTvCell", bundle: nil), forCellReuseIdentifier: "BuysellOpenTvCell")
        first_tableview.register(UINib(nibName: "OrderTvSecondcell", bundle: nil), forCellReuseIdentifier: "OrderTvSecondcell")
        second_tableview.register(UINib(nibName: "OrderTvCommoncell", bundle: nil), forCellReuseIdentifier: "OrderTvCommoncell")
        
        //timerSellCV = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//        guard let marketid = UserDefaults.standard.string(forKey: "MarketID") else {
//            self.marketID = "3"
//            return
//        }
        marketOrderTag = "L"
        if marketID == nil || marketID == ""
        {
            marketID = "3"
        }
        else
        {
            
        }
        if marketCode == nil || marketCode == ""
        {
            self.marketCodeNew = "BSS"
            print("MarketCode=",self.marketCodeNew)
            pricelabel.text = "Price(BTC)"
        }
        else
        {
            let myarray = marketCode.components(separatedBy:"/")
            let marketcodestr = myarray[0]
            self.marketCodeNew = marketcodestr
            print("MarketCode=",self.marketCodeNew)
            pricelabel.text = "Price(" + myarray[1] + ")"
        }
        firsttableApiHIt()
        SecondtableApiHIt()
        MarketTradeApiHIt()
        GetCoinbtcbalanceApiHIt()
        GraphGetApiHIt()
        
        timerSellCV = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerSellCV.invalidate()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @objc func updateData()
    {
        self.firsttableApiHIt()
        self.SecondtableApiHIt()
        self.MarketTradeApiHIt()
        self.GetCoinbtcbalanceApiHIt()
        self.GraphGetApiHIt()
    }
    func setChart(xValues: [String], yValuesLineChart: [Double], yValuesBarChart: [Double],yValuesBarChart0: [Double],yValuesBarChart1: [Double]) {
        //combinedChartView.noDataText = "Please provide data for the chart."
        lineChartView.noDataText = "Please provide data for the chart."
        barChartView.noDataText = "Please provide data for the chart."
        
        var yVals1 : [ChartDataEntry] = [ChartDataEntry]()
        var yVals2 : [BarChartDataEntry] = [BarChartDataEntry]()
        var yVals3 : [BarChartDataEntry] = [BarChartDataEntry]()
        var yVals4 : [BarChartDataEntry] = [BarChartDataEntry]()
        
        for i in 0..<volumeArray.count {
            
            yVals2.append(BarChartDataEntry(x: Double(i), y: yValuesBarChart[i]))
            
        }
        for i in 0..<volumeArray0.count {
            
            yVals3.append(BarChartDataEntry(x: Double(i), y: yValuesBarChart0[i]))
            
        }
        for i in 0..<volumeArray1.count {
            
            yVals4.append(BarChartDataEntry(x: Double(i), y: yValuesBarChart1[i]))
            
        }
        for j in 0..<openArray.count{
            yVals1.append(ChartDataEntry(x: Double(j), y: openArray[j] ))
        }
        print("Volume1 Count = ",volumeArray1.count)
        print("Volume1  = ",volumeArray1)
        print("Volume0 Count = ",volumeArray0.count)
        print("Volume0  = ",volumeArray0)
        print("Volume Count = ",volumeArray.count)
        print("Volume  = ",volumeArray)
        
        let lineChartSet = LineChartDataSet(values: yVals1, label: "Line Data")
        let barChartSet: BarChartDataSet = BarChartDataSet(values: yVals2, label: "Bar Data")
        ////
        let barCharBuySet = BarChartDataSet(values: yVals3, label: "Sell")
        barCharBuySet.colors = [NSUIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0)]
        barCharBuySet.drawValuesEnabled = false
        
        let barCharSellSet = BarChartDataSet(values: yVals4, label: "Buy")
        barCharSellSet.colors = [NSUIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0)]
        barCharSellSet.drawValuesEnabled = false
        ////
        lineChartSet.circleColors = [UIColor.clear]
        lineChartSet.colors = [UIColor.init(red: 25.0/255.0, green: 105.0/255.0, blue: 129.0/255.0, alpha: 1.0)]
        lineChartSet.circleHoleColor = UIColor.clear
        lineChartSet.valueTextColor = UIColor.clear
        lineChartSet.valueColors = [NSUIColor.clear]
        
        let gradientColor = [UIColor.init(red: 19.0/255.0, green: 106.0/255.0, blue: 144.0/255.0, alpha: 1.0).cgColor, UIColor.init(red: 19.0/255.0, green: 106.0/255.0, blue: 144.0/255.0, alpha: 1.0).cgColor] as CFArray
        let colorPosition: [CGFloat] = [1.0, 1.0]
        
        guard let gradient = CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: gradientColor, locations: colorPosition) else{
            print("gradient error")
            return
        }
        lineChartSet.fill = Fill.fillWithLinearGradient(gradient, angle: 180.0)
        lineChartSet.drawFilledEnabled = true
        /* for j in 0..<yValuesBarChart.count
         {
         print("Value Bar = ",yValuesBarChart[j])
         //            if yValuesBarChart[j] == 4.0 || yValuesBarChart[j] == 5.0 || yValuesBarChart[j] == 5.5
         if j == 3 || j == 5 || j == 9 || j == 14
         {
         //barChartSet.colors = [NSUIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0)]
         barChartSet.setColor(NSUIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0))
         
         //barChartSet.setColor(NSUIColor.gray)
         }
         else
         {
         // barChartSet.colors = [NSUIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0)]
         barChartSet.setColor(NSUIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0))
         //barChartSet.setColor(NSUIColor.gray)
         }
         }*/
        var colorarray = [UIColor]()
        for i in 0..<tradeTrypeArray.count
        {
            let colorr = setColorr(value: self.tradeTrypeArray[i])
            colorarray.append(colorr)
        }
        barChartSet.colors = colorarray
        barChartSet.valueColors = [NSUIColor.clear]
        //barChartSet.formSize = 2.0
        barChartSet.valueTextColor = UIColor.clear
        
        //        let data: CombinedChartData = CombinedChartData()
        //        data.barData = BarChartData(dataSets: [barChartSet])
        //        data.lineData = LineChartData(dataSets: [lineChartSet])
        //        data.barData.barWidth = 0.3
        //        combinedChartView.data = data
        
        let data1 = LineChartData()
        data1.addDataSet(lineChartSet)
        lineChartView.data = data1
        lineChartView.chartDescription?.text = ""
        lineChartView.leftAxis.drawAxisLineEnabled = false
        lineChartView.leftAxis.drawGridLinesEnabled = false
        lineChartView.leftAxis.gridColor = NSUIColor.clear
        lineChartView.rightAxis.drawGridLinesEnabled = false
        lineChartView.rightAxis.drawAxisLineEnabled = false
        lineChartView.xAxis.drawGridLinesEnabled = false
        lineChartView.gridBackgroundColor = NSUIColor.clear
        lineChartView.gridBackgroundColor = UIColor.clear
        lineChartView.backgroundColor = UIColor.black
        lineChartView.xAxis.labelTextColor = UIColor.clear
        lineChartView.xAxis.labelPosition = .bottom
        lineChartView.xAxis.granularity = 2
        lineChartView.legend.enabled = false
        
        let data2 = BarChartData(dataSets: [barCharBuySet, barCharSellSet])
        //data2.groupWidth(groupSpace: 0, barSpace: 0)
        //data2.addDataSet(barCharBuySet)
        //data2.addDataSet(barCharSellSet)
        //data2.addDataSet(barChartSet)
        data2.barWidth = 0.8
        barChartView.data = data2
        
        barChartView.chartDescription?.text = ""
        barChartView.leftAxis.drawGridLinesEnabled = false
        barChartView.leftAxis.drawAxisLineEnabled = false
        barChartView.leftAxis.gridColor = NSUIColor.clear
        barChartView.rightAxis.drawGridLinesEnabled = false
        barChartView.rightAxis.drawAxisLineEnabled = false
        barChartView.xAxis.drawGridLinesEnabled = false
        barChartView.backgroundColor = UIColor.black
        barChartView.xAxis.labelTextColor = UIColor.clear
        barChartView.xAxis.labelPosition = .bottom
        barChartView.legend.enabled = false
        barChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values:timeArray1)
        barChartView.xAxis.granularity = 1
        
    }
    func setColorr(value: String) -> UIColor{
        
        /* if self.tradeTrypeArray.count > 0
         {
         for i in 0..<tradeTrypeArray.count
         {
         if tradeTrypeArray[i] == "0"
         {
         return UIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0)
         }
         else
         {
         return UIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0)
         }
         }
         }
         
         else
         {
         return UIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0)
         }*/
        if(value == "0"){
            return UIColor.init(red:87.0/255.0 , green: 177.0/255.0, blue: 0.0/255.0, alpha: 1.0)
        }
            
            /*else if(value > 1000){
             return UIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0)
             }*/
            
        else { //In case anything goes wrong
            return UIColor.init(red:252.0/255.0 , green: 0.0/255.0, blue: 108.0/255.0, alpha: 1.0)
        }
    }
    @IBAction func sell_btcacn(_ sender: Any) {
        if btcprice_text.text?.count == 0
        {
            Alert.showBasic(title: "", message:"Please enter price.", viewController: self)
        }
        else if (btcprice_text.text?.contains("0.00000000"))!
        {
            Alert.showBasic(title: "", message:"Price must be greater than 0.", viewController: self)
        }
        else if sellprice_txt.text?.count == 0
            
        {
            Alert.showBasic(title: "", message:"Please enter amount.", viewController: self)
        }
        else if (sellprice_txt.text?.contains("0.00000000"))!
        {
            Alert.showBasic(title: "", message:"Amount must be greater than 0.", viewController: self)
        }
        else
        {
            let feetotal = (sellprice as NSString).floatValue * (btcprice_text.text! as NSString).floatValue * 0.0020
             print("Feetotal= ",feetotal)
            let numberFormatter = NumberFormatter()
            numberFormatter.numberStyle = .decimal
            numberFormatter.maximumFractionDigits = 8
            feeStr = numberFormatter.string(for: feetotal)!
            //feeStr = String(feetotal)
           print("FeetotalString= ",feeStr)
            
            let numberFormatterr = NumberFormatter()
            numberFormatterr.numberStyle = .decimal
            numberFormatterr.maximumFractionDigits = 8
            print("Total Amount= ",totalAmnt)
            netTotalStr = numberFormatterr.string(for: totalAmnt - feetotal)!
            //netTotalStr = String(totalAmnt + feetotal)
            print("Total Amount String= ",netTotalStr)
            print("Balance String= ",balStr)
            
            if feetotal < 0.00000020
            {
                
                Alert.showBasic(title: "Alert", message:"Fee must add up to 0.00000020 BTC.", viewController: self)
            }
            else if (sellprice as NSString).floatValue > (totalcoin_lbl.text! as NSString).floatValue//else if (netTotalStr as NSString).floatValue > (balStr as NSString).floatValue
            {
                Alert.showBasic(title: "Alert", message:"Insufficient balance.", viewController: self)
            }
            else
            {
                SellcurrencyChekApiHit()
            }
        }
    }
    @IBAction func limitorder_btnacn(_ sender: Any){
        
        myTableView.isHidden = false
        
        
        
    }
    @IBAction func blur_btnacn(_ sender: Any) {
        tradedetail_popview.isHidden = true
        blur_btnoutlet.isHidden = true
    }
    @IBAction func confirm_btnacn(_ sender: Any) {
        
        tradedetail_popview.isHidden = true
        blur_btnoutlet.isHidden = true
        SellcurrencyChekApiHitAgain()
    }
    
    @IBAction func cancel_btnacn(_ sender: Any) {
        tradedetail_popview.isHidden = false
        
    }
  func scrollViewDidScroll(_ scrollView: UIScrollView) {
        //scroll_view?.contentSize = CGSize(width: self.view.frame.size.width, height: CGFloat(getheight*2))
   }
}
extension SellcontainerVC{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView  == first_tableview{
            return firsttablearray.count
        }
        else if tableView == second_tableview{
            return secondtablearray.count
        }
        
        else if tableView == myTableView{
            return myArray.count
        }
        else
        {
            return tradeTotal.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == first_tableview {
            let cell = tableView.dequeueReusableCell(withIdentifier: "OrderTvSecondcell", for: indexPath) as!OrderTvSecondcell
            
            let priceFloat = Float(firsttablearray[indexPath.row].price)
            let numberFormatter = NumberFormatter()
            numberFormatter.numberStyle = .decimal
            numberFormatter.maximumFractionDigits = 8
            cell.price_lbl.text = numberFormatter.string(for: priceFloat)!
            
            let amntFloat = Float(firsttablearray[indexPath.row].amount)
            let numberFormatterr = NumberFormatter()
            numberFormatterr.numberStyle = .decimal
            numberFormatterr.maximumFractionDigits = 3
            cell.amount_lbl.text = numberFormatterr.string(for: amntFloat)!
            return cell
        }
        else  if tableView == second_tableview{
            let cell = tableView.dequeueReusableCell(withIdentifier: "OrderTvCommoncell", for: indexPath) as! OrderTvCommoncell
            
            let priceFloat = Float(secondtablearray[indexPath.row].price)
            let numberFormatter = NumberFormatter()
            numberFormatter.numberStyle = .decimal
            numberFormatter.maximumFractionDigits = 8
            cell.price_lbl.text = numberFormatter.string(for: priceFloat)!
            
            let amntFloat = Float(secondtablearray[indexPath.row].amount)
            let numberFormatterr = NumberFormatter()
            numberFormatterr.numberStyle = .decimal
            numberFormatterr.maximumFractionDigits = 3
            cell.amountl_lbl.text = numberFormatterr.string(for: amntFloat)!
            return cell
        }
        else if tableView == myTableView{
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath as IndexPath)
            cell.contentView.backgroundColor = UIColor.black
            cell.textLabel!.text = "\(myArray[indexPath.row])"
            cell.textLabel?.textColor = UIColor.white
            cell.textLabel?.font = UIFont.systemFont(ofSize: 12.0)
            return cell
            
            
        }
        else {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "BuysellOpenTvCell", for: indexPath) as! BuysellOpenTvCell
            cell.time_btnoutlet.setTitle(tradePrice[indexPath.row], for: .normal)
            cell.price_btnoutlet.setTitle(tradeVolume[indexPath.row], for: .normal)
            cell.volume_btnoutlet.setTitle(tradeTotal[indexPath.row], for: .normal)
            return cell
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if tableView == myTableView
        {
            if indexPath.row == 1
            {
                self.totalAmntHghtConstrnt.constant = 0
                self.viewsell.isHidden = true
                self.marketLabel.isHidden = false
                self.marketLabel.text = (myArray[indexPath.row] as! String)
                self.myTableView.isHidden = true
                marketOrderTag = "M"
                self.sellprice_txt.text = ""
                self.totalamount_txt.text = ""
            }
            else
            {
                self.totalAmntHghtConstrnt.constant = 30
                self.viewsell.isHidden = false
                self.marketLabel.isHidden = true
                self.myTableView.isHidden = true
                marketOrderTag = "L"
                self.sellprice_txt.text = ""
                self.totalamount_txt.text = ""
            }
        }
        
        if tableView == first_tableview
        {
            let priceFloat = Float(firsttablearray[indexPath.row].price)
            let numberFormatter = NumberFormatter()
            numberFormatter.numberStyle = .decimal
            numberFormatter.maximumFractionDigits = 8
            self.btcprice_text.text =  numberFormatter.string(for: priceFloat)!
            
            sellprice = self.sellprice_txt.text!
            print("sell price string",string)
            print("sell price value",sellprice)
            if sellprice.count == 0
            {
                self.totalamount_txt.text = ""
            }
            else
            {
                
                totalAmnt = (sellprice as NSString).floatValue * (btcprice_text.text! as NSString).floatValue
                let numberFormatter = NumberFormatter()
                numberFormatter.numberStyle = .decimal
                numberFormatter.maximumFractionDigits = 20
                let stringg = numberFormatter.string(for: totalAmnt)!
                self.totalamount_txt.text = stringg
                
                
            }
        }
        
        if tableView == tradedetail_tableview {
            
        }
        
        
    }
}
    
extension SellcontainerVC{
    private func MarketTradeApiHIt(){
        var myResponse : JSON? = nil
        var myUser : MarketMainClass? = nil
        var url = String()
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
       
        if self.marketID.contains("&live=1") {
            url = GetTradeHistoryByAMrket_LiveURL
        }
        else{
            url = GetTradeHistoryByAMrket_URL
        }
            ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:url, viewController: self,paramvalue: self.marketID,paramname: "marketid", loadercheck: 5, onCompletion: { (Pairjson) ->Void in
            myResponse = Pairjson
            //self.sell_tableview?.markettradeArray.removeAll()
            print(" MARKET TRADE DATA FIX ID API IS",myResponse!)
            DispatchQueue.main.async {
                    print("This is run on the main queue, after the previous code in outer block")
                
                    myUser = MarketMainClass.init(marketmainclassjson: myResponse!)
                    print("status = ",myUser?.status as Any)
                    print(myUser?.status as Any)
            
                    if myUser?.status == "Succeed"{
                
                        //  cell.SellsellTV.marketradeArray = (myUser?.marketdataclass)!
                        self.sell_tableview?.markettradeArray = (myUser?.marketdataclass)!
                    }
                    else{
                        Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                    }
                }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
    
}

//MARK:-  firsttableApiHIt
    
extension SellcontainerVC{
    private func firsttableApiHIt(){
        var myResponse : JSON? = nil
        var myUser : BuySellMainClass? = nil
        var url = String()
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
        
        if self.marketID.contains("&live=1") {
            url = SellOrdeByMarket_LiveURL
        }
        else{
            url = SellOrderByMarket_URL
        }
            ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:url, viewController: self,paramvalue:self.marketID,paramname: "marketid", loadercheck: 5, onCompletion: { (Pairjson) ->Void in
            myResponse = Pairjson
            //self.firsttablearray.removeAll()
            print("SELL ORDER FIX ID DATA FIX ID API IS SELL CV",myResponse!)
            DispatchQueue.main.async {
                    print("This is run on the main queue, after the previous code in outer block")
                
                    myUser = BuySellMainClass.init(buysellmainclassresponse: myResponse!)
                    // myUser = MarketMainClass.init(marketmainclassjson: myResponse!)
                    print("status = ",myUser?.status as Any)
                    print(myUser?.status as Any)
            
                    if myUser?.status == "Succeed"{
                
                            //self.order_tableview.ordertablearray = (myUser?.buysellddataclass)!
                
                            self.firsttablearray = (myUser?.buysellddataclass)!
                    }
                    else{
                            Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                    }
                }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
}
//MARK:-  SecondtableApiHIt
extension SellcontainerVC{
    private func SecondtableApiHIt(){
        var myResponse : JSON? = nil
        var myUser : BuySellMainClass? = nil
        var url = String()
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
       
        if self.marketID.contains("&live=1") {
            url = BuyOrderBuymarket_LiveURL
        }
        else{
            url = BuyOrderBuymarket_URL
        }
            ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:url, viewController: self,paramvalue: self.marketID,paramname: "marketid", loadercheck: 5, onCompletion: { (Pairjson) ->Void in
            myResponse = Pairjson
            //self.secondtablearray.removeAll()
            print("BUY ORDER FIX ID DATA FIX ID API IS SELL CV",myResponse!)
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
               
                myUser = BuySellMainClass.init(buysellmainclassresponse: myResponse!)
            
                //myUser = MarketMainClass.init(marketmainclassjson: myResponse!)
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
                if myUser?.status == "Succeed"{
                    self.secondtablearray = (myUser?.buysellddataclass)!
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
                }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
}

extension SellcontainerVC {
     func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        sellprice = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        print("sell price string",string)
        print("sell price value",sellprice)
        if sellprice.count == 0
        {
            self.totalamount_txt.text = ""
        }
        else
        {
            if marketOrderTag == "L"
            {
                totalAmnt = (sellprice as NSString).floatValue * (btcprice_text.text! as NSString).floatValue
                let numberFormatter = NumberFormatter()
                numberFormatter.numberStyle = .decimal
                numberFormatter.maximumFractionDigits = 8
                let stringg = numberFormatter.string(for: totalAmnt)!
                self.totalamount_txt.text = stringg
            }
            else
            {
                btcprice_text.text = self.SELLPRICE
                totalAmnt = (sellprice as NSString).floatValue * (btcprice_text.text! as NSString).floatValue
                let numberFormatter = NumberFormatter()
                numberFormatter.numberStyle = .decimal
                numberFormatter.maximumFractionDigits = 8
                let stringg = numberFormatter.string(for: totalAmnt)!
                self.totalamount_txt.text = stringg
            }
            
        }
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
    }
}


extension SellcontainerVC{
    private func GetCoinbtcbalanceApiHIt(){
        var myResponse : JSON? = nil
        var myUser : GetCoinBTCBalanceMainClass? = nil
        
        let memberid = UserDefaults.standard.string(forKey: "USERID")
    ApiManager.sharedInstance.fetchResponseFromUrl_getWithtwoParam(urlStr:GetCoinBtcBalance_URL, viewController: self,paramvalue1: marketID,paramname1: "marketId",paramvalue2: memberid!,paramname2: "memberid",  loadercheck: 5, onCompletion: { (coinbtcresponsejson) ->Void in
            myResponse = coinbtcresponsejson
            print("GET COIN BTC BALANCE API IS",myResponse!)
            myUser =  GetCoinBTCBalanceMainClass.init(getcoinbtcmainclassjson: myResponse!)
            
            print("status = ",myUser?.status as Any)
            print(myUser?.status as Any)
            if myUser?.status == "Succeed"{
                self.getcoinbtcbalanceArray = (myUser?.getcoinbtcbalancedataclass)!
                for i in 0..<self.getcoinbtcbalanceArray.count{
                    let singledataarray = self.getcoinbtcbalanceArray[i]
                    self.SELLPRICE = singledataarray.sellprice
                    self.btcprice_text.text = singledataarray.sellprice
                    self.totalcoin_lbl.text = singledataarray.TotalCoin
                    self.balStr = singledataarray.TotalCoin
                }
            }
            else{
                Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
}
}


extension SellcontainerVC{
    
    func SellcurrencyChekApiHit() {
        var myResponse : JSON? = nil
        var myUser : BuySellCurrencyChekMainClass? = nil
        
        let para : [String:String] = ["MarketId":self.marketID, "Price":self.btcprice_text.text!, "Amount":self.sellprice_txt.text!,"TotalPrice":self.totalamount_txt.text!,"curreny":self.marketCodeNew]
        
        ApiManager.sharedInstance.fetchResponseFromUrl(urlStr:SellCurrencyChek_URL, paraMeters: para,viewController: self, loadercheck: 6, onCompletion: { (BuyCurrencychekJson) ->Void in
            myResponse = BuyCurrencychekJson
            // myUser = LOGIN(loginjson: myResponse!)
            myUser = BuySellCurrencyChekMainClass.init(buysellcurrencychekmainclassjson: myResponse!)
            print("Sell CURRENCY CHEK API IS",myResponse!)
            print("message = ",myUser?.Message as Any)
            print(myUser?.status as Any)
            
            if myUser?.status == "Succeed"{
                if (myUser?.busellcurrencychekdataclass.count)! > 0
                {
                    //for i in 0..<bussellcurrencydata.count
                    //{
                    let isOkStr =  myUser?.busellcurrencychekdataclass[0].isok
                    if isOkStr == "0"
                    {
                        let str = "#" + (myUser?.busellcurrencychekdataclass[0].key)! + " Bought " + (myUser?.busellcurrencychekdataclass[0].toamount_tot)! + " " + (myUser?.busellcurrencychekdataclass[0].fromcurrency)! + " with " + (myUser?.busellcurrencychekdataclass[0].fromamount)! + " " + (myUser?.busellcurrencychekdataclass[0].tocurrency)! + " , " + " Price: " + (myUser?.busellcurrencychekdataclass[0].price)! + " Fee: " + (myUser?.busellcurrencychekdataclass[0].fee)! + " " + (myUser?.busellcurrencychekdataclass[0].fromcurrency)! + " Net Total: " + (myUser?.busellcurrencychekdataclass[0].toamount)!
                        //Alert.showBasic(title: "Alert", message: str , viewController: self)
                        let alrtctr = UIAlertController.init(title: "Alert", message: str, preferredStyle: .alert)
                        let alrtact1 = UIAlertAction.init(title: "Confirm", style: .default, handler: {action in
                            self.SellcurrencyChekApiHitAgain()
                        })
                        let alrtact2 = UIAlertAction.init(title: "Cancel", style: .default, handler: {action in
                            
                        })
                        alrtctr.addAction(alrtact1)
                        alrtctr.addAction(alrtact2)
                        self.present(alrtctr, animated: true, completion: nil)
                    }
                    else if isOkStr == "1"
                    {
                        self.tradeTotal.removeAll()
                        self.tradePrice.removeAll()
                        self.tradeVolume.removeAll()
                        
                        if let bussellcurrencydata = myUser?.busellcurrencychekdataclass
                        {
                            for i in 0..<bussellcurrencydata.count
                            {
                                self.tradePrice.append(bussellcurrencydata[i].price)
                                self.tradeVolume.append(bussellcurrencydata[i].fromamount)
                                self.tradeTotal.append(bussellcurrencydata[i].toamount_tot)
                            }
                        }
                        
                        self.tradedetail_popview.isHidden = false
                        self.blur_btnoutlet.isHidden = false
                        self.tradedetail_tableview.reloadData()
                        
                        //                            let alrtctr = UIAlertController.init(title: "Alert", message: "Some order available on below price", preferredStyle: .alert)
                        //                            let alrtact1 = UIAlertAction.init(title: "Confirm", style: .default, handler: {action in
                        //
                        //                            })
                        //                            let alrtact2 = UIAlertAction.init(title: "Cancel", style: .default, handler: {action in
                        //
                        //                            })
                        //                            alrtctr.addAction(alrtact1)
                        //                            alrtctr.addAction(alrtact2)
                        //                            self.present(alrtctr, animated: true, completion: nil)
                    }
                    //}
                }
                
            }
                
            else{
                Alert.showBasic(title: "", message: (myUser?.Message)!, viewController: self)
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
}

extension SellcontainerVC{
    
    func SellcurrencyChekApiHitAgain() {
        var myResponse : JSON? = nil
        var myUser : BuySellClass? = nil
        let memberid = UserDefaults.standard.string(forKey: "USERID")
        
        let para : [String:String] = ["MarketId":self.marketID, "Price":self.btcprice_text.text!, "Amount":self.sellprice_txt.text! ,"TotalPrice":self.totalamount_txt.text!,"curreny":self.marketCodeNew,"BuyClick":"true","MemberId":memberid!]
        
        ApiManager.sharedInstance.fetchResponseFromUrl(urlStr:SellCurrencyChek_URL, paraMeters: para,viewController: self, loadercheck: 6, onCompletion: { (BuySellJson) ->Void in
            myResponse = BuySellJson
            myUser = BuySellClass.init(buyselljson: myResponse!)
            print("Sell CURRENCY CHEK Again API IS",myResponse!)
            print("message = ",myUser?.Message as Any)
            print(myUser?.status as Any)
            
            if myUser?.status == "Succeed"{
               Alert.showBasic(title: "", message: (myUser?.Message)!, viewController: self)
                //let openOrder = OpenOrderVC()
                //openOrder.TradeApiHIt()
                self.sellprice_txt.text = ""
                self.totalamount_txt.text = ""
                self.GetCoinbtcbalanceApiHIt()
                self.firsttableApiHIt()
                self.SecondtableApiHIt()
                self.MarketTradeApiHIt()
            }
            else{
                Alert.showBasic(title: "", message: (myUser?.Message)!, viewController: self)
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
    }
}

extension SellcontainerVC{
    
        private func GraphGetApiHIt(){
            var myResponse : JSON? = nil
            var myUser : GraphClass? = nil
            
            DispatchQueue.global(qos: .background).async {
                print("This is run on the background queue")
                
                
                ApiManager.sharedInstance.fetchResponseFromUrl_getWithtwoParam(urlStr: GraphData_URL, viewController: self, paramvalue1: self.marketID, paramname1: "marketid", paramvalue2: "86400", paramname2: "history", loadercheck: 1, onCompletion: { (GraphDataJson) ->Void in
                    myResponse = GraphDataJson
                    print(" Graph Data is ",myResponse!)
                    DispatchQueue.main.async {
                        print("This is run on the main queue, after the previous code in outer block")
                        
                        myUser = GraphClass.init(graphclassresponse: myResponse!)
                        print("status = ",myUser?.status as Any)
                        print(myUser?.status as Any)
                        
                        if myUser?.status == "Succeed"{
                            self.volumeArray.removeAll()
                            self.highArray.removeAll()
                            self.lowArray.removeAll()
                            self.openArray.removeAll()
                            self.timeArray.removeAll()
                            self.tradeTrypeArray.removeAll()
                            self.timeArray0.removeAll()
                            self.timeArray1.removeAll()
                            self.volumeArray0.removeAll()
                            self.volumeArray1.removeAll()
                            
                            if let graphDataArray = myUser?.graphdataclass{
                                for i in 0..<graphDataArray.count{
                                    
                                    let volume = graphDataArray[i].volume
                                    self.volumeArray.append(Double(volume)!)
                                    let high = graphDataArray[i].high
                                    self.highArray.append(Double(high)!)
                                    let low = graphDataArray[i].low
                                    self.lowArray.append(Double(low)!)
                                    let ticker = graphDataArray[i].ticker
                                    self.timeArray.append(ticker)
                                    let openPrice = graphDataArray[i].open
                                    self.openArray.append(Double(openPrice)!)
                                    let tradetype = graphDataArray[i].tradetype
                                    self.tradeTrypeArray.append(tradetype)
                                    let array = ticker.components(separatedBy:" " )
                                    self.timeArray0.append(array[0])
                                    let arrayNew = array[1].components(separatedBy: ":")
                                    let timee = arrayNew[0] + ":" + arrayNew[1]
                                    self.timeArray1.append(timee)
                                }
                            }
                            if (myUser?.graphdataclass.count)! == 98{
                                if let graphDataArray0 = myUser?.graphdataclass0{
                                    for i in 0..<graphDataArray0.count{
                                        self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                    }
                                }
                                if let graphDataArray1 = myUser?.graphdataclass1{
                                    for i in 0..<graphDataArray1.count{
                                        self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                    }
                                }
                            }
                            if (myUser?.graphdataclass.count)! > 98{
                                if let graphDataArray0 = myUser?.graphdataclass0{
                                    if graphDataArray0.count > 98{
                                        for i in 0..<98{
                                            self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                        }
                                    }
                                    else{
                                        for i in 0..<graphDataArray0.count{
                                            self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                        }
                                    }
                                }
                                if let graphDataArray1 = myUser?.graphdataclass1{
                                    if graphDataArray1.count > 98{
                                        for i in 0..<98{
                                            self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                        }
                                    }
                                    else{
                                        for i in 0..<graphDataArray1.count{
                                            self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                        }
                                    }
                                }
                            }
                            if (myUser?.graphdataclass.count)! < 98{
                                if let graphDataArray0 = myUser?.graphdataclass0{
                                    for i in 0..<graphDataArray0.count{
                                        self.volumeArray0.append(Double(graphDataArray0[i].volume)!)
                                    }
                                }
                                if let graphDataArray1 = myUser?.graphdataclass1{
                                    for i in 0..<graphDataArray1.count{
                                        self.volumeArray1.append(Double(graphDataArray1[i].volume)!)
                                    }
                                }
                                for i in (myUser?.graphdataclass0.count)! + (myUser?.graphdataclass1.count)!..<98{
                                    self.volumeArray0.append(0)
                                }
                            }
                            else
                            {
                                
                            }
                            
                            self.setChart(xValues: self.months, yValuesLineChart:  self.openArray, yValuesBarChart: self.volumeArray, yValuesBarChart0: self.volumeArray0, yValuesBarChart1: self.volumeArray1)
                        }
                        else{
                            Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                        }
                    }
                })
                {
                    (failure)-> Void in
                    POPMESSAGE.popmessage.NoInternetMessage()
                }
            }
        }
        

}


