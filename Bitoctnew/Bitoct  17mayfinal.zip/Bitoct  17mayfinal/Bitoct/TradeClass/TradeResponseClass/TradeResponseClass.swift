//
//  TradeResponseClass.swift
//  Bitoct
//
//  Created by Purushottam on 01/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire



class TradeMainMainClass {
    
    var status = String()
    var Message = String()
    var tradedatajson:JSON?
    var tradedataclass:[TradeDataClass] = []
    
    init(trademaincassjsin:JSON) {
        self.status = trademaincassjsin["status"].stringValue
        self.Message = trademaincassjsin["Message"].stringValue
        self.tradedatajson = trademaincassjsin["Data"]
        
        if let TradeDataArray = self.tradedatajson{
            for i in 0..<TradeDataArray.count{
                let datasingle = TradeDataClass.init(tradedataclassjson: TradeDataArray[i])
               self.tradedataclass.append(datasingle)
          }
       }
        
    }
}

class TradeDataClass {
    var Sno = String()
    var tickerid = String()
    var tradetype = String()
    
    var ticker = String()
    var MarketId = String()
    var Market = String()
    
    var price = String()
    var volume = String()
    var btcvalue = String()
    var Fee = String()
    var NetTotal = String()
    
    init(tradedataclassjson:JSON) {
        self.Sno = tradedataclassjson["Sno"].stringValue
        self.tickerid = tradedataclassjson["tickerid"].stringValue
        self.tradetype = tradedataclassjson["tradetype"].stringValue
        
        self.ticker = tradedataclassjson["ticker"].stringValue
        self.MarketId = tradedataclassjson["MarketId"].stringValue
        self.Market = tradedataclassjson["Market"].stringValue
        
        self.price = tradedataclassjson["price"].stringValue
        self.volume = tradedataclassjson["volume"].stringValue
        self.btcvalue = tradedataclassjson["btcvalue"].stringValue
        
        self.Fee = tradedataclassjson["Fee"].stringValue
        self.NetTotal = tradedataclassjson["NetTotal"].stringValue
        
    }
}





