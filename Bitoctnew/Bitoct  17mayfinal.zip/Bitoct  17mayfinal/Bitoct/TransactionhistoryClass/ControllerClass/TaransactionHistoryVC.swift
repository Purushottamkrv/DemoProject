//
//  TaransactionHistoryVC.swift
//  Bitoct
//
//  Created by Purushottam on 29/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class TaransactionHistoryVC: UIViewController {
    
    
    @IBOutlet weak var deposit_lbl: UILabel!
    @IBOutlet weak var withdrawalline_lbl: UILabel!
    @IBOutlet weak var deposit_containerview: UIView!
    @IBOutlet weak var withdrawal_containerview: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        deposit_containerview.isHidden = false
        withdrawal_containerview.isHidden = true
        deposit_lbl.isHidden = false
        withdrawalline_lbl.isHidden = true

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func backbtn_acn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension TaransactionHistoryVC{
    @IBAction func deposit_btnacn(_ sender: Any) {
        deposit_containerview.isHidden = false
        withdrawal_containerview.isHidden = true
        deposit_lbl.isHidden = false
        withdrawalline_lbl.isHidden = true
    }
    @IBAction func withdrawalbtn_acn(_ sender: Any) {
        deposit_containerview.isHidden = true
        withdrawal_containerview.isHidden = false
        deposit_lbl.isHidden = true
        withdrawalline_lbl.isHidden = false
    }
}
