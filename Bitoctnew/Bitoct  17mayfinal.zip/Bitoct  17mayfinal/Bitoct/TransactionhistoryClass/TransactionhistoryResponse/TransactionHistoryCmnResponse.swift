//
//  TransactionHistoryCmnResponse.swift
//  Bitoct
//
//  Created by Purushottam on 03/05/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class TransactioHistoryMainClass {
    
    var status = String()
    var Message = String()
    var transactionhistorydatajson:JSON?
    var transactionhistorydataclass:[TransationHistoryDataClass] = []
    
    init(transactionhistorymaincassjson:JSON) {
        self.status = transactionhistorymaincassjson["status"].stringValue
        self.Message = transactionhistorymaincassjson["Message"].stringValue
        self.transactionhistorydatajson = transactionhistorymaincassjson["Data"]
        
        if let TransactionhistoryDataArray = self.transactionhistorydatajson{
            for i in 0..<TransactionhistoryDataArray.count{
               let datasingle = TransationHistoryDataClass.init(transactionhistorydataclassjson: TransactionhistoryDataArray[i])
                transactionhistorydataclass.append(datasingle)
            }
        }
        
    }
}

class TransationHistoryDataClass {
    var PaymentAmount = String()
    var PaymentDate = String()
    var txtId = String()
    var Coin = String()
    var Confirmation = String()
    init(transactionhistorydataclassjson:JSON) {
        self.PaymentAmount = transactionhistorydataclassjson["PaymentAmount"].stringValue
        self.PaymentDate = transactionhistorydataclassjson["PaymentDate"].stringValue
        self.txtId = transactionhistorydataclassjson["txtId"].stringValue
        self.Coin = transactionhistorydataclassjson["Coin"].stringValue
        self.Confirmation = transactionhistorydataclassjson["Confirmation"].stringValue
    }
}

