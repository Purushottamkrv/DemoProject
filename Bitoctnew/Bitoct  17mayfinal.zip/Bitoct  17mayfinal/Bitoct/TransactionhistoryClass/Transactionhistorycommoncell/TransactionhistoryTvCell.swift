//
//  TransactionhistoryTvCell.swift
//  Bitoct
//
//  Created by Purushottam on 29/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class TransactionhistoryTvCell: UITableViewCell {

    @IBOutlet weak var coin_lbl: UILabel!
    
    @IBOutlet weak var paymentamount_lbl: UILabel!
    @IBOutlet weak var paymetdate_lbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
