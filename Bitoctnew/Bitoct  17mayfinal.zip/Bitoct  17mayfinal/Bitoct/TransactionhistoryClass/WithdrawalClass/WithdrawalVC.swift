//
//  WithdrawalVC.swift
//  Bitoct
//
//  Created by Purushottam on 30/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

import SwiftyJSON
import Alamofire

class WithdrawalVC: UIViewController {
    
    var timerWithdraw = Timer()
    @IBOutlet weak var withdrawal_tableview: WithdrawalTV!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        WithdrawApiHit()
        
        withdrawal_tableview.register(UINib(nibName: "TransactionhistoryTvCell", bundle: nil), forCellReuseIdentifier: "TransactionhistoryTvCell")
        
        //timerWithdraw = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        timerWithdraw = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.updateData), userInfo: nil, repeats: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timerWithdraw.invalidate()
    }
    @objc func updateData()
    {
        self.WithdrawApiHit()
    }


}
extension WithdrawalVC{
    private func WithdrawApiHit(){
        var myResponse : JSON? = nil
        var myUser : TransactioHistoryMainClass? = nil
        let memberid = UserDefaults.standard.string(forKey: "USERID")
        
        DispatchQueue.global(qos: .background).async {
            print("This is run on the background queue")
        
        ApiManager.sharedInstance.fetchResponseFromUrl_getWithParam(urlStr:WithdrawalHistory_URL, viewController: self,paramvalue:memberid! ,paramname: "MemberId", loadercheck: 5, onCompletion: { (Withdrawaljson) ->Void in
            
            myResponse = Withdrawaljson
            print(" WITHDRAWAL HISTORY DATA API IS",myResponse!)
            
            DispatchQueue.main.async {
                print("This is run on the main queue, after the previous code in outer block")
                //  myUser = PairMainclass.init(pairmainclassjson: myResponse!)
                myUser = TransactioHistoryMainClass.init(transactionhistorymaincassjson: myResponse!)
            
                print("status = ",myUser?.status as Any)
                print(myUser?.status as Any)
                if myUser?.status == "Succeed"{
                
                    // self.gainer_tableview.gainerDataArray = (myUser?.pairdataclassplus)!
                
                    self.withdrawal_tableview.withdrawaldataarray = (myUser?.transactionhistorydataclass)!
                }
                else{
                    Alert.showBasic(title: "", message:(myUser?.Message)!, viewController: self)
                }
            }
        })
        {
            (failure)-> Void in
            POPMESSAGE.popmessage.NoInternetMessage()
        }
        }
    }
}

