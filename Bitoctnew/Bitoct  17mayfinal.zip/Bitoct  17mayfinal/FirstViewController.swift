//
//  FirstViewController.swift
//  Bitoct
//
//  Created by apple on 5/10/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var logoName: UILabel!
    @IBOutlet weak var gifImageView: UIImageView!
    var timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        UIView.beginAnimations("animateText", context: nil)
//        UIView.setAnimationCurve(.easeIn)
//        UIView.setAnimationDuration(5.0)
//        self.logoName.alpha = 0
//        self.logoName.text = "BITOCT"

//        self.logoName.alpha = 1.0
//        UIView.commitAnimations()
        
//        UIView.transition(with: self.view, duration: 5.0, options: UIViewAnimationOptions.transitionCrossDissolve, animations: {
//            self.logoName.text = "BITOCT"
//        }, completion: { (finished: Bool) -> () in
//            self.logoName.text = "BITOCT"
//        })
        
        
        /*self.logoName.alpha = 1.0
        UIView.animate(withDuration: 2.0, delay: 0.5, usingSpringWithDamping: 0.2, initialSpringVelocity: 0.9, options: .curveEaseIn, animations: {
            self.logoName.center = CGPoint(x: self.mainView.frame.origin.x, y: self.mainView.frame.origin.y+200)
            self.logoName.alpha = 1.0
        }, completion: nil) */
        
        
        gifImageView.image = UIImage.animatedImageNamed("Arrow-", duration: 2.0)
        gifImageView.animationRepeatCount = 0
        gifImageView.startAnimating()
        
        timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
        // Do any additional setup after loading the view.
    }

    @objc func update()
    {
        let userid = UserDefaults.standard.string(forKey: "USERID")
        if userid != nil{
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let tabVC = storyboard.instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
            tabVC.selectedIndex = 0
            //let navigationController = application.windows[0].rootViewController as! UINavigationController
            timer.invalidate()
            self.navigationController?.pushViewController(tabVC, animated: false)
            
        }
        else{
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let loginVC = storyboard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            
            //let navigationController = application.windows[0].rootViewController as! UINavigationController
            timer.invalidate()
            self.navigationController?.pushViewController(loginVC, animated: false)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
