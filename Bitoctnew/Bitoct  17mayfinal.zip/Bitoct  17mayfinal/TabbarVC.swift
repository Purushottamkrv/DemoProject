//
//  TabbarVC.swift
//  Bitoct
//
//  Created by Purushottam on 25/04/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class TabbarVC: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        UITabBar.appearance().barTintColor = UIColor.black
       // UITabBar.appearance().tintColor. = UIColor.white
        //[[UITabBar appearance] setUnselectedItemTintColor:[UIColor blackColor]];
        
        //.appearance().tintColor.u
        UITabBar.appearance().unselectedItemTintColor = UIColor.white


       // UITabBar.appearance().barTintColor = UIColor .white


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
